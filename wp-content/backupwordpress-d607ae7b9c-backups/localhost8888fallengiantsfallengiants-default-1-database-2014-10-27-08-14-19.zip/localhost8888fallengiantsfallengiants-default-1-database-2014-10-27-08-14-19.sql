# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (3 records)
#
 
INSERT INTO `wp_commentmeta` VALUES (1, 2, 'rating', '5') ; 
INSERT INTO `wp_commentmeta` VALUES (2, 3, 'is_customer_note', '0') ; 
INSERT INTO `wp_commentmeta` VALUES (3, 4, 'is_customer_note', '0') ;
#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (4 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-10-09 02:56:00', '2014-10-09 02:56:00', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (2, 167, 'admin_fg', 'alex.chavet@gmail.com', '', '::1', '2014-10-13 07:12:23', '2014-10-13 07:12:23', 'Good wine', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.101 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (3, 168, 'admin_fg', 'alex.chavet@gmail.com', '', '', '2014-10-14 00:56:12', '2014-10-14 00:56:12', 'Order status changed from pending payment to processing.', 0, '1', 'WooCommerce', 'order_note', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (4, 168, 'admin_fg', 'alex.chavet@gmail.com', '', '', '2014-10-14 00:56:18', '2014-10-14 00:56:18', 'Order status changed from processing to completed.', 0, '1', 'WooCommerce', 'order_note', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=682 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (311 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost:8888/FallenGiants/fallengiants', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Fallen Giants', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'Just another WordPress site', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'alex.chavet@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (32, 'active_plugins', 'a:4:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:19:"jetpack/jetpack.php";i:2;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:3;s:27:"woocommerce/woocommerce.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'home', 'http://localhost:8888/FallenGiants/fallengiants', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (41, 'template', 'cornerstone-master', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'stylesheet', 'fallengiants', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'db_version', '29630', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'page_on_front', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'initial_db_version', '27916', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:132:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:3:{s:4:"read";b:1;s:10:"edit_posts";b:0;s:12:"delete_posts";b:0;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop Manager";s:12:"capabilities";a:110:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_users";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:15:"unfiltered_html";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'sidebars_widgets', 'a:6:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:18:"orphaned_widgets_2";a:0:{}s:13:"array_version";i:3;s:13:"right_sidebar";a:0:{}s:14:"footer_sidebar";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'cron', 'a:11:{i:1414368000;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1414397681;a:1:{s:20:"jetpack_clean_nonces";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1414401247;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1414421790;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1414432130;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1414439220;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1414450800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1414465091;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1414465134;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1414897200;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, '_transient_random_seed', '8aaf430cda4d388204700d94ccbeac2a', 'yes') ; 
INSERT INTO `wp_options` VALUES (100, 'auth_key', 'uM25O+r$(jt{gp7({Bs$VcMGc~]t#%EcJFM8IeM4H>yk?GJ@Yh7p[dp7.?J6_hsa', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, 'auth_salt', 'z%<ph`$R)C@V&qN0~00Ohf`];4ELAWTLYicjie6J#=.KjFs881!Jp5c8-qo-8NC:', 'yes') ; 
INSERT INTO `wp_options` VALUES (102, 'logged_in_key', 'T/ Ls9 )+df8.>Rf5[{C:V3@1^}F/0^VN@SFaBgW!fqX`miD62x; +m;AMp$b.*q', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, 'logged_in_salt', '((x1uATL9,7?oENKG%K_&[sjsQVBf}@rFb{LH&W?xb2:Bb=jF .(<:`Sfhe0:JM{', 'yes') ; 
INSERT INTO `wp_options` VALUES (104, 'nonce_key', '3*d=C5@qNgZT&:r[?pQfnI.H|y{!&dYKQ&;B[kmBNzgL&MDt@s4^<iN?|XuM@* m', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, 'nonce_salt', '16KZ!Iq^K1Y#8^ycLN5q< bdir1Hs0@-r|y&zxO/,*n0~Dc~+;&~9=CHV@avkbJ{', 'yes') ; 
INSERT INTO `wp_options` VALUES (129, '_transient_twentyfourteen_category_count', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (134, 'current_theme', 'Fallen Giants', 'yes') ; 
INSERT INTO `wp_options` VALUES (135, 'theme_mods_reverie-master', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1413166262;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:7:"Sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:6:"Footer";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (136, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (140, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (147, '_transient_timeout_presstrends_theme_cache_data', '1413252049', 'no') ; 
INSERT INTO `wp_options` VALUES (148, '_transient_presstrends_theme_cache_data', 'a:15:{s:3:"url";s:37:"localhost8888FallenGiantsfallengiants";s:5:"posts";s:1:"1";s:5:"pages";s:1:"5";s:8:"comments";i:1;s:8:"approved";s:1:"1";s:4:"spam";i:0;s:9:"pingbacks";s:1:"0";s:15:"post_conversion";s:3:"100";s:13:"theme_version";s:5:"5.2.3";s:10:"theme_name";s:7:"Reverie";s:9:"site_name";s:12:"FallenGiants";s:7:"plugins";i:0;s:6:"plugin";s:27:"%26Akismet%26Hello+Dolly%26";s:9:"wpversion";s:5:"3.9.1";s:11:"api_version";s:3:"2.4";}', 'no') ; 
INSERT INTO `wp_options` VALUES (149, '_site_transient_timeout_browser_dfa360b589279742faa044ee50d0ed9e', '1413770450', 'yes') ; 
INSERT INTO `wp_options` VALUES (150, '_site_transient_browser_dfa360b589279742faa044ee50d0ed9e', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"38.0.2125.101";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (167, 'theme_mods_fallengiants', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:3:{s:16:"header-menu-left";i:2;s:11:"footer-menu";i:0;s:17:"header-menu-right";i:7;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (168, 'recently_activated', 'a:1:{s:67:"comprehensive-google-map-plugin/comprehensive-google-map-plugin.php";i:1414039905;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (169, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1413167669;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (170, 'WPLANG', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (171, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (173, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:57:"https://downloads.wordpress.org/release/wordpress-4.0.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:57:"https://downloads.wordpress.org/release/wordpress-4.0.zip";s:10:"no_content";s:68:"https://downloads.wordpress.org/release/wordpress-4.0-no-content.zip";s:11:"new_bundled";s:69:"https://downloads.wordpress.org/release/wordpress-4.0-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"4.0";s:7:"version";s:3:"4.0";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1414397649;s:15:"version_checked";s:3:"4.0";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (174, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (186, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (187, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (188, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (189, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (196, 'woocommerce_default_country', 'AU:VIC', 'yes') ; 
INSERT INTO `wp_options` VALUES (197, 'woocommerce_allowed_countries', 'all', 'yes') ; 
INSERT INTO `wp_options` VALUES (198, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (199, 'woocommerce_demo_store', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (200, 'woocommerce_demo_store_notice', 'This is a demo store for testing purposes — no orders shall be fulfilled.', 'no') ; 
INSERT INTO `wp_options` VALUES (201, 'woocommerce_api_enabled', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (202, 'woocommerce_currency', 'AUD', 'yes') ; 
INSERT INTO `wp_options` VALUES (203, 'woocommerce_currency_pos', 'left', 'yes') ; 
INSERT INTO `wp_options` VALUES (204, 'woocommerce_price_thousand_sep', ',', 'yes') ; 
INSERT INTO `wp_options` VALUES (205, 'woocommerce_price_decimal_sep', '.', 'yes') ; 
INSERT INTO `wp_options` VALUES (206, 'woocommerce_price_num_decimals', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (207, 'woocommerce_enable_lightbox', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (208, 'woocommerce_enable_chosen', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (209, 'woocommerce_shop_page_id', '7', 'yes') ; 
INSERT INTO `wp_options` VALUES (210, 'woocommerce_shop_page_display', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (211, 'woocommerce_category_archive_display', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (212, 'woocommerce_default_catalog_orderby', 'menu_order', 'yes') ; 
INSERT INTO `wp_options` VALUES (213, 'woocommerce_cart_redirect_after_add', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (214, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (215, 'woocommerce_weight_unit', 'kg', 'yes') ; 
INSERT INTO `wp_options` VALUES (216, 'woocommerce_dimension_unit', 'cm', 'yes') ; 
INSERT INTO `wp_options` VALUES (217, 'woocommerce_enable_review_rating', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (218, 'woocommerce_review_rating_required', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (219, 'woocommerce_review_rating_verification_label', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (220, 'woocommerce_review_rating_verification_required', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (221, 'shop_catalog_image_size', 'a:3:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (222, 'shop_single_image_size', 'a:3:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";s:1:"1";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (223, 'shop_thumbnail_image_size', 'a:3:{s:5:"width";s:2:"30";s:6:"height";s:2:"30";s:4:"crop";s:1:"1";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (224, 'woocommerce_file_download_method', 'force', 'no') ; 
INSERT INTO `wp_options` VALUES (225, 'woocommerce_downloads_require_login', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (226, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (227, 'woocommerce_manage_stock', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (228, 'woocommerce_hold_stock_minutes', '60', 'no') ; 
INSERT INTO `wp_options` VALUES (229, 'woocommerce_notify_low_stock', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (230, 'woocommerce_notify_no_stock', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (231, 'woocommerce_stock_email_recipient', 'alex.chavet@gmail.com', 'no') ; 
INSERT INTO `wp_options` VALUES (232, 'woocommerce_notify_low_stock_amount', '2', 'no') ; 
INSERT INTO `wp_options` VALUES (233, 'woocommerce_notify_no_stock_amount', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (234, 'woocommerce_hide_out_of_stock_items', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (235, 'woocommerce_stock_format', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (236, 'woocommerce_calc_taxes', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (237, 'woocommerce_prices_include_tax', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (238, 'woocommerce_tax_based_on', 'shipping', 'yes') ; 
INSERT INTO `wp_options` VALUES (239, 'woocommerce_default_customer_address', 'base', 'yes') ; 
INSERT INTO `wp_options` VALUES (240, 'woocommerce_shipping_tax_class', 'title', 'yes') ; 
INSERT INTO `wp_options` VALUES (241, 'woocommerce_tax_round_at_subtotal', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (242, 'woocommerce_tax_classes', 'Reduced Rate
Zero Rate', 'yes') ; 
INSERT INTO `wp_options` VALUES (243, 'woocommerce_tax_display_shop', 'excl', 'yes') ; 
INSERT INTO `wp_options` VALUES (244, 'woocommerce_price_display_suffix', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (245, 'woocommerce_tax_display_cart', 'excl', 'no') ; 
INSERT INTO `wp_options` VALUES (246, 'woocommerce_tax_total_display', 'itemized', 'no') ; 
INSERT INTO `wp_options` VALUES (247, 'woocommerce_enable_coupons', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (248, 'woocommerce_enable_guest_checkout', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (249, 'woocommerce_force_ssl_checkout', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (250, 'woocommerce_unforce_ssl_checkout', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (251, 'woocommerce_cart_page_id', '35', 'yes') ; 
INSERT INTO `wp_options` VALUES (252, 'woocommerce_checkout_page_id', '37', 'yes') ; 
INSERT INTO `wp_options` VALUES (253, 'woocommerce_terms_page_id', '', 'no') ; 
INSERT INTO `wp_options` VALUES (254, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes') ; 
INSERT INTO `wp_options` VALUES (255, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes') ; 
INSERT INTO `wp_options` VALUES (256, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes') ; 
INSERT INTO `wp_options` VALUES (257, 'woocommerce_calc_shipping', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (258, 'woocommerce_enable_shipping_calc', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (259, 'woocommerce_shipping_cost_requires_address', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (260, 'woocommerce_shipping_method_format', '', 'no') ; 
INSERT INTO `wp_options` VALUES (261, 'woocommerce_ship_to_destination', 'shipping', 'no') ; 
INSERT INTO `wp_options` VALUES (262, 'woocommerce_ship_to_countries', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (263, 'woocommerce_specific_ship_to_countries', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (264, 'woocommerce_myaccount_page_id', '39', 'yes') ; 
INSERT INTO `wp_options` VALUES (265, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes') ; 
INSERT INTO `wp_options` VALUES (266, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes') ; 
INSERT INTO `wp_options` VALUES (267, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes') ; 
INSERT INTO `wp_options` VALUES (268, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes') ; 
INSERT INTO `wp_options` VALUES (269, 'woocommerce_logout_endpoint', 'customer-logout', 'yes') ; 
INSERT INTO `wp_options` VALUES (270, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (271, 'woocommerce_enable_myaccount_registration', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (272, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (273, 'woocommerce_registration_generate_username', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (274, 'woocommerce_registration_generate_password', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (275, 'woocommerce_email_from_name', 'Fallen Giants', 'no') ; 
INSERT INTO `wp_options` VALUES (276, 'woocommerce_email_from_address', 'alex.chavet@gmail.com', 'no') ; 
INSERT INTO `wp_options` VALUES (277, 'woocommerce_email_header_image', '', 'no') ; 
INSERT INTO `wp_options` VALUES (278, 'woocommerce_email_footer_text', 'Fallen Giants - Powered by WooCommerce', 'no') ; 
INSERT INTO `wp_options` VALUES (279, 'woocommerce_email_base_color', '#557da1', 'no') ; 
INSERT INTO `wp_options` VALUES (280, 'woocommerce_email_background_color', '#f5f5f5', 'no') ; 
INSERT INTO `wp_options` VALUES (281, 'woocommerce_email_body_background_color', '#fdfdfd', 'no') ; 
INSERT INTO `wp_options` VALUES (282, 'woocommerce_email_text_color', '#505050', 'no') ; 
INSERT INTO `wp_options` VALUES (284, 'woocommerce_db_version', '2.2.6', 'yes') ; 
INSERT INTO `wp_options` VALUES (285, 'woocommerce_version', '2.2.6', 'yes') ; 
INSERT INTO `wp_options` VALUES (292, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (294, 'woocommerce_frontend_css_colors', 'a:5:{s:7:"primary";s:7:"#ad74a2";s:9:"secondary";s:7:"#f7f6f7";s:9:"highlight";s:7:"#85ad74";s:10:"content_bg";s:7:"#ffffff";s:7:"subtext";s:7:"#777777";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (297, '_transient_product_query-transient-version', '1414103972', 'yes') ; 
INSERT INTO `wp_options` VALUES (307, 'product_shipping_class_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (308, '_transient_timeout_wc_rating_count_41', '1444718717', 'no') ; 
INSERT INTO `wp_options` VALUES (309, '_transient_wc_rating_count_41', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (310, '_transient_timeout_wc_average_rating_41', '1444718717', 'no') ; 
INSERT INTO `wp_options` VALUES (311, '_transient_wc_average_rating_41', '', 'no') ; 
INSERT INTO `wp_options` VALUES (321, '_transient_timeout_wc_rating_count_166', '1444719820', 'no') ; 
INSERT INTO `wp_options` VALUES (322, '_transient_wc_rating_count_166', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (323, '_transient_timeout_wc_average_rating_166', '1444719820', 'no') ; 
INSERT INTO `wp_options` VALUES (324, '_transient_wc_average_rating_166', '', 'no') ; 
INSERT INTO `wp_options` VALUES (325, '_transient_timeout_woocommerce_addons_data', '1413788772', 'no') ; 
INSERT INTO `wp_options` VALUES (326, '_transient_woocommerce_addons_data', 'O:8:"stdClass":10:{s:8:"featured";a:4:{i:0;O:8:"stdClass":5:{s:5:"title";s:20:"WooCommerce Bookings";s:5:"image";s:0:"";s:7:"excerpt";s:108:"Sell your time or date based bookings! Perfect for those wanting to offer appointments, services or rentals.";s:4:"link";s:114:"http://www.woothemes.com/products/woocommerce-bookings/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;249.00";}i:1;O:8:"stdClass":5:{s:5:"title";s:15:"Product Add-ons";s:5:"image";s:0:"";s:7:"excerpt";s:110:"Allow your customers to customise your products by adding input boxes, dropdowns or a field set of checkboxes.";s:4:"link";s:109:"http://www.woothemes.com/products/product-add-ons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:2;O:8:"stdClass":5:{s:5:"title";s:25:"WooCommerce Subscriptions";s:5:"image";s:84:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/09/woosubs.png";s:7:"excerpt";s:85:"WC Subscriptions makes it easy to create and manage products with recurring payments.";s:4:"link";s:119:"http://www.woothemes.com/products/woocommerce-subscriptions/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;199.00";}i:3;O:8:"stdClass":5:{s:5:"title";s:19:"Table Rate Shipping";s:5:"image";s:0:"";s:7:"excerpt";s:123:"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.";s:4:"link";s:115:"http://www.woothemes.com/products/table-rate-shipping-2/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;199.00";}}s:7:"popular";a:25:{i:0;O:8:"stdClass":5:{s:5:"title";s:19:"WooCommerce iOS App";s:5:"image";s:0:"";s:7:"excerpt";s:217:"Keep your finger on the pulse of your online shop with WooCommerce iOS. All of your shop\'s catalog & performance reports are now just a tap away - quickly accessible & beautifully presented right there on your iPhone.";s:4:"link";s:100:"http://www.woothemes.com/woocommerce-ios/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;4.99";}i:1;O:8:"stdClass":5:{s:5:"title";s:15:"Product Add-ons";s:5:"image";s:0:"";s:7:"excerpt";s:110:"Allow your customers to customise your products by adding input boxes, dropdowns or a field set of checkboxes.";s:4:"link";s:109:"http://www.woothemes.com/products/product-add-ons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:2;O:8:"stdClass":5:{s:5:"title";s:15:"Pay with Amazon";s:5:"image";s:116:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/08/AP_HLogo_215x35-3012530377._V360408447_.png";s:7:"excerpt";s:153:"Pay with Amazon is embedded directly into your WooCommerce store. Buyer interactions take place in embedded widgets, so the buyer never leaves your site.";s:4:"link";s:109:"http://www.woothemes.com/products/pay-with-amazon/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:3;O:8:"stdClass":5:{s:5:"title";s:25:"WooCommerce Subscriptions";s:5:"image";s:84:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/09/woosubs.png";s:7:"excerpt";s:85:"WC Subscriptions makes it easy to create and manage products with recurring payments.";s:4:"link";s:119:"http://www.woothemes.com/products/woocommerce-subscriptions/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;199.00";}i:4;O:8:"stdClass":5:{s:5:"title";s:20:"USPS Shipping Method";s:5:"image";s:61:"https://www.woothemes.com/wp-content/uploads/2012/09/usps.jpg";s:7:"excerpt";s:91:"Get shipping rates from the USPS API which handles both domestic and international parcels.";s:4:"link";s:114:"http://www.woothemes.com/products/usps-shipping-method/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:5;O:8:"stdClass":5:{s:5:"title";s:19:"Table Rate Shipping";s:5:"image";s:0:"";s:7:"excerpt";s:123:"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.";s:4:"link";s:115:"http://www.woothemes.com/products/table-rate-shipping-2/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;199.00";}i:6;O:8:"stdClass":5:{s:5:"title";s:19:"UPS Shipping Method";s:5:"image";s:85:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/01/ups_logo.gif";s:7:"excerpt";s:90:"Get shipping rates from the UPS API which handles both domestic and international parcels.";s:4:"link";s:113:"http://www.woothemes.com/products/ups-shipping-method/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:7;O:8:"stdClass":5:{s:5:"title";s:6:"Stripe";s:5:"image";s:63:"https://www.woothemes.com/wp-content/uploads/2012/09/stripe.png";s:7:"excerpt";s:30:"Stripe gateway for WooCommerce";s:4:"link";s:100:"http://www.woothemes.com/products/stripe/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:8;O:8:"stdClass":5:{s:5:"title";s:24:"Product CSV Import Suite";s:5:"image";s:0:"";s:7:"excerpt";s:91:"Import, merge, and export products and variations to and from WooCommerce using a CSV file.";s:4:"link";s:118:"http://www.woothemes.com/products/product-csv-import-suite/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;199.00";}i:9;O:8:"stdClass":5:{s:5:"title";s:15:"Dynamic Pricing";s:5:"image";s:0:"";s:7:"excerpt";s:48:"Bulk discounts, role-based pricing and much more";s:4:"link";s:109:"http://www.woothemes.com/products/dynamic-pricing/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:10;O:8:"stdClass":5:{s:5:"title";s:35:"Print Invoices &#038; Packing lists";s:5:"image";s:0:"";s:7:"excerpt";s:49:"Print your WooCommerce invoices and packing lists";s:4:"link";s:122:"http://www.woothemes.com/products/print-invoices-packing-lists/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:11;O:8:"stdClass":5:{s:5:"title";s:25:"Order/Customer CSV Export";s:5:"image";s:0:"";s:7:"excerpt";s:69:"Export orders and customers from WooCommerce to a CSV file with ease.";s:4:"link";s:118:"http://www.woothemes.com/products/ordercustomer-csv-export/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:12;O:8:"stdClass":5:{s:5:"title";s:10:"PayPal Pro";s:5:"image";s:86:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2011/09/paypalpro.png";s:7:"excerpt";s:69:"Take credit card payments directly on your checkout using PayPal Pro.";s:4:"link";s:104:"http://www.woothemes.com/products/paypal-pro/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:13;O:8:"stdClass":5:{s:5:"title";s:17:"Authorize.net AIM";s:5:"image";s:82:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2011/09/auth1.png";s:7:"excerpt";s:112:"Take credit card payments direct on your checkout using the Authorize.net (AIM) payment gateway for WooCommerce.";s:4:"link";s:111:"http://www.woothemes.com/products/authorize-net-aim/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:14;O:8:"stdClass":5:{s:5:"title";s:26:"Catalog Visibility Options";s:5:"image";s:0:"";s:7:"excerpt";s:80:"Transform WooCommerce into an online catalog by removing eCommerce functionality";s:4:"link";s:120:"http://www.woothemes.com/products/catalog-visibility-options/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:15;O:8:"stdClass":5:{s:5:"title";s:21:"Gravity Forms Add-ons";s:5:"image";s:0:"";s:7:"excerpt";s:39:"Powerful product add-ons, Gravity style";s:4:"link";s:115:"http://www.woothemes.com/products/gravity-forms-add-ons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;99.00";}i:16;O:8:"stdClass":5:{s:5:"title";s:15:"Product Bundles";s:5:"image";s:0:"";s:7:"excerpt";s:149:"Create and offer highly configurable product bundles, kits and assemblies that consist of simple and variable items - both physical and downloadable.";s:4:"link";s:109:"http://www.woothemes.com/products/product-bundles/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:17;O:8:"stdClass":5:{s:5:"title";s:15:"Paypal Advanced";s:5:"image";s:91:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/09/paypaladvanced.png";s:7:"excerpt";s:105:"Take credit card payments securely via Paypal Payments Advanced (Payflow) keeping customers on your site.";s:4:"link";s:109:"http://www.woothemes.com/products/paypal-advanced/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;99.00";}i:18;O:8:"stdClass":5:{s:5:"title";s:21:"Checkout Field Editor";s:5:"image";s:0:"";s:7:"excerpt";s:128:"The checkout field editor provides you with an interface to add, edit and remove fields shown on your WooCommerce checkout page.";s:4:"link";s:127:"http://www.woothemes.com/products/woocommerce-checkout-field-editor/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:19;O:8:"stdClass":5:{s:5:"title";s:17:"Authorize.net CIM";s:5:"image";s:75:"https://www.woothemes.com/wp-content/uploads/2013/04/authorize-net-logo.png";s:7:"excerpt";s:68:"Authorize CIM gateway with support for pre-orders and subscriptions.";s:4:"link";s:111:"http://www.woothemes.com/products/authorize-net-cim/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:20;O:8:"stdClass":5:{s:5:"title";s:13:"Smart Coupons";s:5:"image";s:0:"";s:7:"excerpt";s:93:"An "all in one" solution for gift certificates, store credits, discount coupons and vouchers.";s:4:"link";s:107:"http://www.woothemes.com/products/smart-coupons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;99.00";}i:21;O:8:"stdClass":5:{s:5:"title";s:21:"FedEx Shipping Method";s:5:"image";s:98:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/01/FedEx_Logo_Wallpaper.jpeg";s:7:"excerpt";s:92:"Get shipping rates from the FedEx API which handles both domestic and international parcels.";s:4:"link";s:115:"http://www.woothemes.com/products/fedex-shipping-module/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:22;O:8:"stdClass":5:{s:5:"title";s:17:"Shipment Tracking";s:5:"image";s:0:"";s:7:"excerpt";s:48:"Add shipment tracking information to your orders";s:4:"link";s:111:"http://www.woothemes.com/products/shipment-tracking/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:23;O:8:"stdClass":5:{s:5:"title";s:23:"WooCommerce Tab Manager";s:5:"image";s:0:"";s:7:"excerpt";s:134:"Gives you complete control over your product page tabs, create local and global tabs using a visual drag-and-drop interface, and more.";s:4:"link";s:117:"http://www.woothemes.com/products/woocommerce-tab-manager/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;99.00";}i:24;O:8:"stdClass":5:{s:5:"title";s:23:"PayFast Payment Gateway";s:5:"image";s:72:"https://www.woothemes.com/wp-content/uploads/2013/09/PayFast_Logo_75.png";s:7:"excerpt";s:70:"Take payments on your WooCommerce store via PayFast (redirect method).";s:4:"link";s:117:"http://www.woothemes.com/products/payfast-payment-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}}s:16:"payment-gateways";a:24:{i:0;O:8:"stdClass":5:{s:5:"title";s:15:"Pay with Amazon";s:5:"image";s:116:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/08/AP_HLogo_215x35-3012530377._V360408447_.png";s:7:"excerpt";s:153:"Pay with Amazon is embedded directly into your WooCommerce store. Buyer interactions take place in embedded widgets, so the buyer never leaves your site.";s:4:"link";s:109:"http://www.woothemes.com/products/pay-with-amazon/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:1;O:8:"stdClass":5:{s:5:"title";s:6:"Stripe";s:5:"image";s:63:"https://www.woothemes.com/wp-content/uploads/2012/09/stripe.png";s:7:"excerpt";s:30:"Stripe gateway for WooCommerce";s:4:"link";s:100:"http://www.woothemes.com/products/stripe/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:2;O:8:"stdClass":5:{s:5:"title";s:10:"PayPal Pro";s:5:"image";s:86:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2011/09/paypalpro.png";s:7:"excerpt";s:69:"Take credit card payments directly on your checkout using PayPal Pro.";s:4:"link";s:104:"http://www.woothemes.com/products/paypal-pro/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:3;O:8:"stdClass":5:{s:5:"title";s:17:"Authorize.net AIM";s:5:"image";s:82:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2011/09/auth1.png";s:7:"excerpt";s:112:"Take credit card payments direct on your checkout using the Authorize.net (AIM) payment gateway for WooCommerce.";s:4:"link";s:111:"http://www.woothemes.com/products/authorize-net-aim/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:4;O:8:"stdClass":5:{s:5:"title";s:15:"Paypal Advanced";s:5:"image";s:91:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/09/paypaladvanced.png";s:7:"excerpt";s:105:"Take credit card payments securely via Paypal Payments Advanced (Payflow) keeping customers on your site.";s:4:"link";s:109:"http://www.woothemes.com/products/paypal-advanced/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;99.00";}i:5;O:8:"stdClass":5:{s:5:"title";s:17:"Authorize.net CIM";s:5:"image";s:75:"https://www.woothemes.com/wp-content/uploads/2013/04/authorize-net-logo.png";s:7:"excerpt";s:68:"Authorize CIM gateway with support for pre-orders and subscriptions.";s:4:"link";s:111:"http://www.woothemes.com/products/authorize-net-cim/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:6;O:8:"stdClass":5:{s:5:"title";s:23:"PayFast Payment Gateway";s:5:"image";s:72:"https://www.woothemes.com/wp-content/uploads/2013/09/PayFast_Logo_75.png";s:7:"excerpt";s:70:"Take payments on your WooCommerce store via PayFast (redirect method).";s:4:"link";s:117:"http://www.woothemes.com/products/payfast-payment-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:7;O:8:"stdClass":5:{s:5:"title";s:31:"Simplify Commerce by MasterCard";s:5:"image";s:84:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/11/sc-logo.png";s:7:"excerpt";s:149:"Simplify Commerce by MasterCard gives you a merchant account and payment gateway in a single, secure package that takes just a few minutes to set up.";s:4:"link";s:125:"http://www.woothemes.com/products/simplify-commerce-by-mastercard/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:8;O:8:"stdClass":5:{s:5:"title";s:9:"FirstData";s:5:"image";s:66:"https://www.woothemes.com/wp-content/uploads/2012/09/firstdata.jpg";s:7:"excerpt";s:33:"FirstData gateway for WooCommerce";s:4:"link";s:103:"http://www.woothemes.com/products/firstdata/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:9;O:8:"stdClass":5:{s:5:"title";s:17:"Authorize.net DPM";s:5:"image";s:84:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/02/authdpm.png";s:7:"excerpt";s:123:"Take credit card payments safely and securely using the Authorize.net (Direct Post Method) payment gateway for WooCommerce.";s:4:"link";s:111:"http://www.woothemes.com/products/authorize-net-dpm/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:10;O:8:"stdClass":5:{s:5:"title";s:14:"PayPal Express";s:5:"image";s:90:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/05/paypalexpress.png";s:7:"excerpt";s:98:"The PayPal Express gateway for WooCommerce lets users skip the WC checkout and use PayPal instead.";s:4:"link";s:108:"http://www.woothemes.com/products/paypal-express/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:11;O:8:"stdClass":5:{s:5:"title";s:18:"WooCommerce Mollie";s:5:"image";s:63:"https://www.woothemes.com/wp-content/uploads/2012/09/mollie.png";s:7:"excerpt";s:106:"Process secure iDEAL, credit card, Mister Cash, PayPal, and paysafecard payments using WooCommerce Mollie.";s:4:"link";s:112:"http://www.woothemes.com/products/woocommerce-mollie/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:12;O:8:"stdClass":5:{s:5:"title";s:8:"WorldPay";s:5:"image";s:65:"https://www.woothemes.com/wp-content/uploads/2012/09/worldpay.jpg";s:7:"excerpt";s:26:"Take payments via WorldPay";s:4:"link";s:102:"http://www.woothemes.com/products/worldpay/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:13;O:8:"stdClass":5:{s:5:"title";s:13:"Sage Pay Form";s:5:"image";s:69:"https://www.woothemes.com/wp-content/uploads/2011/10/sage-cropped.png";s:7:"excerpt";s:70:"Take payments on your WooCommerce store via SagePay (redirect method).";s:4:"link";s:107:"http://www.woothemes.com/products/sage-pay-form/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:14;O:8:"stdClass":5:{s:5:"title";s:9:"Braintree";s:5:"image";s:66:"https://www.woothemes.com/wp-content/uploads/2012/09/braintree.png";s:7:"excerpt";s:27:"Take payments via Braintree";s:4:"link";s:103:"http://www.woothemes.com/products/braintree/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:15;O:8:"stdClass":5:{s:5:"title";s:4:"eWAY";s:5:"image";s:61:"https://www.woothemes.com/wp-content/uploads/2012/09/eway.gif";s:7:"excerpt";s:92:"Take credit card payments securely via eWay (UK, AU, and NZ) keeping customers on your site.";s:4:"link";s:98:"http://www.woothemes.com/products/eway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:16;O:8:"stdClass":5:{s:5:"title";s:6:"Klarna";s:5:"image";s:93:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2011/12/klarna_main-logo.png";s:7:"excerpt";s:30:"Klarna gateway for WooCommerce";s:4:"link";s:100:"http://www.woothemes.com/products/klarna/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:17;O:8:"stdClass":5:{s:5:"title";s:28:"Intuit Payments/QBMS Gateway";s:5:"image";s:0:"";s:7:"excerpt";s:104:"Allow customers to securely save multiple payment methods</strong> to their account for faster checkout.";s:4:"link";s:105:"http://www.woothemes.com/products/intuit-qbms/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:18;O:8:"stdClass":5:{s:5:"title";s:22:"Sofort payment gateway";s:5:"image";s:83:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/06/200x75.png";s:7:"excerpt";s:60:"Online bank transfer powered by the Sofort payment provider.";s:4:"link";s:116:"http://www.woothemes.com/products/sofort-payment-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:19;O:8:"stdClass":5:{s:5:"title";s:25:"Elavon VM Payment Gateway";s:5:"image";s:84:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/07/images.jpeg";s:7:"excerpt";s:93:"Take credit card payments with Elavon, the fourth largest merchant acquirer in North America.";s:4:"link";s:119:"http://www.woothemes.com/products/elavon-vm-payment-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:20;O:8:"stdClass":5:{s:5:"title";s:28:"PayPal Digital Goods gateway";s:5:"image";s:90:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/01/paypaldigital.png";s:7:"excerpt";s:63:"PayPal Digital Goods gateway specifically for digital products.";s:4:"link";s:122:"http://www.woothemes.com/products/paypal-digital-goods-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:21;O:8:"stdClass":5:{s:5:"title";s:37:"Role based payment / shipping methods";s:5:"image";s:0:"";s:7:"excerpt";s:67:"Limit different user roles to specific payment and shipping methods";s:4:"link";s:129:"http://www.woothemes.com/products/role-based-payment-shipping-methods/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:22;O:8:"stdClass":5:{s:5:"title";s:11:"Payson Form";s:5:"image";s:63:"https://www.woothemes.com/wp-content/uploads/2012/09/payson.png";s:7:"excerpt";s:69:"Take payments on your WooCommerce store via Payson (redirect method).";s:4:"link";s:105:"http://www.woothemes.com/products/payson-form/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:23;O:8:"stdClass":5:{s:5:"title";s:15:"Moneris Gateway";s:5:"image";s:64:"https://www.woothemes.com/wp-content/uploads/2012/09/moneris.gif";s:7:"excerpt";s:32:"Take payments online via Moneris";s:4:"link";s:109:"http://www.woothemes.com/products/moneris-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}}s:16:"shipping-methods";a:24:{i:0;O:8:"stdClass":5:{s:5:"title";s:20:"USPS Shipping Method";s:5:"image";s:61:"https://www.woothemes.com/wp-content/uploads/2012/09/usps.jpg";s:7:"excerpt";s:91:"Get shipping rates from the USPS API which handles both domestic and international parcels.";s:4:"link";s:114:"http://www.woothemes.com/products/usps-shipping-method/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:1;O:8:"stdClass":5:{s:5:"title";s:19:"Table Rate Shipping";s:5:"image";s:0:"";s:7:"excerpt";s:123:"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.";s:4:"link";s:115:"http://www.woothemes.com/products/table-rate-shipping-2/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;199.00";}i:2;O:8:"stdClass":5:{s:5:"title";s:19:"UPS Shipping Method";s:5:"image";s:85:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/01/ups_logo.gif";s:7:"excerpt";s:90:"Get shipping rates from the UPS API which handles both domestic and international parcels.";s:4:"link";s:113:"http://www.woothemes.com/products/ups-shipping-method/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:3;O:8:"stdClass":5:{s:5:"title";s:35:"Print Invoices &#038; Packing lists";s:5:"image";s:0:"";s:7:"excerpt";s:49:"Print your WooCommerce invoices and packing lists";s:4:"link";s:122:"http://www.woothemes.com/products/print-invoices-packing-lists/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:4;O:8:"stdClass":5:{s:5:"title";s:21:"FedEx Shipping Method";s:5:"image";s:98:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/01/FedEx_Logo_Wallpaper.jpeg";s:7:"excerpt";s:92:"Get shipping rates from the FedEx API which handles both domestic and international parcels.";s:4:"link";s:115:"http://www.woothemes.com/products/fedex-shipping-module/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:5;O:8:"stdClass":5:{s:5:"title";s:17:"Shipment Tracking";s:5:"image";s:0:"";s:7:"excerpt";s:48:"Add shipment tracking information to your orders";s:4:"link";s:111:"http://www.woothemes.com/products/shipment-tracking/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:6;O:8:"stdClass":5:{s:5:"title";s:22:"Advanced Notifications";s:5:"image";s:0:"";s:7:"excerpt";s:96:"Easily setup "new order" and stock email notifications for multiple recipients of your choosing.";s:4:"link";s:116:"http://www.woothemes.com/products/advanced-notifications/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:7;O:8:"stdClass":5:{s:5:"title";s:20:"Per Product Shipping";s:5:"image";s:0:"";s:7:"excerpt";s:107:"Define separate shipping costs per product which are combined at checkout to provide a total shipping cost.";s:4:"link";s:114:"http://www.woothemes.com/products/per-product-shipping/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:8;O:8:"stdClass":5:{s:5:"title";s:30:"Australia Post Shipping Method";s:5:"image";s:71:"https://www.woothemes.com/wp-content/uploads/2012/09/australia-post.gif";s:7:"excerpt";s:101:"Get shipping rates from the Australia Post API which handles both domestic and international parcels.";s:4:"link";s:124:"http://www.woothemes.com/products/australia-post-shipping-method/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:9;O:8:"stdClass":5:{s:5:"title";s:23:"ShipStation Integration";s:5:"image";s:88:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/08/shipstation.png";s:7:"excerpt";s:113:"ShipStation is a web-based shipping solution that streamlines the order fulfillment process for online retailers.";s:4:"link";s:117:"http://www.woothemes.com/products/shipstation-integration/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:10;O:8:"stdClass":5:{s:5:"title";s:27:"Canada Post Shipping Method";s:5:"image";s:68:"https://www.woothemes.com/wp-content/uploads/2012/09/canada-post.png";s:7:"excerpt";s:106:"Get shipping rates from the Canada Post Ratings API which handles both domestic and international parcels.";s:4:"link";s:121:"http://www.woothemes.com/products/canada-post-shipping-method/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:11;O:8:"stdClass":5:{s:5:"title";s:17:"Local Pickup Plus";s:5:"image";s:0:"";s:7:"excerpt";s:54:"Let customers pick up products from specific locations";s:4:"link";s:111:"http://www.woothemes.com/products/local-pickup-plus/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:12;O:8:"stdClass":5:{s:5:"title";s:27:"Shipping Multiple Addresses";s:5:"image";s:0:"";s:7:"excerpt";s:86:"Allow your customers to ship individual items in a single order to multiple addresses.";s:4:"link";s:121:"http://www.woothemes.com/products/shipping-multiple-addresses/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:13;O:8:"stdClass":5:{s:5:"title";s:37:"Role based payment / shipping methods";s:5:"image";s:0:"";s:7:"excerpt";s:67:"Limit different user roles to specific payment and shipping methods";s:4:"link";s:129:"http://www.woothemes.com/products/role-based-payment-shipping-methods/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:14;O:8:"stdClass":5:{s:5:"title";s:27:"Postcode/Address Validation";s:5:"image";s:0:"";s:7:"excerpt";s:104:"Simplify your checkout process by having your customer validate or lookup their address during checkout.";s:4:"link";s:120:"http://www.woothemes.com/products/postcodeaddress-validation/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:15;O:8:"stdClass":5:{s:5:"title";s:26:"Stamps.com XML File Export";s:5:"image";s:111:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/10/Screen-Shot-2012-10-10-at-17.05.22.png";s:7:"excerpt";s:132:"The WooCommerce Stamps.com extension allows you to select orders to export into an XML format for import into the Stamps.com client.";s:4:"link";s:120:"http://www.woothemes.com/products/stamps-com-xml-file-export/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:16;O:8:"stdClass":5:{s:5:"title";s:10:"Royal Mail";s:5:"image";s:86:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/04/royalmail.png";s:7:"excerpt";s:49:"Offer Royal Mail shipping rates to your customers";s:4:"link";s:104:"http://www.woothemes.com/products/royal-mail/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:17;O:8:"stdClass":5:{s:5:"title";s:22:"Flat Rate Box Shipping";s:5:"image";s:0:"";s:7:"excerpt";s:60:"Pack items into boxes with pre-defined costs per destination";s:4:"link";s:116:"http://www.woothemes.com/products/flat-rate-box-shipping/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:18;O:8:"stdClass":5:{s:5:"title";s:8:"Shipwire";s:5:"image";s:103:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/04/shipwire_logo_blue-310x100.png";s:7:"excerpt";s:152:"A full-featured Shipwire integration, including real-time shipping rates, automatic order fulfillment processing, and live inventory / tracking updates.";s:4:"link";s:102:"http://www.woothemes.com/products/shipwire/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:19;O:8:"stdClass":5:{s:5:"title";s:25:"Purolator Shipping Method";s:5:"image";s:81:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/08/puro.png";s:7:"excerpt";s:69:"Calculate order shipping costs automatically using the Purolator API.";s:4:"link";s:119:"http://www.woothemes.com/products/purolator-shipping-method/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:20;O:8:"stdClass":5:{s:5:"title";s:28:"SAPO Domestic Parcel Service";s:5:"image";s:61:"https://www.woothemes.com/wp-content/uploads/2012/09/sapo.jpg";s:7:"excerpt";s:28:"SAPO Domestic Parcel Service";s:4:"link";s:122:"http://www.woothemes.com/products/sapo-domestic-parcel-service/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:21;O:8:"stdClass":5:{s:5:"title";s:8:"Correios";s:5:"image";s:65:"https://www.woothemes.com/wp-content/uploads/2012/09/correios.jpg";s:7:"excerpt";s:33:"Correios shipping method (Brazil)";s:4:"link";s:102:"http://www.woothemes.com/products/correios/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:22;O:8:"stdClass":5:{s:5:"title";s:20:"USPS Shipping Method";s:5:"image";s:61:"https://www.woothemes.com/wp-content/uploads/2012/09/usps.jpg";s:7:"excerpt";s:91:"Get shipping rates from the USPS API which handles both domestic and international parcels.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=151085&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:23;O:8:"stdClass":5:{s:5:"title";s:33:"SAPO International Parcel Service";s:5:"image";s:60:"http://www.woothemes.com/wp-content/uploads/2012/09/sapo.jpg";s:7:"excerpt";s:33:"SAPO International parcel service";s:4:"link";s:127:"http://www.woothemes.com/products/sapo-international-parcel-service/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}}s:13:"import-export";a:12:{i:0;O:8:"stdClass":5:{s:5:"title";s:24:"Product CSV Import Suite";s:5:"image";s:0:"";s:7:"excerpt";s:91:"Import, merge, and export products and variations to and from WooCommerce using a CSV file.";s:4:"link";s:118:"http://www.woothemes.com/products/product-csv-import-suite/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;199.00";}i:1;O:8:"stdClass":5:{s:5:"title";s:25:"Order/Customer CSV Export";s:5:"image";s:0:"";s:7:"excerpt";s:69:"Export orders and customers from WooCommerce to a CSV file with ease.";s:4:"link";s:118:"http://www.woothemes.com/products/ordercustomer-csv-export/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:2;O:8:"stdClass":5:{s:5:"title";s:38:"Customer/Order/Coupon CSV Import Suite";s:5:"image";s:0:"";s:7:"excerpt";s:66:"Import both customers and orders into WooCommerce from a CSV file.";s:4:"link";s:124:"http://www.woothemes.com/products/customerorder-csv-import-suite/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:3;O:8:"stdClass":5:{s:5:"title";s:23:"ShipStation Integration";s:5:"image";s:88:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/08/shipstation.png";s:7:"excerpt";s:113:"ShipStation is a web-based shipping solution that streamlines the order fulfillment process for online retailers.";s:4:"link";s:117:"http://www.woothemes.com/products/shipstation-integration/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:4;O:8:"stdClass":5:{s:5:"title";s:19:"WPEC to WooCommerce";s:5:"image";s:84:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/09/wpec2wc.png";s:7:"excerpt";s:68:"Import product data from a WordPress eCommerce store to WooCommerce.";s:4:"link";s:113:"http://www.woothemes.com/products/wpec-to-woocommerce/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:5;O:8:"stdClass":5:{s:5:"title";s:26:"Stamps.com XML File Export";s:5:"image";s:111:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/10/Screen-Shot-2012-10-10-at-17.05.22.png";s:7:"excerpt";s:132:"The WooCommerce Stamps.com extension allows you to select orders to export into an XML format for import into the Stamps.com client.";s:4:"link";s:120:"http://www.woothemes.com/products/stamps-com-xml-file-export/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:6;O:8:"stdClass":5:{s:5:"title";s:31:"Customer/Order XML Export Suite";s:5:"image";s:0:"";s:7:"excerpt";s:100:"Easily export orders from your WooCommerce to XML and download or automatically upload them via FTP.";s:4:"link";s:124:"http://www.woothemes.com/products/customerorder-xml-export-suite/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;99.00";}i:7;O:8:"stdClass":5:{s:5:"title";s:23:"Jigoshop to WooCommerce";s:5:"image";s:82:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/09/js2wc.png";s:7:"excerpt";s:80:"Import your products from your old Jigoshop to your shiny new WooCommerce store.";s:4:"link";s:117:"http://www.woothemes.com/products/jigoshop-to-woocommerce/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:8;O:8:"stdClass":5:{s:5:"title";s:9:"Cart2Cart";s:5:"image";s:0:"";s:7:"excerpt";s:184:"Cart2Cart is a service which migrates product / customer / order data from many other eCommerce platforms into WooCommerce. Perfect if you\'re looking to make the switch to WooCommerce!";s:4:"link";s:103:"http://www.woothemes.com/products/cart2cart/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:9;O:8:"stdClass":5:{s:5:"title";s:7:"StoreYa";s:5:"image";s:0:"";s:7:"excerpt";s:159:"StoreYa.com is a leading F-commerce platform designed for automatically importing WooCommerce stores into Facebook taking full advantage of its social elements";s:4:"link";s:101:"http://www.woothemes.com/products/storeya/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:10;O:8:"stdClass":5:{s:5:"title";s:23:"PriceCheck Product Feed";s:5:"image";s:102:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/07/pricecheck-logo-woo-small.png";s:7:"excerpt";s:141:"The PriceCheck Product Feed extension allows you to easily configure the products you would like to display on your PriceCheck store profile.";s:4:"link";s:117:"http://www.woothemes.com/products/pricecheck-product-feed/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:11;O:8:"stdClass":5:{s:5:"title";s:25:"osCommerce to WooCommerce";s:5:"image";s:0:"";s:7:"excerpt";s:62:"Import product data from your osCommerce store to WooCommerce.";s:4:"link";s:119:"http://www.woothemes.com/products/oscommerce-to-woocommerce/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}}s:10:"accounting";a:18:{i:0;O:8:"stdClass":5:{s:5:"title";s:35:"Print Invoices &#038; Packing lists";s:5:"image";s:0:"";s:7:"excerpt";s:49:"Print your WooCommerce invoices and packing lists";s:4:"link";s:122:"http://www.woothemes.com/products/print-invoices-packing-lists/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:1;O:8:"stdClass":5:{s:5:"title";s:28:"Sequential Order Numbers Pro";s:5:"image";s:0:"";s:7:"excerpt";s:35:"Tame your WooCommerce Order Numbers";s:4:"link";s:122:"http://www.woothemes.com/products/sequential-order-numbers-pro/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:2;O:8:"stdClass":5:{s:5:"title";s:12:"PDF Invoices";s:5:"image";s:0:"";s:7:"excerpt";s:94:"Automatically create and attach a fully customizable PDF invoice to the completed order email.";s:4:"link";s:106:"http://www.woothemes.com/products/pdf-invoices/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:3;O:8:"stdClass":5:{s:5:"title";s:13:"EU VAT Number";s:5:"image";s:0:"";s:7:"excerpt";s:85:"Collect VAT numbers at checkout and remove the VAT charge for eligible EU businesses.";s:4:"link";s:107:"http://www.woothemes.com/products/eu-vat-number/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:4;O:8:"stdClass":5:{s:5:"title";s:18:"WooCommerce Zapier";s:5:"image";s:88:"http://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/09/zapier-logo1.png";s:7:"excerpt";s:110:"Send your WooCommerce store\'s data to 230+ third party web services using this extension and a Zapier account!";s:4:"link";s:112:"http://www.woothemes.com/products/woocommerce-zapier/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;59.00";}i:5;O:8:"stdClass":5:{s:5:"title";s:4:"Xero";s:5:"image";s:82:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/08/xero2.png";s:7:"excerpt";s:72:"Save time with automated sync between WooCommerce and your Xero account.";s:4:"link";s:98:"http://www.woothemes.com/products/xero/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:6;O:8:"stdClass":5:{s:5:"title";s:29:"Returns and Warranty Requests";s:5:"image";s:0:"";s:7:"excerpt";s:131:"Manage the RMA process, add warranties to products &amp; let customers request &amp; manage returns / exchanges from their account.";s:4:"link";s:111:"http://www.woothemes.com/products/warranty-requests/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:7;O:8:"stdClass":5:{s:5:"title";s:22:"WooCommerce FreshBooks";s:5:"image";s:67:"https://www.woothemes.com/wp-content/uploads/2012/09/freshbooks.png";s:7:"excerpt";s:50:"Integrate WooCommerce with your FreshBooks account";s:4:"link";s:116:"http://www.woothemes.com/products/woocommerce-freshbooks/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:8;O:8:"stdClass":5:{s:5:"title";s:22:"QuickBooks Integration";s:5:"image";s:0:"";s:7:"excerpt";s:64:"Sync orders, customers and inventory to your QuickBooks software";s:4:"link";s:110:"http://www.woothemes.com/?post_type=product&p=18658&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:9;O:8:"stdClass":5:{s:5:"title";s:23:"Authorize.net Reporting";s:5:"image";s:0:"";s:7:"excerpt";s:113:"This WooCommerce extension allows you to Get Daily Transaction Reports via Email for your Authorize.net account.";s:4:"link";s:129:"http://www.woothemes.com/products/woocommerce-authorize-net-reporting/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:10;O:8:"stdClass":5:{s:5:"title";s:14:"QuickBooks POS";s:5:"image";s:0:"";s:7:"excerpt";s:68:"Streamline your order and inventory management using QuickBooks POS.";s:4:"link";s:108:"http://www.woothemes.com/products/quickbooks-pos/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:11;O:8:"stdClass":5:{s:5:"title";s:21:"LinnWorks Integration";s:5:"image";s:83:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/11/lwlogo.png";s:7:"excerpt";s:113:"Order management and stock control system that integrates with multiple sale channels like eBay, Amazon, Magento.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=138577&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;99.00";}i:12;O:8:"stdClass":5:{s:5:"title";s:20:"US Export Compliance";s:5:"image";s:129:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/06/woothemes-woocommerce-us-export-ecommerce-compliance.jpg";s:7:"excerpt";s:119:"Increase comfort and security of your online transactions by making your shop compliant with the US Export regulations.";s:4:"link";s:114:"http://www.woothemes.com/products/us-export-compliance/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:13;O:8:"stdClass":5:{s:5:"title";s:31:"QuickBooks Cloud Cart Connector";s:5:"image";s:0:"";s:7:"excerpt";s:150:"Cloud Cart Connector syncs orders to QuickBooks Pro, Premier, Enterprise in the U.S. and QuickBooks Online in the U.S., Canada, and the U.K.

&nbsp;";s:4:"link";s:129:"http://www.woothemes.com/products/quickbooks-pro-cloud-cart-connector/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:14;O:8:"stdClass":5:{s:5:"title";s:13:"Smart Manager";s:5:"image";s:0:"";s:7:"excerpt";s:124:"Smart Manager is a unique, revolutionary tool that gives you the power to efficiently manage products, customers and orders.";s:4:"link";s:107:"http://www.woothemes.com/products/smart-manager/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;97.00";}i:15;O:8:"stdClass":5:{s:5:"title";s:9:"Q-Invoice";s:5:"image";s:99:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2014/06/q_invoice_large-300x75.jpg";s:7:"excerpt";s:296:"<span style="color: #555555;">Bookkeeping is equally as important as your sales, with q-invoice  </span><span style="color: #555555;">you can send professional looking invoices to your customers while at  </span><span style="color: #555555;">the same time updating your administration. </span>";s:4:"link";s:103:"http://www.woothemes.com/products/q-invoice/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:16;O:8:"stdClass":5:{s:5:"title";s:15:"Custom Statuses";s:5:"image";s:0:"";s:7:"excerpt";s:62:"This plugin allows you to create custom orders in WooCommerce.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120741&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:17;O:8:"stdClass":5:{s:5:"title";s:24:"Sequential Order Numbers";s:5:"image";s:0:"";s:7:"excerpt";s:105:"This plugin extends the WooCommerce e-commerce plugin by setting sequential order numbers for new orders.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120755&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}}s:9:"marketing";a:24:{i:0;O:8:"stdClass":5:{s:5:"title";s:15:"Product Bundles";s:5:"image";s:0:"";s:7:"excerpt";s:149:"Create and offer highly configurable product bundles, kits and assemblies that consist of simple and variable items - both physical and downloadable.";s:4:"link";s:109:"http://www.woothemes.com/products/product-bundles/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:1;O:8:"stdClass":5:{s:5:"title";s:13:"Smart Coupons";s:5:"image";s:0:"";s:7:"excerpt";s:93:"An "all in one" solution for gift certificates, store credits, discount coupons and vouchers.";s:4:"link";s:107:"http://www.woothemes.com/products/smart-coupons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;99.00";}i:2;O:8:"stdClass":5:{s:5:"title";s:16:"Follow up emails";s:5:"image";s:0:"";s:7:"excerpt";s:34:"Send follow-up emails to customers";s:4:"link";s:110:"http://www.woothemes.com/products/follow-up-emails/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;99.00";}i:3;O:8:"stdClass":5:{s:5:"title";s:23:"Newsletter Subscription";s:5:"image";s:0:"";s:7:"excerpt";s:127:"Allow customers to subscribe to your MailChimp or CampaignMonitor mailing list(s) via a widget or by opting in during checkout.";s:4:"link";s:117:"http://www.woothemes.com/products/newsletter-subscription/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:4;O:8:"stdClass":5:{s:5:"title";s:21:"WooCommerce Wishlists";s:5:"image";s:0:"";s:7:"excerpt";s:113:"WooCommerce Wishlists allows guests and customers to create and add products to an unlimited number of Wishlists.";s:4:"link";s:115:"http://www.woothemes.com/products/woocommerce-wishlists/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:5;O:8:"stdClass":5:{s:5:"title";s:19:"Google Product Feed";s:5:"image";s:0:"";s:7:"excerpt";s:151:"The Google Product Feed extension allows you to easily configure data to be added to your Google Merchant Centre feed and displayed on Google Shopping.";s:4:"link";s:113:"http://www.woothemes.com/products/google-product-feed/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:6;O:8:"stdClass":5:{s:5:"title";s:12:"Facebook Tab";s:5:"image";s:0:"";s:7:"excerpt";s:41:"Sell your products via your Facebook page";s:4:"link";s:106:"http://www.woothemes.com/products/facebook-tab/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:7;O:8:"stdClass":5:{s:5:"title";s:30:"WooCommerce Points and Rewards";s:5:"image";s:0:"";s:7:"excerpt";s:102:"Reward your customers for purchases and other actions with points which can be redeemed for discounts.";s:4:"link";s:124:"http://www.woothemes.com/products/woocommerce-points-and-rewards/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:8;O:8:"stdClass":5:{s:5:"title";s:12:"Cart Notices";s:5:"image";s:0:"";s:7:"excerpt";s:73:"Display dynamic, actionable messages to your customers as they check out.";s:4:"link";s:106:"http://www.woothemes.com/products/cart-notices/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:9;O:8:"stdClass":5:{s:5:"title";s:12:"Cart Add-ons";s:5:"image";s:0:"";s:7:"excerpt";s:109:"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart";s:4:"link";s:106:"http://www.woothemes.com/products/cart-add-ons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:10;O:8:"stdClass":5:{s:5:"title";s:18:"WooCommerce Zapier";s:5:"image";s:88:"http://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/09/zapier-logo1.png";s:7:"excerpt";s:110:"Send your WooCommerce store\'s data to 230+ third party web services using this extension and a Zapier account!";s:4:"link";s:112:"http://www.woothemes.com/products/woocommerce-zapier/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;59.00";}i:11;O:8:"stdClass":5:{s:5:"title";s:24:"WooCommerce Splash Popup";s:5:"image";s:0:"";s:7:"excerpt";s:135:"Alert people to latest offers, prompt them to sign up to newsletters or just deliver some important content to your visitors via popup.";s:4:"link";s:118:"http://www.woothemes.com/products/woocommerce-splash-popup/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:12;O:8:"stdClass":5:{s:5:"title";s:11:"URL Coupons";s:5:"image";s:0:"";s:7:"excerpt";s:140:"Add a unique URL to a coupon code that automatically applies a discount and (optionally) adds products to the customer&#039;s shopping cart.";s:4:"link";s:105:"http://www.woothemes.com/products/url-coupons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:13;O:8:"stdClass":5:{s:5:"title";s:12:"Store Credit";s:5:"image";s:0:"";s:7:"excerpt";s:152:"Generate store credit coupons that enable customers to make multiple purchases until the total value specified is exhausted or the coupons life expires.";s:4:"link";s:106:"http://www.woothemes.com/products/store-credit/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:14;O:8:"stdClass":5:{s:5:"title";s:19:"Review for Discount";s:5:"image";s:0:"";s:7:"excerpt";s:43:"Reward your reviewers with discount coupons";s:4:"link";s:113:"http://www.woothemes.com/products/review-for-discount/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:15;O:8:"stdClass":5:{s:5:"title";s:31:"WooCommerce Conditional Content";s:5:"image";s:0:"";s:7:"excerpt";s:87:"Allows you to display content on your store based on a set of rules that you configure.";s:4:"link";s:125:"http://www.woothemes.com/products/woocommerce-conditional-content/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:16;O:8:"stdClass":5:{s:5:"title";s:30:"Aweber Newsletter Subscription";s:5:"image";s:0:"";s:7:"excerpt";s:53:"Allow customers to opt-in to your AWeber mailing list";s:4:"link";s:124:"http://www.woothemes.com/products/aweber-newsletter-subscription/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:17;O:8:"stdClass":5:{s:5:"title";s:17:"Product Documents";s:5:"image";s:0:"";s:7:"excerpt";s:158:"Give customers access to product documentation and help reduce barriers to purchase. Or just give you a slick way to display product information to customers.";s:4:"link";s:111:"http://www.woothemes.com/products/product-documents/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:18;O:8:"stdClass":5:{s:5:"title";s:17:"Product Retailers";s:5:"image";s:0:"";s:7:"excerpt";s:102:"Allow customers to purchase external products directly on your site, or from a selection of retailers.";s:4:"link";s:111:"http://www.woothemes.com/products/product-retailers/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:19;O:8:"stdClass":5:{s:5:"title";s:24:"Twilio SMS Notifications";s:5:"image";s:0:"";s:7:"excerpt";s:127:"Send SMS updates to customers when their order status is updated and receive an SMS message when a customer places a new order.";s:4:"link";s:118:"http://www.woothemes.com/products/twilio-sms-notifications/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:20;O:8:"stdClass":5:{s:5:"title";s:13:"Account Funds";s:5:"image";s:0:"";s:7:"excerpt";s:122:"Account Funds will allow your customers to deposit funds into their accounts for which you can reward them with discounts.";s:4:"link";s:107:"http://www.woothemes.com/products/account-funds/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:21;O:8:"stdClass":5:{s:5:"title";s:21:"WooCommerce Instagram";s:5:"image";s:0:"";s:7:"excerpt";s:101:"With the Instagram extension, showcasing how customers are using your products has never been easier.";s:4:"link";s:115:"http://www.woothemes.com/products/woocommerce-instagram/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:22;O:8:"stdClass":5:{s:5:"title";s:14:"Sale Flash Pro";s:5:"image";s:0:"";s:7:"excerpt";s:113:"Further incentivise sales at your store by displaying a % or total discount on product archive and details pages.";s:4:"link";s:108:"http://www.woothemes.com/products/sale-flash-pro/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:23;O:8:"stdClass":5:{s:5:"title";s:13:"Limited Deals";s:5:"image";s:0:"";s:7:"excerpt";s:115:"Offer expiring deals to your customers and optionally display order totals &amp; savings via a stylish css3 banner.";s:4:"link";s:107:"http://www.woothemes.com/products/limited-deals/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}}s:7:"product";a:24:{i:0;O:8:"stdClass":5:{s:5:"title";s:15:"Product Add-ons";s:5:"image";s:0:"";s:7:"excerpt";s:110:"Allow your customers to customise your products by adding input boxes, dropdowns or a field set of checkboxes.";s:4:"link";s:109:"http://www.woothemes.com/products/product-add-ons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:1;O:8:"stdClass":5:{s:5:"title";s:15:"Dynamic Pricing";s:5:"image";s:0:"";s:7:"excerpt";s:48:"Bulk discounts, role-based pricing and much more";s:4:"link";s:109:"http://www.woothemes.com/products/dynamic-pricing/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:2;O:8:"stdClass":5:{s:5:"title";s:21:"Gravity Forms Add-ons";s:5:"image";s:0:"";s:7:"excerpt";s:39:"Powerful product add-ons, Gravity style";s:4:"link";s:115:"http://www.woothemes.com/products/gravity-forms-add-ons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;99.00";}i:3;O:8:"stdClass":5:{s:5:"title";s:15:"Product Bundles";s:5:"image";s:0:"";s:7:"excerpt";s:149:"Create and offer highly configurable product bundles, kits and assemblies that consist of simple and variable items - both physical and downloadable.";s:4:"link";s:109:"http://www.woothemes.com/products/product-bundles/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:4;O:8:"stdClass":5:{s:5:"title";s:22:"Groups for WooCommerce";s:5:"image";s:0:"";s:7:"excerpt";s:94:"Sell memberships using the free &#039;Groups&#039; plugin, Groups integration and WooCommerce.";s:4:"link";s:112:"http://www.woothemes.com/products/groups-woocommerce/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:5;O:8:"stdClass":5:{s:5:"title";s:29:"Variation Swatches and Photos";s:5:"image";s:0:"";s:7:"excerpt";s:73:"Show color and image swatches instead of dropdowns for variable products.";s:4:"link";s:123:"http://www.woothemes.com/products/variation-swatches-and-photos/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;99.00";}i:6;O:8:"stdClass":5:{s:5:"title";s:22:"WooCommerce TradeGecko";s:5:"image";s:87:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/09/tradegecko.png";s:7:"excerpt";s:105:"Enhance your business backend with advanced inventory and order management connected to your WooCommerce.";s:4:"link";s:116:"http://www.woothemes.com/products/woocommerce-tradegecko/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:7;O:8:"stdClass":5:{s:5:"title";s:18:"Min/Max Quantities";s:5:"image";s:0:"";s:7:"excerpt";s:82:"Specify minimum and maximum allowed product quantities for orders to be completed.";s:4:"link";s:111:"http://www.woothemes.com/products/minmax-quantities/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:8;O:8:"stdClass":5:{s:5:"title";s:6:"Brands";s:5:"image";s:0:"";s:7:"excerpt";s:84:"Create, assign and list brands for products, and allow customers to filter by brand.";s:4:"link";s:100:"http://www.woothemes.com/products/brands/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:9;O:8:"stdClass":5:{s:5:"title";s:15:"Name your price";s:5:"image";s:0:"";s:7:"excerpt";s:90:"Allow customers to define the product price. Also useful for accepting user-set donations.";s:4:"link";s:109:"http://www.woothemes.com/products/name-your-price/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:10;O:8:"stdClass":5:{s:5:"title";s:22:"Advanced Notifications";s:5:"image";s:0:"";s:7:"excerpt";s:96:"Easily setup "new order" and stock email notifications for multiple recipients of your choosing.";s:4:"link";s:116:"http://www.woothemes.com/products/advanced-notifications/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:11;O:8:"stdClass":5:{s:5:"title";s:15:"Product Vendors";s:5:"image";s:0:"";s:7:"excerpt";s:82:"Turn your store into a multi-vendor marketplace (such as Etsy or Creative Market).";s:4:"link";s:109:"http://www.woothemes.com/products/product-vendors/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:12;O:8:"stdClass":5:{s:5:"title";s:18:"Composite Products";s:5:"image";s:0:"";s:7:"excerpt";s:100:"Build dynamic, complex product kits and build-to-order assemblies by compositing existing products. ";s:4:"link";s:112:"http://www.woothemes.com/products/composite-products/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:13;O:8:"stdClass":5:{s:5:"title";s:20:"WooCommerce Waitlist";s:5:"image";s:0:"";s:7:"excerpt";s:117:"With WooCommerce Waitlist customers can register for email notifications when out-of-stock products become available.";s:4:"link";s:114:"http://www.woothemes.com/products/woocommerce-waitlist/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:14;O:8:"stdClass":5:{s:5:"title";s:22:"WooCommerce Pre-Orders";s:5:"image";s:0:"";s:7:"excerpt";s:60:"Allow customers to order products before they are available.";s:4:"link";s:116:"http://www.woothemes.com/products/woocommerce-pre-orders/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:15;O:8:"stdClass":5:{s:5:"title";s:10:"Cloud Zoom";s:5:"image";s:0:"";s:7:"excerpt";s:146:"Using the popular Cloud Zoom plugin for jQuery, users can zoom into your product photos by simply mousing over them with this intuitive extension.";s:4:"link";s:104:"http://www.woothemes.com/products/cloud-zoom/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:16;O:8:"stdClass":5:{s:5:"title";s:16:"Chained Products";s:5:"image";s:0:"";s:7:"excerpt";s:30:"Create and sell product combos";s:4:"link";s:110:"http://www.woothemes.com/products/chained-products/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:17;O:8:"stdClass":5:{s:5:"title";s:28:"Measurement Price Calculator";s:5:"image";s:0:"";s:7:"excerpt";s:109:"Add a calculator to your product pages to calculate the product quantity required by square footage and more.";s:4:"link";s:122:"http://www.woothemes.com/products/measurement-price-calculator/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:18;O:8:"stdClass":5:{s:5:"title";s:20:"Product Enquiry Form";s:5:"image";s:0:"";s:7:"excerpt";s:127:"Allow visitors to contact you directly from the product details page via a reCAPTCHA protected form to enquire about a product.";s:4:"link";s:114:"http://www.woothemes.com/products/product-enquiry-form/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:19;O:8:"stdClass":5:{s:5:"title";s:22:"WooCommerce Quick View";s:5:"image";s:0:"";s:7:"excerpt";s:83:"Show a quick-view button to view product details and add to cart via lightbox popup";s:4:"link";s:116:"http://www.woothemes.com/products/woocommerce-quick-view/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:20;O:8:"stdClass":5:{s:5:"title";s:21:"Bulk Stock Management";s:5:"image";s:0:"";s:7:"excerpt";s:72:"Edit product and variation stock levels in bulk via this handy interface";s:4:"link";s:115:"http://www.woothemes.com/products/bulk-stock-management/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:21;O:8:"stdClass":5:{s:5:"title";s:14:"Product Finder";s:5:"image";s:0:"";s:7:"excerpt";s:133:"Allows your users to search your site more thoroughly by giving you the ability to add an in-depth advanced search form to your site.";s:4:"link";s:108:"http://www.woothemes.com/products/product-finder/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:22;O:8:"stdClass":5:{s:5:"title";s:23:"Product Image Watermark";s:5:"image";s:0:"";s:7:"excerpt";s:37:"Add watermarks to your product images";s:4:"link";s:117:"http://www.woothemes.com/products/product-image-watermark/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:23;O:8:"stdClass":5:{s:5:"title";s:20:"PDF Product Vouchers";s:5:"image";s:0:"";s:7:"excerpt";s:57:"Customize and sell downloadable PDF vouchers for products";s:4:"link";s:114:"http://www.woothemes.com/products/pdf-product-vouchers/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}}s:4:"free";a:24:{i:0;O:8:"stdClass":5:{s:5:"title";s:15:"Pay with Amazon";s:5:"image";s:116:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/08/AP_HLogo_215x35-3012530377._V360408447_.png";s:7:"excerpt";s:153:"Pay with Amazon is embedded directly into your WooCommerce store. Buyer interactions take place in embedded widgets, so the buyer never leaves your site.";s:4:"link";s:109:"http://www.woothemes.com/products/pay-with-amazon/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:1;O:8:"stdClass":5:{s:5:"title";s:23:"PayFast Payment Gateway";s:5:"image";s:72:"https://www.woothemes.com/wp-content/uploads/2013/09/PayFast_Logo_75.png";s:7:"excerpt";s:70:"Take payments on your WooCommerce store via PayFast (redirect method).";s:4:"link";s:117:"http://www.woothemes.com/products/payfast-payment-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:2;O:8:"stdClass":5:{s:5:"title";s:11:"PayJunction";s:5:"image";s:68:"https://www.woothemes.com/wp-content/uploads/2012/09/payjunction.jpg";s:7:"excerpt";s:108:"Accept all major brands with the PayJunction service: Visa, MasterCard, American Express, Discover and more.";s:4:"link";s:110:"http://www.woothemes.com/?post_type=product&p=18656&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:3;O:8:"stdClass":5:{s:5:"title";s:24:"Accepted Payment Methods";s:5:"image";s:0:"";s:7:"excerpt";s:93:"Allows you to display which payment methods you accept via widget, shortcode or template tag.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=135051&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:4;O:8:"stdClass":5:{s:5:"title";s:16:"Smart Sale Badge";s:5:"image";s:0:"";s:7:"excerpt";s:91:"Enhances the WooCommerce sale badge by displaying the total saving a customer will receive.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=196635&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:5;O:8:"stdClass":5:{s:5:"title";s:8:"PayStand";s:5:"image";s:79:"https://www.woothemes.com/wp-content/uploads/2014/09/PayStand_Logo-Lg-white.jpg";s:7:"excerpt";s:228:"PayStand is the first fair payment gateway- charging you a monthly subscription and passing on wholesale rates from VISA and the banks to you. Pay 2.69% on every Credit Card, $0.25 for Bank Transfers, and nothing for Bitcoin.";s:4:"link";s:102:"http://www.woothemes.com/products/paystand/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:6;O:8:"stdClass":5:{s:5:"title";s:24:"Sold Out Products Widget";s:5:"image";s:0:"";s:7:"excerpt";s:86:"Extends WooCommerce by adding a widget and shortcode for displaying sold out products.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=197567&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:7;O:8:"stdClass":5:{s:5:"title";s:16:"CCAvenue Gateway";s:5:"image";s:0:"";s:7:"excerpt";s:125:"This is the CCAvenue payment gateway for WooCommerce. Allows you to use CCAvenue payment gateway with the WooCommerce plugin.";s:4:"link";s:110:"http://www.woothemes.com/products/ccavenue-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:8;O:8:"stdClass":5:{s:5:"title";s:17:"Coupon Shortcodes";s:5:"image";s:0:"";s:7:"excerpt";s:140:"Show coupon discount info using shortcodes. Allows to render coupon information and content conditionally, based on the validity of coupons.";s:4:"link";s:111:"http://www.woothemes.com/products/coupon-shortcodes/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:9;O:8:"stdClass":5:{s:5:"title";s:23:"Inspire Payment Gateway";s:5:"image";s:85:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/11/logo.200.png";s:7:"excerpt";s:145:"Inspire Commerce is the all-in-one solution that allows you to turn your beautiful WooCommerce backed shopping experience into a selling machine.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=138175&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:10;O:8:"stdClass":5:{s:5:"title";s:7:"Mijireh";s:5:"image";s:69:"https://www.woothemes.com/wp-content/uploads/2014/09/mijireh-logo.png";s:7:"excerpt";s:209:"Over 80 payment gateways included for free. Mijireh Checkout is a secure, PCI compliant hosted checkout page that looks exactly like the rest of your site. You don&#039;t even need your own SSL Certificate.";s:4:"link";s:101:"http://www.woothemes.com/products/mijireh/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:11;O:8:"stdClass":5:{s:5:"title";s:18:"Grid / List Toggle";s:5:"image";s:0:"";s:7:"excerpt";s:136:"Adds a Grid / List toggle to your product archives allowing users to, you guessed it, toggle between grid / list views of your products.";s:4:"link";s:110:"http://www.woothemes.com/products/grid-list-toggle/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:12;O:8:"stdClass":5:{s:5:"title";s:26:"Product Archive Customiser";s:5:"image";s:0:"";s:7:"excerpt";s:53:"Allows you to customise WooCommerce product archives.";s:4:"link";s:120:"http://www.woothemes.com/products/product-archive-customiser/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:13;O:8:"stdClass":5:{s:5:"title";s:25:"Postgiro/Bankgiro gateway";s:5:"image";s:0:"";s:7:"excerpt";s:136:"Adds a new payment gateway to WooCommerce, there you are available to add Postgiro number and Bankgiro number (Swedish payment methods).";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120749&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:14;O:8:"stdClass":5:{s:5:"title";s:18:"Photos Product Tab";s:5:"image";s:0:"";s:7:"excerpt";s:108:"Allows you to display all the images you have attached to a product in a new tab on the single product page.";s:4:"link";s:112:"http://www.woothemes.com/products/photos-product-tab/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:15;O:8:"stdClass":5:{s:5:"title";s:27:"PayJunction Payment Gateway";s:5:"image";s:68:"https://www.woothemes.com/wp-content/uploads/2012/09/payjunction.jpg";s:7:"excerpt";s:108:"Accept all major brands with the PayJunction service: Visa, MasterCard, American Express, Discover and more.";s:4:"link";s:121:"http://www.woothemes.com/products/payjunction-payment-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:16;O:8:"stdClass":5:{s:5:"title";s:9:"Piggy Pro";s:5:"image";s:0:"";s:7:"excerpt";s:137:"Piggy is an awesome, mobile web app that taps straight into WooCommerce and gives you your latest sales data on your mobile in real-time.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120727&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:17;O:8:"stdClass":5:{s:5:"title";s:27:"Total Web Solutions Gateway";s:5:"image";s:93:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/05/tws-secure-clear.png";s:7:"excerpt";s:52:"Total Web Solutions payment gateway for WooCommerce.";s:4:"link";s:121:"http://www.woothemes.com/products/total-web-solutions-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:18;O:8:"stdClass":5:{s:5:"title";s:14:"Delivery Notes";s:5:"image";s:0:"";s:7:"excerpt";s:150:"Print order invoices &amp; delivery notes for WooCommerce shop. You can add company/shop info as well as personal notes &amp; policies to print pages.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120750&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:19;O:8:"stdClass":5:{s:5:"title";s:16:"Putler Connector";s:5:"image";s:0:"";s:7:"excerpt";s:131:"Connect WooCommerce with Putler - the best sales analytics app. Synchronize orders and instantly get X-ray vision on your business!";s:4:"link";s:110:"http://www.woothemes.com/products/putler-connector/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:20;O:8:"stdClass":5:{s:5:"title";s:15:"Paysius Gateway";s:5:"image";s:0:"";s:7:"excerpt";s:151:"A merchant solution which uses cutting-edge Bitcoin technology to give merchants zero risk of chargeback and lower fees than with conventional systems.";s:4:"link";s:109:"http://www.woothemes.com/products/paysius-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:21;O:8:"stdClass":5:{s:5:"title";s:17:"Product Video Tab";s:5:"image";s:0:"";s:7:"excerpt";s:111:"Easily add a unique video tab to your product pages. Perfect if you have video demonstrations of your products.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120728&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:22;O:8:"stdClass":5:{s:5:"title";s:26:"Product Details Customiser";s:5:"image";s:0:"";s:7:"excerpt";s:132:"Customise WooCommerce product details pages. Show / Hide core components like product imagery, tabs, upsells &amp; related products.";s:4:"link";s:120:"http://www.woothemes.com/products/product-details-customiser/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:23;O:8:"stdClass":5:{s:5:"title";s:15:"Genesis Connect";s:5:"image";s:0:"";s:7:"excerpt";s:111:"This plugin allows you to seamlessly integrate WooCommerce with the Genesis Framework and Genesis child themes.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120752&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}}s:11:"third-party";a:95:{i:0;O:8:"stdClass":5:{s:5:"title";s:7:"Mijireh";s:5:"image";s:69:"https://www.woothemes.com/wp-content/uploads/2014/09/mijireh-logo.png";s:7:"excerpt";s:209:"Over 80 payment gateways included for free. Mijireh Checkout is a secure, PCI compliant hosted checkout page that looks exactly like the rest of your site. You don&#039;t even need your own SSL Certificate.";s:4:"link";s:101:"http://www.woothemes.com/products/mijireh/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:1;O:8:"stdClass":5:{s:5:"title";s:9:"FuturePay";s:5:"image";s:72:"https://www.woothemes.com/wp-content/uploads/2014/09/logoFuturePay-1.png";s:7:"excerpt";s:0:"";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=501148&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:2;O:8:"stdClass":5:{s:5:"title";s:8:"PayStand";s:5:"image";s:79:"https://www.woothemes.com/wp-content/uploads/2014/09/PayStand_Logo-Lg-white.jpg";s:7:"excerpt";s:228:"PayStand is the first fair payment gateway- charging you a monthly subscription and passing on wholesale rates from VISA and the banks to you. Pay 2.69% on every Credit Card, $0.25 for Bank Transfers, and nothing for Bitcoin.";s:4:"link";s:102:"http://www.woothemes.com/products/paystand/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:3;O:8:"stdClass":5:{s:5:"title";s:8:"OrderCup";s:5:"image";s:74:"https://www.woothemes.com/wp-content/uploads/2014/08/ordercup_woo_logo.png";s:7:"excerpt";s:169:"<p class="p1">Print Shipping Labels with 1 click. USPS, FedEx, UPS, DHL, Canada Post.  Up to 70% off on USPS and DHL rates. Fully web based. Ship from any Country!</p>";s:4:"link";s:102:"http://www.woothemes.com/products/ordercup/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:4;O:8:"stdClass":5:{s:5:"title";s:9:"PayVector";s:5:"image";s:66:"https://www.woothemes.com/wp-content/uploads/2014/08/payvector.png";s:7:"excerpt";s:174:"<p class="p1">PayVector is an online payment gateway which includes free comprehensive reporting, fraud suite, tokenisation, recurring payments and PayByLink as standard.</p>";s:4:"link";s:103:"http://www.woothemes.com/products/payvector/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:5;O:8:"stdClass":5:{s:5:"title";s:22:"OSI Affiliate Software";s:5:"image";s:94:"https://www.woothemes.com/wp-content/uploads/2014/08/affiliate-software-press-kit-logo-big.png";s:7:"excerpt";s:261:"<p class="p1">OSI Affiliate Software helps you to set up an affiliate program for your eCommerce store. An affiliate program or referral program gets you more traffic, leads, and sales by working with other marketers to promote your store. Try for Free Now!</p>";s:4:"link";s:116:"http://www.woothemes.com/products/osi-affiliate-software/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:6;O:8:"stdClass":5:{s:5:"title";s:14:"InstantSearch+";s:5:"image";s:91:"https://www.woothemes.com/wp-content/uploads/2014/08/instantsearchplus_360x60_woothemes.png";s:7:"excerpt";s:114:"Add the fastest, most advanced, cloud-based search to your WooCommerce store, and see your conversion rates go up.";s:4:"link";s:107:"http://www.woothemes.com/products/instantsearch/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:7;O:8:"stdClass":5:{s:5:"title";s:10:"SendinBlue";s:5:"image";s:67:"https://www.woothemes.com/wp-content/uploads/2014/08/sendinblue.png";s:7:"excerpt";s:245:"<p class="p1">SendinBlue is an email marketing software that let you easily manage your email marketing campaigns, transactional emails and SMS messages, all in one simple and powerful platform. Starting from $7.37 for 40 000 emails / month.</p>";s:4:"link";s:104:"http://www.woothemes.com/products/sendinblue/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:8;O:8:"stdClass":5:{s:5:"title";s:9:"netParcel";s:5:"image";s:94:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2014/08/netparcel_cropped.png";s:7:"excerpt";s:170:"<p style="color: #666666;">Save up to 70% on Small Parcel and LTL Freight. Import orders and schedule pick-ups for UPS, FedEx, Purolator, DHL, Con-Way, YRC, and more!</p>";s:4:"link";s:103:"http://www.woothemes.com/products/netparcel/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:9;O:8:"stdClass":5:{s:5:"title";s:14:"Spark Shipping";s:5:"image";s:114:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2014/08/Screen-Shot-2014-08-04-at-11.07.47-AM.png";s:7:"excerpt";s:219:"eCommerce automation for dropshippers. As orders are created immediately send them to vendors &amp; manufacturers. Always keep your inventory up to date by automatically synchronizing your inventory with your vendor\'s.";s:4:"link";s:108:"http://www.woothemes.com/products/spark-shipping/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:10;O:8:"stdClass":5:{s:5:"title";s:6:"Ordoro";s:5:"image";s:70:"https://www.woothemes.com/wp-content/uploads/2014/08/ordoro_logo_f.png";s:7:"excerpt";s:156:"<p class="p1">Get access to the lowest shipping rates in the industry. Manage all your WooCommerce and Amazon/eBay/Etsy accounts, together in one place.</p>";s:4:"link";s:100:"http://www.woothemes.com/products/ordoro/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:11;O:8:"stdClass":5:{s:5:"title";s:36:"WooCommerce Gateways Country Limiter";s:5:"image";s:0:"";s:7:"excerpt";s:150:"<p class="p1">This extension lets you choose which payment gateways to display for different countries, as determined by the customer’s address.</p>";s:4:"link";s:98:"http://www.woothemes.com/products/wpml/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;39.00";}i:12;O:8:"stdClass":5:{s:5:"title";s:15:"Live Sales Feed";s:5:"image";s:0:"";s:7:"excerpt";s:183:"<span style="color: #444444;">Marketing your WooCommerce store was never so easy before. Live Sales Feed will display the latest orders placed on your website to your visitors.</span>";s:4:"link";s:109:"http://www.woothemes.com/products/live-sales-feed/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;13.00";}i:13;O:8:"stdClass":5:{s:5:"title";s:9:"Q-Invoice";s:5:"image";s:99:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2014/06/q_invoice_large-300x75.jpg";s:7:"excerpt";s:296:"<span style="color: #555555;">Bookkeeping is equally as important as your sales, with q-invoice  </span><span style="color: #555555;">you can send professional looking invoices to your customers while at  </span><span style="color: #555555;">the same time updating your administration. </span>";s:4:"link";s:103:"http://www.woothemes.com/products/q-invoice/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:14;O:8:"stdClass":5:{s:5:"title";s:13:"Social Rebate";s:5:"image";s:0:"";s:7:"excerpt";s:120:"An innovative e-commerce solution that converts your customers’ purchases into highly credible Social Media Marketing.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=434026&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:15;O:8:"stdClass":5:{s:5:"title";s:11:"AffiliateWP";s:5:"image";s:81:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2014/04/logo.png";s:7:"excerpt";s:127:"A complete affiliate management system for WooCommerce built directly into your WordPress dashboard for a seamless integration.";s:4:"link";s:105:"http://www.woothemes.com/products/affiliatewp/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:16;O:8:"stdClass":5:{s:5:"title";s:10:"AppPresser";s:5:"image";s:93:"https://www.woothemes.com/wp-content/uploads/2014/04/85AFF89A-5411-47AD-A1FF-4F026A5A5C11.png";s:7:"excerpt";s:212:"AppPresser turns your existing WooCommerce store into a mobile app with no custom coding. This is the easiest and most affordable way to allow your customers to purchase your products through a native mobile app.";s:4:"link";s:104:"http://www.woothemes.com/products/apppresser/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;249.00";}i:17;O:8:"stdClass":5:{s:5:"title";s:5:"Veeqo";s:5:"image";s:70:"https://www.woothemes.com/wp-content/uploads/2014/04/veeqo-cropped.png";s:7:"excerpt";s:201:"Manage all your inventory and orders in one place, we import all your orders from WooCommerce automatically so you can bulk print shipping labels/invoices/packing slips plus we integrate with couriers.";s:4:"link";s:99:"http://www.woothemes.com/products/veeqo/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:18;O:8:"stdClass":5:{s:5:"title";s:14:"Quick Checkout";s:5:"image";s:0:"";s:7:"excerpt";s:115:"Add single page checkout forms anywhere on your WooCommerce powered website quickly and easily with Quick Checkout.";s:4:"link";s:108:"http://www.woothemes.com/products/quick-checkout/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;76.00";}i:19;O:8:"stdClass":5:{s:5:"title";s:10:"Coupon Pop";s:5:"image";s:86:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2014/04/couponpop.png";s:7:"excerpt";s:127:"Boost your website conversion rate and increase your fan base and email lists by popping up special discounts to your visitors!";s:4:"link";s:104:"http://www.woothemes.com/products/coupon-pop/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:20;O:8:"stdClass":5:{s:5:"title";s:25:"osCommerce to WooCommerce";s:5:"image";s:0:"";s:7:"excerpt";s:62:"Import product data from your osCommerce store to WooCommerce.";s:4:"link";s:119:"http://www.woothemes.com/products/oscommerce-to-woocommerce/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:21;O:8:"stdClass":5:{s:5:"title";s:19:"SEO Friendly Images";s:5:"image";s:0:"";s:7:"excerpt";s:135:"Automatically optimize product images by adding alt &amp; title attributes. Features include nicer image previews &amp; images sitemap.";s:4:"link";s:113:"http://www.woothemes.com/products/seo-friendly-images/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;179.00";}i:22;O:8:"stdClass":5:{s:5:"title";s:31:"QuickBooks Cloud Cart Connector";s:5:"image";s:0:"";s:7:"excerpt";s:150:"Cloud Cart Connector syncs orders to QuickBooks Pro, Premier, Enterprise in the U.S. and QuickBooks Online in the U.S., Canada, and the U.K.

&nbsp;";s:4:"link";s:129:"http://www.woothemes.com/products/quickbooks-pro-cloud-cart-connector/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:23;O:8:"stdClass":5:{s:5:"title";s:21:"Roost for WooCommerce";s:5:"image";s:87:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2014/02/roost-logo.png";s:7:"excerpt";s:123:"Send push notifications to your customers, notifying them of abandoned carts, promotional offers or any message you\'d like.";s:4:"link";s:115:"http://www.woothemes.com/products/roost-for-woocommerce/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:24;O:8:"stdClass":5:{s:5:"title";s:25:"WooCommerce Opening Hours";s:5:"image";s:0:"";s:7:"excerpt";s:135:"Adds opening/closing times. Ideal for timed delivery, restaurants &amp; anyone else who wants to allow customer choice of a order time.";s:4:"link";s:119:"http://www.woothemes.com/products/woocommerce-opening-hours/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:25;O:8:"stdClass":5:{s:5:"title";s:12:"ReadyShipper";s:5:"image";s:113:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2014/02/Screen-Shot-2014-02-06-at-2.35.04-PM.png";s:7:"excerpt";s:159:"Looking for a better shipping solution? ReadyShipper makes shipping all your WC orders a breeze. See why thousands of merchants use it for FedEx, UPS and USPS.";s:4:"link";s:106:"http://www.woothemes.com/products/readyshipper/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:26;O:8:"stdClass":5:{s:5:"title";s:11:"AddShoppers";s:5:"image";s:113:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2014/02/Screen-Shot-2014-02-06-at-1.55.28-PM.png";s:7:"excerpt";s:153:"AddShoppers helps you easily drive more social shares and sales with apps like Sharing Buttons, Social Rewards, Purchase Sharing, and Social Retargeting.";s:4:"link";s:105:"http://www.woothemes.com/products/addshoppers/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:27;O:8:"stdClass":5:{s:5:"title";s:16:"Putler Connector";s:5:"image";s:0:"";s:7:"excerpt";s:131:"Connect WooCommerce with Putler - the best sales analytics app. Synchronize orders and instantly get X-ray vision on your business!";s:4:"link";s:110:"http://www.woothemes.com/products/putler-connector/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:28;O:8:"stdClass":5:{s:5:"title";s:18:"Photos Product Tab";s:5:"image";s:0:"";s:7:"excerpt";s:108:"Allows you to display all the images you have attached to a product in a new tab on the single product page.";s:4:"link";s:112:"http://www.woothemes.com/products/photos-product-tab/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:29;O:8:"stdClass":5:{s:5:"title";s:26:"Email Cart for WooCommerce";s:5:"image";s:0:"";s:7:"excerpt";s:102:"Send a pre-populated WooCommerce Cart to a customer’s email address, ready and waiting for checkout.";s:4:"link";s:120:"http://www.woothemes.com/products/email-cart-for-woocommerce/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;15.00";}i:30;O:8:"stdClass":5:{s:5:"title";s:17:"Coupon Shortcodes";s:5:"image";s:0:"";s:7:"excerpt";s:140:"Show coupon discount info using shortcodes. Allows to render coupon information and content conditionally, based on the validity of coupons.";s:4:"link";s:111:"http://www.woothemes.com/products/coupon-shortcodes/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:31;O:8:"stdClass":5:{s:5:"title";s:15:"WooCommerce SEO";s:5:"image";s:0:"";s:7:"excerpt";s:104:"Want to make your WooCommerce store integrate seamlessly with WordPress SEO? This is the plugin to have.";s:4:"link";s:109:"http://www.woothemes.com/products/woocommerce-seo/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;29.00";}i:32;O:8:"stdClass":5:{s:5:"title";s:20:"FetchApp integration";s:5:"image";s:0:"";s:7:"excerpt";s:88:"Provides integration between the FetchApp digital delivery application and WooCommerce.";s:4:"link";s:114:"http://www.woothemes.com/products/fetchapp-integration/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:33;O:8:"stdClass":5:{s:5:"title";s:29:"WooCommerce Custom Currencies";s:5:"image";s:0:"";s:7:"excerpt";s:107:"Add your currency to list of supported currencies in WooCommerce or edit an existing one\'s symbol or label.";s:4:"link";s:123:"http://www.woothemes.com/products/woocommerce-custom-currencies/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:34;O:8:"stdClass":5:{s:5:"title";s:23:"PriceCheck Product Feed";s:5:"image";s:102:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/07/pricecheck-logo-woo-small.png";s:7:"excerpt";s:141:"The PriceCheck Product Feed extension allows you to easily configure the products you would like to display on your PriceCheck store profile.";s:4:"link";s:117:"http://www.woothemes.com/products/pricecheck-product-feed/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:35;O:8:"stdClass":5:{s:5:"title";s:11:"HTML5 Video";s:5:"image";s:0:"";s:7:"excerpt";s:137:"Add videos to your products. This WooCommerce extension uses HTML5 to render videos. It supports embedded videos and MP4 and Ogg formats.";s:4:"link";s:105:"http://www.woothemes.com/products/html5-video/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:36;O:8:"stdClass":5:{s:5:"title";s:20:"Yotpo Social Reviews";s:5:"image";s:82:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/07/Yotpo.png";s:7:"excerpt";s:117:"Build your shoppers confidence with trustworthy reviews. Yotpo is free and getting started takes less than 5 minutes.";s:4:"link";s:114:"http://www.woothemes.com/products/yotpo-social-reviews/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:37;O:8:"stdClass":5:{s:5:"title";s:18:"Order Notes Window";s:5:"image";s:0:"";s:7:"excerpt";s:129:"Overrides the default behaviour when clicking on Order notes button so that modal window with order notes is displayed instantly.";s:4:"link";s:112:"http://www.woothemes.com/products/order-notes-window/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:38;O:8:"stdClass":5:{s:5:"title";s:16:"Novalnet Gateway";s:5:"image";s:0:"";s:7:"excerpt";s:80:"Take payment via Novalnet Payment Solutions Worldwide on your WooCommerce store.";s:4:"link";s:110:"http://www.woothemes.com/products/novalnet-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:39;O:8:"stdClass":5:{s:5:"title";s:20:"Order Status Control";s:5:"image";s:0:"";s:7:"excerpt";s:80:"Automatically change the status of orders to completed after successful payment.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=206465&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:40;O:8:"stdClass":5:{s:5:"title";s:26:"Product Details Customiser";s:5:"image";s:0:"";s:7:"excerpt";s:132:"Customise WooCommerce product details pages. Show / Hide core components like product imagery, tabs, upsells &amp; related products.";s:4:"link";s:120:"http://www.woothemes.com/products/product-details-customiser/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:41;O:8:"stdClass":5:{s:5:"title";s:27:"Total Web Solutions Gateway";s:5:"image";s:93:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2013/05/tws-secure-clear.png";s:7:"excerpt";s:52:"Total Web Solutions payment gateway for WooCommerce.";s:4:"link";s:121:"http://www.woothemes.com/products/total-web-solutions-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:42;O:8:"stdClass":5:{s:5:"title";s:26:"Product Archive Customiser";s:5:"image";s:0:"";s:7:"excerpt";s:53:"Allows you to customise WooCommerce product archives.";s:4:"link";s:120:"http://www.woothemes.com/products/product-archive-customiser/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:43;O:8:"stdClass":5:{s:5:"title";s:24:"Sold Out Products Widget";s:5:"image";s:0:"";s:7:"excerpt";s:86:"Extends WooCommerce by adding a widget and shortcode for displaying sold out products.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=197567&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:44;O:8:"stdClass":5:{s:5:"title";s:14:"Social Rewards";s:5:"image";s:0:"";s:7:"excerpt";s:79:"Offer rewards based on events or social actions made by your store\'s customers.";s:4:"link";s:108:"http://www.woothemes.com/products/social-rewards/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;69.00";}i:45;O:8:"stdClass":5:{s:5:"title";s:16:"Smart Sale Badge";s:5:"image";s:0:"";s:7:"excerpt";s:91:"Enhances the WooCommerce sale badge by displaying the total saving a customer will receive.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=196635&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:46;O:8:"stdClass":5:{s:5:"title";s:32:"WooCommerce Bundle Style Coupons";s:5:"image";s:0:"";s:7:"excerpt";s:99:"Enables store owners to make a coupon only apply when all products required for it are in the cart.";s:4:"link";s:126:"http://www.woothemes.com/products/woocommerce-bundle-style-coupons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:47;O:8:"stdClass":5:{s:5:"title";s:29:"WooCommerce New Product Badge";s:5:"image";s:0:"";s:7:"excerpt";s:76:"Displays a \'new\' badge on WooCommerce products published in the last x days.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=190246&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:48;O:8:"stdClass":5:{s:5:"title";s:28:"WooCommerce Email Validation";s:5:"image";s:0:"";s:7:"excerpt";s:141:"Add a \'confirm email address\' field to the checkout page as a required field ensuring that your customers will enter a correct email address.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=185343&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:49;O:8:"stdClass":5:{s:5:"title";s:29:"WooCommerce Thesis Integrator";s:5:"image";s:0:"";s:7:"excerpt";s:95:"Integrated WooCommerce and Thesis 2. Use the coupon code \'woothemes\' to receive a 25% discount!";s:4:"link";s:123:"http://www.woothemes.com/products/woocommerce-thesis-integrator/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:50;O:8:"stdClass":5:{s:5:"title";s:20:"Social Review Engine";s:5:"image";s:0:"";s:7:"excerpt";s:156:"The Social Review Engine is a powerful and feature rich website and product review plugin built for WordPress powered blogs and integrated with WooCommerce.";s:4:"link";s:114:"http://www.woothemes.com/products/social-review-engine/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;97.00";}i:51;O:8:"stdClass":5:{s:5:"title";s:15:"Infinite Scroll";s:5:"image";s:0:"";s:7:"excerpt";s:111:"Automatically append the next page of posts/products (via AJAX) to your page when a user scrolls to the bottom.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=176537&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:52;O:8:"stdClass":5:{s:5:"title";s:18:"MobiCart Connector";s:5:"image";s:0:"";s:7:"excerpt";s:145:"Turn your WooCommerce e-commerce store into an m-commerce app. MobiCart supports native iPhone, iPad and Android apps, as well as HTML5 web apps.";s:4:"link";s:112:"http://www.woothemes.com/products/mobicart-connector/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;15.00";}i:53;O:8:"stdClass":5:{s:5:"title";s:20:"Tickets: WooCommerce";s:5:"image";s:0:"";s:7:"excerpt";s:147:"With the WooTickets add-on for The Events Calendar/Events Calendar PRO, taking control of ticket sales for an upcoming event has never been easier.";s:4:"link";s:113:"http://www.woothemes.com/products/tickets-woocommerce/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;65.00";}i:54;O:8:"stdClass":5:{s:5:"title";s:21:"WooCommerce Menu Cart";s:5:"image";s:0:"";s:7:"excerpt";s:145:"This plugin installs a shopping cart button in the navigation bar. The plugin takes less than a minute to setup, and includes a bunch of options.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=170213&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:55;O:8:"stdClass":5:{s:5:"title";s:12:"Smart Offers";s:5:"image";s:0:"";s:7:"excerpt";s:161:"Instantly boost profits by creating targeted special offers and promotions within your sales funnel. Upsells, Downsells, One Time Offers, Backend sales and more.";s:4:"link";s:106:"http://www.woothemes.com/products/smart-offers/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;97.00";}i:56;O:8:"stdClass":5:{s:5:"title";s:16:"Bitcoin Payments";s:5:"image";s:0:"";s:7:"excerpt";s:74:"Accept payment in bitcoins for physical and digital downloadable products.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=168744&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:57;O:8:"stdClass":5:{s:5:"title";s:28:"InfusionSoft Payment Gateway";s:5:"image";s:0:"";s:7:"excerpt";s:95:"Connects the WordPress shopping cart system WooCommerce with any Infusionsoft Merchant Account.";s:4:"link";s:122:"http://www.woothemes.com/products/infusionsoft-payment-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;127.00";}i:58;O:8:"stdClass":5:{s:5:"title";s:20:"WooCommerce Cart Tab";s:5:"image";s:0:"";s:7:"excerpt";s:124:"Displays a link to the cart which is visible sitewide and fixed in position so it remains visible wherever the user scrolls.";s:4:"link";s:114:"http://www.woothemes.com/products/woocommerce-cart-tab/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:59;O:8:"stdClass":5:{s:5:"title";s:7:"StoreYa";s:5:"image";s:0:"";s:7:"excerpt";s:159:"StoreYa.com is a leading F-commerce platform designed for automatically importing WooCommerce stores into Facebook taking full advantage of its social elements";s:4:"link";s:101:"http://www.woothemes.com/products/storeya/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:60;O:8:"stdClass":5:{s:5:"title";s:15:"Paysius Gateway";s:5:"image";s:0:"";s:7:"excerpt";s:151:"A merchant solution which uses cutting-edge Bitcoin technology to give merchants zero risk of chargeback and lower fees than with conventional systems.";s:4:"link";s:109:"http://www.woothemes.com/products/paysius-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:61;O:8:"stdClass":5:{s:5:"title";s:27:"PayJunction Payment Gateway";s:5:"image";s:68:"https://www.woothemes.com/wp-content/uploads/2012/09/payjunction.jpg";s:7:"excerpt";s:108:"Accept all major brands with the PayJunction service: Visa, MasterCard, American Express, Discover and more.";s:4:"link";s:121:"http://www.woothemes.com/products/payjunction-payment-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:62;O:8:"stdClass":5:{s:5:"title";s:17:"QR Code Generator";s:5:"image";s:0:"";s:7:"excerpt";s:123:"Let people instantly view a product or even add it to their cart by scanning custom QR codes generated with this extension.";s:4:"link";s:111:"http://www.woothemes.com/products/qr-code-generator/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:63;O:8:"stdClass":5:{s:5:"title";s:13:"Limited Deals";s:5:"image";s:0:"";s:7:"excerpt";s:115:"Offer expiring deals to your customers and optionally display order totals &amp; savings via a stylish css3 banner.";s:4:"link";s:107:"http://www.woothemes.com/products/limited-deals/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;49.00";}i:64;O:8:"stdClass":5:{s:5:"title";s:23:"Inspire Payment Gateway";s:5:"image";s:85:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/11/logo.200.png";s:7:"excerpt";s:145:"Inspire Commerce is the all-in-one solution that allows you to turn your beautiful WooCommerce backed shopping experience into a selling machine.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=138175&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:65;O:8:"stdClass":5:{s:5:"title";s:24:"Accepted Payment Methods";s:5:"image";s:0:"";s:7:"excerpt";s:93:"Allows you to display which payment methods you accept via widget, shortcode or template tag.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=135051&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:66;O:8:"stdClass":5:{s:5:"title";s:14:"IcePay Gateway";s:5:"image";s:0:"";s:7:"excerpt";s:118:"ICEPAY online payment plugin for WooCommerce provides all popular online payment methods for your WooCommerce webshop.";s:4:"link";s:108:"http://www.woothemes.com/products/icepay-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:67;O:8:"stdClass":5:{s:5:"title";s:25:"Improvely for WooCommerce";s:5:"image";s:0:"";s:7:"excerpt";s:141:"Use Improvely with your WooCommerce-powered store to measure your advertising, click fraud marketing, social media marketing and SEO results.";s:4:"link";s:119:"http://www.woothemes.com/products/improvely-for-woocommerce/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:68;O:8:"stdClass":5:{s:5:"title";s:14:"Bring Shipping";s:5:"image";s:82:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/10/bring.png";s:7:"excerpt";s:104:"Automatically calculate shipment prices of products in your customer\'s cart using the services of Bring.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=122539&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:69;O:8:"stdClass":5:{s:5:"title";s:17:"Amazon Simple Pay";s:5:"image";s:82:"https://www.woothemes.com/wp-content/uploads/woocommerce_uploads/2012/08/home.jpeg";s:7:"excerpt";s:62:"Take payments on your WooCommerce store via Amazon Simple Pay.";s:4:"link";s:110:"http://www.woothemes.com/?post_type=product&p=18725&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;79.00";}i:70;O:8:"stdClass":5:{s:5:"title";s:14:"QuickBooks POS";s:5:"image";s:0:"";s:7:"excerpt";s:68:"Streamline your order and inventory management using QuickBooks POS.";s:4:"link";s:108:"http://www.woothemes.com/products/quickbooks-pos/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:71;O:8:"stdClass":5:{s:5:"title";s:22:"QuickBooks Integration";s:5:"image";s:0:"";s:7:"excerpt";s:64:"Sync orders, customers and inventory to your QuickBooks software";s:4:"link";s:110:"http://www.woothemes.com/?post_type=product&p=18658&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:72;O:8:"stdClass":5:{s:5:"title";s:11:"PayJunction";s:5:"image";s:68:"https://www.woothemes.com/wp-content/uploads/2012/09/payjunction.jpg";s:7:"excerpt";s:108:"Accept all major brands with the PayJunction service: Visa, MasterCard, American Express, Discover and more.";s:4:"link";s:110:"http://www.woothemes.com/?post_type=product&p=18656&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:73;O:8:"stdClass":5:{s:5:"title";s:16:"Pinterest Button";s:5:"image";s:0:"";s:7:"excerpt";s:158:"Easily add a Pinterest Pin-it button to your WooCommerce single product pages. This allows customers to easily post your product images directly to Pinterest.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120759&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:74;O:8:"stdClass":5:{s:5:"title";s:24:"Sequential Order Numbers";s:5:"image";s:0:"";s:7:"excerpt";s:105:"This plugin extends the WooCommerce e-commerce plugin by setting sequential order numbers for new orders.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120755&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:75;O:8:"stdClass":5:{s:5:"title";s:17:"WP Cart Mailcheck";s:5:"image";s:0:"";s:7:"excerpt";s:102:"Checks for mis-spelled email addresses (e.g. joe.bloggs@gnail.com) and corrects them for the customer.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120754&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:76;O:8:"stdClass":5:{s:5:"title";s:18:"Admin Bar Addition";s:5:"image";s:0:"";s:7:"excerpt";s:127:"This plugin adds useful admin links and massive resources for the WooCommerce Shop Plugin to the WordPress Toolbar / Admin Bar.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120753&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:77;O:8:"stdClass":5:{s:5:"title";s:15:"Genesis Connect";s:5:"image";s:0:"";s:7:"excerpt";s:111:"This plugin allows you to seamlessly integrate WooCommerce with the Genesis Framework and Genesis child themes.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120752&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:78;O:8:"stdClass":5:{s:5:"title";s:14:"Delivery Notes";s:5:"image";s:0:"";s:7:"excerpt";s:150:"Print order invoices &amp; delivery notes for WooCommerce shop. You can add company/shop info as well as personal notes &amp; policies to print pages.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120750&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:79;O:8:"stdClass":5:{s:5:"title";s:25:"Postgiro/Bankgiro gateway";s:5:"image";s:0:"";s:7:"excerpt";s:136:"Adds a new payment gateway to WooCommerce, there you are available to add Postgiro number and Bankgiro number (Swedish payment methods).";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120749&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:80;O:8:"stdClass":5:{s:5:"title";s:16:"CCAvenue Gateway";s:5:"image";s:0:"";s:7:"excerpt";s:125:"This is the CCAvenue payment gateway for WooCommerce. Allows you to use CCAvenue payment gateway with the WooCommerce plugin.";s:4:"link";s:110:"http://www.woothemes.com/products/ccavenue-gateway/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:81;O:8:"stdClass":5:{s:5:"title";s:12:"Ewire Direct";s:5:"image";s:0:"";s:7:"excerpt";s:105:"The Ewire Payment Module makes it possible for your WooCommerce store to accept payment from scandinavia.";s:4:"link";s:106:"http://www.woothemes.com/products/ewire-direct/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:82;O:8:"stdClass":5:{s:5:"title";s:17:"Robokassa Gateway";s:5:"image";s:0:"";s:7:"excerpt";s:104:"Allow customers on your WooCommerce powered online store to check out via the Russian Robokassa gateway.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120745&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:83;O:8:"stdClass":5:{s:5:"title";s:16:"Postepay Gateway";s:5:"image";s:0:"";s:7:"excerpt";s:83:"Allow customers on your WooCommerce powered online store to check out via Postepay.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120744&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:84;O:8:"stdClass":5:{s:5:"title";s:15:"Custom Statuses";s:5:"image";s:0:"";s:7:"excerpt";s:62:"This plugin allows you to create custom orders in WooCommerce.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120741&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:85;O:8:"stdClass":5:{s:5:"title";s:24:"Custom Product Tabs Lite";s:5:"image";s:0:"";s:7:"excerpt";s:129:"Allows a custom product tab to be added to product view pages with arbitrary content, which may contain text, html or shortcodes.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120736&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:86;O:8:"stdClass":5:{s:5:"title";s:9:"Cart2Cart";s:5:"image";s:0:"";s:7:"excerpt";s:184:"Cart2Cart is a service which migrates product / customer / order data from many other eCommerce platforms into WooCommerce. Perfect if you\'re looking to make the switch to WooCommerce!";s:4:"link";s:103:"http://www.woothemes.com/products/cart2cart/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:87;O:8:"stdClass":5:{s:5:"title";s:20:"WPML for WooCommerce";s:5:"image";s:0:"";s:7:"excerpt";s:107:"This \'glue\' plugin makes it possible to run fully multilingual e-commerce sites using WooCommerce and WPML.";s:4:"link";s:114:"http://www.woothemes.com/products/wpml-for-woocommerce/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:88;O:8:"stdClass":5:{s:5:"title";s:14:"Affiliates Pro";s:5:"image";s:0:"";s:7:"excerpt";s:147:"Provides an affiliate management system for sellers, shops and developers, who want to increase sales with their own affiliate program immediately.";s:4:"link";s:108:"http://www.woothemes.com/products/affiliates-pro/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;59.00";}i:89;O:8:"stdClass":5:{s:5:"title";s:15:"Product Compare";s:5:"image";s:0:"";s:7:"excerpt";s:130:"Add a Compare Products Feature to all of your products on you WooCommerce site today with the WooCommerce Compare Products plugin.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120730&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:90;O:8:"stdClass":5:{s:5:"title";s:17:"Product Video Tab";s:5:"image";s:0:"";s:7:"excerpt";s:111:"Easily add a unique video tab to your product pages. Perfect if you have video demonstrations of your products.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120728&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:91;O:8:"stdClass":5:{s:5:"title";s:9:"Piggy Pro";s:5:"image";s:0:"";s:7:"excerpt";s:137:"Piggy is an awesome, mobile web app that taps straight into WooCommerce and gives you your latest sales data on your mobile in real-time.";s:4:"link";s:111:"http://www.woothemes.com/?post_type=product&p=120727&utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:92;O:8:"stdClass":5:{s:5:"title";s:18:"Grid / List Toggle";s:5:"image";s:0:"";s:7:"excerpt";s:136:"Adds a Grid / List toggle to your product archives allowing users to, you guessed it, toggle between grid / list views of your products.";s:4:"link";s:110:"http://www.woothemes.com/products/grid-list-toggle/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:9:"&#36;0.00";}i:93;O:8:"stdClass":5:{s:5:"title";s:13:"WP Lister Pro";s:5:"image";s:0:"";s:7:"excerpt";s:58:"List your products on eBay and keep your inventory in sync";s:4:"link";s:103:"http://www.woothemes.com/products/wp-lister/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:11:"&#36;129.00";}i:94;O:8:"stdClass":5:{s:5:"title";s:13:"Smart Manager";s:5:"image";s:0:"";s:7:"excerpt";s:124:"Smart Manager is a unique, revolutionary tool that gives you the power to efficiently manage products, customers and orders.";s:4:"link";s:107:"http://www.woothemes.com/products/smart-manager/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons";s:5:"price";s:10:"&#36;97.00";}}}', 'no') ; 
INSERT INTO `wp_options` VALUES (331, '_transient_timeout_wc_rating_count_167', '1444720344', 'no') ; 
INSERT INTO `wp_options` VALUES (332, '_transient_wc_rating_count_167', '1', 'no') ; 
INSERT INTO `wp_options` VALUES (333, '_transient_timeout_wc_average_rating_167', '1444720344', 'no') ; 
INSERT INTO `wp_options` VALUES (334, '_transient_wc_average_rating_167', '5.00', 'no') ; 
INSERT INTO `wp_options` VALUES (335, 'woocommerce_default_gateway', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (336, 'woocommerce_gateway_order', 'a:4:{s:4:"bacs";i:0;s:6:"cheque";i:1;s:3:"cod";i:2;s:6:"paypal";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (339, '_transient_timeout_wc_ship_676612bfdab8daff19bcdf96089cbd05', '1413188282', 'no') ; 
INSERT INTO `wp_options` VALUES (340, '_transient_wc_ship_676612bfdab8daff19bcdf96089cbd05', 'a:1:{s:13:"free_shipping";O:16:"WC_Shipping_Rate":5:{s:2:"id";s:13:"free_shipping";s:5:"label";s:13:"Free Shipping";s:4:"cost";d:0;s:5:"taxes";a:0:{}s:9:"method_id";s:13:"free_shipping";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (351, 'wc_customizer_version', '2.0.1', 'yes') ; 
INSERT INTO `wp_options` VALUES (370, '_transient_timeout_wc_ship_51d3ff7b08ccbed8b6574e27f4bb44f4', '1413251291', 'no') ; 
INSERT INTO `wp_options` VALUES (371, '_transient_wc_ship_51d3ff7b08ccbed8b6574e27f4bb44f4', 'a:1:{s:13:"free_shipping";O:16:"WC_Shipping_Rate":5:{s:2:"id";s:13:"free_shipping";s:5:"label";s:13:"Free Shipping";s:4:"cost";d:0;s:5:"taxes";a:0:{}s:9:"method_id";s:13:"free_shipping";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (372, '_transient_timeout_wc_ship_dfe0221a01f79ae3e814ca650c7173e0', '1413251351', 'no') ; 
INSERT INTO `wp_options` VALUES (373, '_transient_wc_ship_dfe0221a01f79ae3e814ca650c7173e0', 'a:1:{s:13:"free_shipping";O:16:"WC_Shipping_Rate":5:{s:2:"id";s:13:"free_shipping";s:5:"label";s:13:"Free Shipping";s:4:"cost";d:0;s:5:"taxes";a:0:{}s:9:"method_id";s:13:"free_shipping";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (374, 'woocommerce_paypal_settings', 'a:19:{s:7:"enabled";s:3:"yes";s:5:"title";s:6:"PayPal";s:11:"description";s:85:"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.";s:5:"email";s:25:"devfallengiants@gmail.com";s:8:"testmode";s:3:"yes";s:5:"debug";s:2:"no";s:8:"shipping";s:0:"";s:13:"send_shipping";s:2:"no";s:16:"address_override";s:2:"no";s:8:"advanced";s:0:"";s:14:"receiver_email";s:0:"";s:14:"invoice_prefix";s:3:"WC-";s:13:"paymentaction";s:4:"sale";s:10:"page_style";s:0:"";s:14:"identity_token";s:0:"";s:11:"api_details";s:0:"";s:12:"api_username";s:0:"";s:12:"api_password";s:0:"";s:13:"api_signature";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (419, '_transient_timeout_wc_ship_c4b71aa1a6fefc0875c9058a331a3952', '1413337486', 'no') ; 
INSERT INTO `wp_options` VALUES (420, '_transient_wc_ship_c4b71aa1a6fefc0875c9058a331a3952', 'a:1:{s:13:"free_shipping";O:16:"WC_Shipping_Rate":5:{s:2:"id";s:13:"free_shipping";s:5:"label";s:13:"Free Shipping";s:4:"cost";d:0;s:5:"taxes";a:0:{}s:9:"method_id";s:13:"free_shipping";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (431, 'wp_gmp_db_version', '1.2.5.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (434, 'gmpchecked_reg_plugs_time', '1413349050', 'yes') ; 
INSERT INTO `wp_options` VALUES (436, 'gmp_plug_was_used', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (437, 'wpgmza_xml_location', '/Users/cyponthemic/Desktop/ARTWORKS/WORDPRESS/FallenGiants/fallengiants/wp-content/uploads/wp-google-maps/', 'yes') ; 
INSERT INTO `wp_options` VALUES (438, 'wpgmza_xml_url', 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/wp-google-maps/', 'yes') ; 
INSERT INTO `wp_options` VALUES (439, 'wpgmza_db_version', '6.0.27', 'yes') ; 
INSERT INTO `wp_options` VALUES (440, 'wpgmaps_current_version', '6.0.27', 'yes') ; 
INSERT INTO `wp_options` VALUES (442, 'WPGMZA_FIRST_TIME', '6.0.27', 'yes') ; 
INSERT INTO `wp_options` VALUES (443, 'WPGMZA_SETTINGS', 'a:9:{s:24:"map_default_starting_lat";s:18:"-37.15714667999481";s:24:"map_default_starting_lng";s:17:"142.5426260546875";s:18:"map_default_height";s:3:"400";s:17:"map_default_width";s:3:"100";s:16:"map_default_zoom";i:9;s:16:"map_default_type";i:1;s:21:"map_default_alignment";i:1;s:22:"map_default_width_type";s:2:"\\%";s:23:"map_default_height_type";s:2:"px";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (447, 'cgmp_options', 'a:4:{s:12:"admin_notice";s:4:"hide";s:13:"plugin_notice";s:4:"show";s:14:"metabox_notice";s:4:"show";s:13:"export_notice";s:4:"show";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (448, 'cgmp_cache_mashup_map', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (449, 'cgmp_cache_time_mashup_map', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (450, 'cgmp_initial_warning', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (451, 'jetpack_activated', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (452, 'jetpack_options', 'a:4:{s:7:"version";s:16:"3.1.1:1413350081";s:11:"old_version";s:16:"3.1.1:1413350081";s:28:"fallback_no_verify_ssl_certs";i:0;s:9:"time_diff";i:-2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (454, '_transient_timeout_jetpack_https_test', '1413436484', 'no') ; 
INSERT INTO `wp_options` VALUES (455, '_transient_jetpack_https_test', '1', 'no') ; 
INSERT INTO `wp_options` VALUES (510, '_site_transient_timeout_browser_65d7f4e7faa616ce2b4b32e4526af61e', '1414471030', 'yes') ; 
INSERT INTO `wp_options` VALUES (511, '_site_transient_browser_65d7f4e7faa616ce2b4b32e4526af61e', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"38.0.2125.104";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (512, '_transient_timeout_wc_admin_report', '1413952632', 'no') ; 
INSERT INTO `wp_options` VALUES (513, '_transient_wc_admin_report', 'a:2:{s:32:"677117e4b61ca1669e5a62ba1c11fb20";a:1:{i:0;O:8:"stdClass":2:{s:15:"sparkline_value";s:3:"140";s:9:"post_date";s:19:"2014-10-14 00:49:00";}}s:32:"11b60ec3bef818783396316c563cf14b";a:1:{i:0;O:8:"stdClass":3:{s:10:"product_id";s:3:"167";s:15:"sparkline_value";s:1:"7";s:9:"post_date";s:19:"2014-10-14 00:49:00";}}}', 'no') ; 
INSERT INTO `wp_options` VALUES (514, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1413909439', 'no') ; 
INSERT INTO `wp_options` VALUES (515, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:26:"https://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Oct 2014 13:39:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:42:"http://wordpress.org/?v=4.1-alpha-20141018";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 4.0 “Benny”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"https://wordpress.org/news/2014/09/benny/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"https://wordpress.org/news/2014/09/benny/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 04 Sep 2014 17:05:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3296";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:370:"Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader Benny Goodman, is available for download or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we&#8217;ve put a little extra polish into it. This release brings you a smoother writing and management experience [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23575:"<p>Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader <a href="http://en.wikipedia.org/wiki/Benny_Goodman">Benny Goodman</a>, is available <a href="https://wordpress.org/download/">for download</a> or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we&#8217;ve put a little extra polish into it. This release brings you a smoother writing and management experience we think you&#8217;ll enjoy.</p>
<div id="v-bUdzKMro-1" class="video-player"><embed id="v-bUdzKMro-1-video" src="https://v0.wordpress.com/player.swf?v=1.03&amp;guid=bUdzKMro&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" title="Introducing WordPress 4.0 &quot;Benny&quot;" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<hr />
<h2 style="text-align: center">Manage your media with style</h2>
<p><img class="alignnone size-full wp-image-3316" src="https://wordpress.org/news/files/2014/09/media.jpg" alt="Media Library" width="1000" height="586" />Explore your uploads in a beautiful, endless grid. A new details preview makes viewing and editing any amount of media in sequence a snap.</p>
<hr />
<h2 style="text-align: center">Working with embeds has never been easier</h2>
<div style="width: 632px; height: 445px; " class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3296-1" width="632" height="445" autoplay="true" preload="metadata" controls="controls"><source type="video/mp4" src="//s.w.org/images/core/4.0/embed.mp4?_=1" /><source type="video/webm" src="//s.w.org/images/core/4.0/embed.webm?_=1" /><source type="video/ogg" src="//s.w.org/images/core/4.0/embed.ogv?_=1" /><a href="//s.w.org/images/core/4.0/embed.mp4">//s.w.org/images/core/4.0/embed.mp4</a></video></div>
<p>Paste in a YouTube URL on a new line, and watch it magically become an embedded video. Now try it with a tweet. Oh yeah — embedding has become a visual experience. The editor shows a true preview of your embedded content, saving you time and giving you confidence.</p>
<p>We’ve expanded the services supported by default, too — you can embed videos from CollegeHumor, playlists from YouTube, and talks from TED. <a href="https://codex.wordpress.org/Embeds">Check out all of the embeds</a> that WordPress supports.</p>
<hr />
<h2 style="text-align: center">Focus on your content</h2>
<div style="width: 632px; height: 356px; " class="wp-video"><video class="wp-video-shortcode" id="video-3296-2" width="632" height="356" autoplay="true" preload="metadata" controls="controls"><source type="video/mp4" src="//s.w.org/images/core/4.0/focus.mp4?_=2" /><source type="video/webm" src="//s.w.org/images/core/4.0/focus.webm?_=2" /><source type="video/ogg" src="//s.w.org/images/core/4.0/focus.ogv?_=2" /><a href="//s.w.org/images/core/4.0/focus.mp4">//s.w.org/images/core/4.0/focus.mp4</a></video></div>
<p>Writing and editing is smoother and more immersive with an editor that expands to fit your content as you write, and keeps the formatting tools available at all times.</p>
<hr />
<h2 style="text-align: center">Finding the right plugin</h2>
<p><img class="aligncenter size-large wp-image-3309" src="https://wordpress.org/news/files/2014/09/add-plugin1-1024x600.png" alt="Add plugins" width="692" height="405" /></p>
<p>There are more than 30,000 free and open source plugins in the WordPress plugin directory. WordPress 4.0 makes it easier to find the right one for your needs, with new metrics, improved search, and a more visual browsing experience.</p>
<hr />
<h2 style="text-align: center">The Ensemble</h2>
<p>This release was led by <a href="http://helenhousandi.com">Helen Hou-Sandí</a>, with the help of these fine individuals. There are 275 contributors with props in this release, a new high. Pull up some Benny Goodman on your music service of choice, as a bandleader or in one of his turns as a classical clarinetist, and check out some of their profiles:</p>
<p><a href="https://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="https://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="https://profiles.wordpress.org/alexanderrohmann">Alexander Rohmann</a>, <a href="https://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="https://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="https://profiles.wordpress.org/amit">Amit Gupta</a>, <a href="https://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/andrezrv">Andres Villarreal</a>, <a href="https://profiles.wordpress.org/zamfeer">Andrew Mowe</a>, <a href="https://profiles.wordpress.org/sumobi">Andrew Munro (sumobi)</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="https://profiles.wordpress.org/ankit-k-gupta">Ankit K Gupta</a>, <a href="https://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="https://profiles.wordpress.org/arnee">arnee</a>, <a href="https://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="https://profiles.wordpress.org/filosofo">Austin Matzko</a>, <a href="https://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="https://profiles.wordpress.org/kau-boy">Bernhard Kau</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="https://profiles.wordpress.org/bramd">Bram Duvigneau</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/brianlayman">Brian Layman</a>, <a href="https://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="https://profiles.wordpress.org/camdensegal">Camden Segal</a>, <a href="https://profiles.wordpress.org/sixhours">Caroline Moore</a>, <a href="https://profiles.wordpress.org/mackensen">Charles Fulton</a>, <a href="https://profiles.wordpress.org/chouby">Chouby</a>, <a href="https://profiles.wordpress.org/chrico">ChriCo</a>, <a href="https://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="https://profiles.wordpress.org/chrisl27">chrisl27</a>, <a href="https://profiles.wordpress.org/caxelsson">Christian Axelsson</a>, <a href="https://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="https://profiles.wordpress.org/boda1982">Christopher Spires</a>, <a href="https://profiles.wordpress.org/clifgriffin">Clifton Griffin</a>, <a href="https://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="https://profiles.wordpress.org/corphi">Corphi</a>, <a href="https://profiles.wordpress.org/extendwings">Daisuke Takahashi</a>, <a href="https://profiles.wordpress.org/ghost1227">Dan Griffiths</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/danielhuesken">Daniel Husken</a>, <a href="https://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="https://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="https://profiles.wordpress.org/dkotter">Darin Kotter</a>, <a href="https://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="https://profiles.wordpress.org/dllh">Daryl L. L. Houston (dllh)</a>, <a href="https://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="https://profiles.wordpress.org/dlh">David Herrera</a>, <a href="https://profiles.wordpress.org/dnaber-de">David Naber</a>, <a href="https://profiles.wordpress.org/davidthemachine">DavidTheMachine</a>, <a href="https://profiles.wordpress.org/debaat">DeBAAT</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/donncha">Donncha O Caoimh</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/dustyn">Dustyn Doyle</a>, <a href="https://profiles.wordpress.org/eddiemoya">Eddie Moya</a>, <a href="https://profiles.wordpress.org/oso96_2000">Eduardo Reveles</a>, <a href="https://profiles.wordpress.org/edwin-at-studiojoyocom">Edwin Siebel</a>, <a href="https://profiles.wordpress.org/ehg">ehg</a>, <a href="https://profiles.wordpress.org/tmeister">Enrique Chavez</a>, <a href="https://profiles.wordpress.org/erayalakese">erayalakese</a>, <a href="https://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="https://profiles.wordpress.org/ebinnion">Eric Binnion</a>, <a href="https://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="https://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="https://profiles.wordpress.org/eherman24">Evan Herman</a>, <a href="https://profiles.wordpress.org/fab1en">Fab1en</a>, <a href="https://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="https://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="https://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="https://profiles.wordpress.org/garhdez">garhdez</a>, <a href="https://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="https://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/garza">garza</a>, <a href="https://profiles.wordpress.org/gauravmittal1995">gauravmittal1995</a>, <a href="https://profiles.wordpress.org/gavra">Gavrisimo</a>, <a href="https://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="https://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="https://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="https://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="https://profiles.wordpress.org/bordoni">Gustavo Bordoni</a>, <a href="https://profiles.wordpress.org/harrym">harrym</a>, <a href="https://profiles.wordpress.org/hebbet">hebbet</a>, <a href="https://profiles.wordpress.org/hinnerk">Hinnerk Altenburg</a>, <a href="https://profiles.wordpress.org/hlashbrooke">Hugh Lashbrooke</a>, <a href="https://profiles.wordpress.org/iljoja">iljoja</a>, <a href="https://profiles.wordpress.org/imath">imath</a>, <a href="https://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="https://profiles.wordpress.org/issuu">issuu</a>, <a href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="https://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="https://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="https://profiles.wordpress.org/jacobdubail">Jacob Dubail</a>, <a href="https://profiles.wordpress.org/janhenkg">JanHenkG</a>, <a href="https://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="https://profiles.wordpress.org/jwenerd">Jared Wenerd</a>, <a href="https://profiles.wordpress.org/jaza613">Jaza613</a>, <a href="https://profiles.wordpress.org/jeffstieler">Jeff Stieler</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jpry">Jeremy Pry</a>, <a href="https://profiles.wordpress.org/slimndap">Jeroen Schmit</a>, <a href="https://profiles.wordpress.org/jerrysarcastic">Jerry Bates (jerrysarcastic)</a>, <a href="https://profiles.wordpress.org/jesin">Jesin A</a>, <a href="https://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="https://profiles.wordpress.org/engelen">Jesper van Engelen</a>, <a href="https://profiles.wordpress.org/jesper800">Jesper van Engelen</a>, <a href="https://profiles.wordpress.org/jessepollak">Jesse Pollak</a>, <a href="https://profiles.wordpress.org/jgadbois">jgadbois</a>, <a href="https://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="https://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="https://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="https://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="https://profiles.wordpress.org/johnzanussi">John Zanussi</a>, <a href="https://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="https://profiles.wordpress.org/jonnyauk">jonnyauk</a>, <a href="https://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="https://profiles.wordpress.org/softmodeling">Jordi Cabot</a>, <a href="https://profiles.wordpress.org/jjeaton">Josh Eaton</a>, <a href="https://profiles.wordpress.org/tai">JOTAKI Taisuke</a>, <a href="https://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="https://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="https://profiles.wordpress.org/jtsternberg">Justin Sternberg</a>, <a href="https://profiles.wordpress.org/greenshady">Justin Tadlock</a>, <a href="https://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="https://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="https://profiles.wordpress.org/ixkaito">Kaito</a>, <a href="https://profiles.wordpress.org/kapeels">kapeels</a>, <a href="https://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="https://profiles.wordpress.org/kevinlangleyjr">Kevin Langley</a>, <a href="https://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="https://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="https://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="https://profiles.wordpress.org/kitchin">kitchin</a>, <a href="https://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/krogsgard">krogsgard</a>, <a href="https://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="https://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="https://profiles.wordpress.org/layotte">Lew Ayotte</a>, <a href="https://profiles.wordpress.org/lritter">lritter</a>, <a href="https://profiles.wordpress.org/lukecarbis">Luke Carbis</a>, <a href="https://profiles.wordpress.org/lgedeon">Luke Gedeon</a>, <a href="https://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="https://profiles.wordpress.org/funkatronic">Manny Fleurmond</a>, <a href="https://profiles.wordpress.org/targz-1">Manuel Schmalstieg</a>, <a href="https://profiles.wordpress.org/clorith">Marius (Clorith)</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="https://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="https://profiles.wordpress.org/sivel">Matt Martz</a>, <a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="https://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="https://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="https://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="https://profiles.wordpress.org/mattheweppelsheimer">Matthew Eppelsheimer</a>, <a href="https://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/meekyhwang">meekyhwang</a>, <a href="https://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="https://profiles.wordpress.org/midxcat">mi_cat</a>, <a href="https://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="https://profiles.wordpress.org/michalzuber">michalzuber</a>, <a href="https://profiles.wordpress.org/mauteri">Mike Auteri</a>, <a href="https://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="https://profiles.wordpress.org/mikejolley">Mike Jolley</a>, <a href="https://profiles.wordpress.org/mikelittle">Mike Little</a>, <a href="https://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="https://profiles.wordpress.org/mnelson4">Mike Nelson</a>, <a href="https://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="https://profiles.wordpress.org/mikeyarce">Mikey Arce</a>, <a href="https://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="https://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="https://profiles.wordpress.org/usermrpapa">Mr Papa</a>, <a href="https://profiles.wordpress.org/mrmist">mrmist</a>, <a href="https://profiles.wordpress.org/m_uysl">Mustafa Uysal</a>, <a href="https://profiles.wordpress.org/muvimotv">MuViMoTV</a>, <a href="https://profiles.wordpress.org/nabil_kadimi">nabil_kadimi</a>, <a href="https://profiles.wordpress.org/namibia">Namibia</a>, <a href="https://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="https://profiles.wordpress.org/nd987">nd987</a>, <a href="https://profiles.wordpress.org/neil_pie">Neil Pie</a>, <a href="https://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/schoenwaldnils">Nils Schonwald</a>, <a href="https://profiles.wordpress.org/ninos-ego">Ninos</a>, <a href="https://profiles.wordpress.org/nvwd">Nowell VanHoesen</a>, <a href="https://profiles.wordpress.org/compute">Patrick Hesselberg</a>, <a href="https://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="https://profiles.wordpress.org/pdclark">Paul Clark</a>, <a href="https://profiles.wordpress.org/paulschreiber">Paul Schreiber</a>, <a href="https://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="https://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="https://profiles.wordpress.org/philipjohn">Philip John</a>, <a href="https://profiles.wordpress.org/senlin">Piet</a>, <a href="https://profiles.wordpress.org/psoluch">Piotr Soluch</a>, <a href="https://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="https://profiles.wordpress.org/purzlbaum">purzlbaum</a>, <a href="https://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="https://profiles.wordpress.org/rclations">RC Lations</a>, <a href="https://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="https://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="https://profiles.wordpress.org/rob1n">rob1n</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="https://profiles.wordpress.org/harmr">RobertHarm</a>, <a href="https://profiles.wordpress.org/rohan013">Rohan Rawat</a>, <a href="https://profiles.wordpress.org/rhurling">Rouven Hurling</a>, <a href="https://profiles.wordpress.org/ruudjoyo">Ruud Laan</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="https://profiles.wordpress.org/sammybeats">Sam Brodie</a>, <a href="https://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="https://profiles.wordpress.org/sathishn">Sathish Nagarajan</a>, <a href="https://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="https://profiles.wordpress.org/scribu">scribu</a>, <a href="https://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="https://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="https://profiles.wordpress.org/sergejmueller">Sergej Muller</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/shanebp">shanebp</a>, <a href="https://profiles.wordpress.org/sharonaustin">Sharon Austin</a>, <a href="https://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="https://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="https://profiles.wordpress.org/simonp303">simonp303</a>, <a href="https://profiles.wordpress.org/slobodanmanic">Slobodan Manic</a>, <a href="https://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="https://profiles.wordpress.org/sphoid">sphoid</a>, <a href="https://profiles.wordpress.org/stephdau">Stephane Daury</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/stompweb">Steven Jones</a>, <a href="https://profiles.wordpress.org/strangerstudios">strangerstudios</a>, <a href="https://profiles.wordpress.org/5um17">Sumit Singh</a>, <a href="https://profiles.wordpress.org/t4k1s">t4k1s</a>, <a href="https://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="https://profiles.wordpress.org/taylorde">Taylor Dewey</a>, <a href="https://profiles.wordpress.org/thomasvanderbeek">Thomas van der Beek</a>, <a href="https://profiles.wordpress.org/tillkruess">Till Kruss</a>, <a href="https://profiles.wordpress.org/codenameeli">Tim \'Eli\' Dalbey</a>, <a href="https://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="https://profiles.wordpress.org/tjnowell">Tom J Nowell</a>, <a href="https://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="https://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="https://profiles.wordpress.org/torresga">torresga</a>, <a href="https://profiles.wordpress.org/liljimmi">Tracy Levesque</a>, <a href="https://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="https://profiles.wordpress.org/treyhunner">treyhunner</a>, <a href="https://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="https://profiles.wordpress.org/vinod-dalvi">Vinod Dalvi</a>, <a href="https://profiles.wordpress.org/vlajos">vlajos</a>, <a href="https://profiles.wordpress.org/voldemortensen">voldemortensen</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/winterdev">winterDev</a>, <a href="https://profiles.wordpress.org/wojtekszkutnik">Wojtek Szkutnik</a>, <a href="https://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="https://profiles.wordpress.org/katzwebdesign">Zack Katz</a>, <a href="https://profiles.wordpress.org/tollmanz">Zack Tollman</a>, and <a href="https://profiles.wordpress.org/zoerooney">Zoe Rooney</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video, and Helen with <a href="http://adriansandi.com">Adrián Sandí</a> for the music.</p>
<p>If you want to follow along or help out, check out <a href="https://make.wordpress.org/">Make WordPress</a> and our <a href="https://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.1!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/news/2014/09/benny/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 4.0 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:76:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Aug 2014 12:20:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3287";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:321:"The first release candidate for WordPress 4.0 is now available! In RC 1, we’ve made refinements to what we&#8217;ve been working on for this release. Check out the Beta 1 announcement post for more details on those features. We hope to ship WordPress 4.0 next week, but we need your help to get there. If you [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2134:"<p>The first release candidate for WordPress 4.0 is now available!</p>
<p>In RC 1, we’ve made refinements to what we&#8217;ve been working on for this release. Check out the <a href="https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">Beta 1 announcement post</a> for more details on those features. We hope to ship WordPress 4.0 <em>next week</em>, but we need your help to get there. If you haven’t tested 4.0 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="https://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="https://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>To test WordPress 4.0 RC1, try the <a href="https://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 4.0, visit the awesome About screen in your dashboard (<strong><img src="https://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar).</p>
<p><strong>Developers,</strong> please test your plugins and themes against WordPress 4.0 and update your plugin&#8217;s <em>Tested up to</em> version in the readme to 4.0 before next week. If you find compatibility problems, please be sure to post any issues to the support forums so we can figure those out before the final release. You also may want to <a href="https://make.wordpress.org/core/2014/08/21/introducing-plugin-icons-in-the-plugin-installer/">give your plugin an icon</a>, which we launched last week and will appear in the dashboard along with banners.</p>
<p><em>It is almost time</em><br />
<em> For the 4.0 release</em><br />
<em> And its awesomeness</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:72:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/08/wordpress-4-0-beta-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2014/08/wordpress-4-0-beta-4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 05:06:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3280";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:353:"The fourth and likely final beta for WordPress 4.0 is now available. We&#8217;ve made more than 250 changes in the past month, including: Further improvements to the editor scrolling experience, especially when it comes to the second column of boxes. Better handling of small screens in the media library modals. A separate bulk selection mode [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2003:"<p>The fourth and likely final beta for WordPress 4.0 is now available. We&#8217;ve made <a href="https://core.trac.wordpress.org/log?rev=29496&amp;stop_rev=29229&amp;limit=300">more than 250 changes</a> in the past month, including:</p>
<ul>
<li>Further improvements to the editor scrolling experience, especially when it comes to the second column of boxes.</li>
<li>Better handling of small screens in the media library modals.</li>
<li>A separate bulk selection mode for the media library grid view.</li>
<li>Improvements to the installation language selector.</li>
<li>Visual tweaks to plugin details and customizer panels.</li>
</ul>
<p><strong>We need your help</strong>. We’re still aiming for a release this month, which means the next week will be critical for identifying and squashing bugs. If you’re just joining us, please see <a href="https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven’t tested WordPress 4.0 yet, now is the time — and be sure to update the “tested up to” version for your plugins so they’re listed as compatible with 4.0.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="https://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta4.zip">download the beta here</a> (zip).</p>
<p><em>We are working hard</em><br />
<em>To finish up 4.0<br />
</em><em>Will you help us too?</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2014/08/wordpress-4-0-beta-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.9.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2014/08/wordpress-3-9-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2014/08/wordpress-3-9-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Aug 2014 19:04:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3269";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:377:"WordPress 3.9.2 is now available as a security release for all previous versions. We strongly encourage you to update your sites immediately. This release fixes a possible denial of service issue in PHP&#8217;s XML processing, reported by Nir Goldshlager of the Salesforce.com Product Security Team. It  was fixed by Michael Adams and Andrew Nacin of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2353:"<p>WordPress 3.9.2 is now available as a security release for all previous versions. We strongly encourage you to update your sites immediately.</p>
<p>This release fixes a possible denial of service issue in PHP&#8217;s XML processing, reported by <a href="https://twitter.com/nirgoldshlager">Nir Goldshlager</a> of the Salesforce.com Product Security Team. It  was fixed by Michael Adams and Andrew Nacin of the WordPress security team and David Rothstein of the <a href="https://www.drupal.org/SA-CORE-2014-004">Drupal security team</a>. This is the first time our two projects have coordinated joint security releases.</p>
<p>WordPress 3.9.2 also contains other security changes:</p>
<ul>
<li>Fixes a possible but unlikely code execution when processing widgets (WordPress is not affected by default), discovered by <a href="http://www.buayacorp.com/">Alex Concha</a> of the WordPress security team.</li>
<li>Prevents information disclosure via XML entity attacks in the external GetID3 library, reported by <a href="http://onsec.ru/en/">Ivan Novikov</a> of ONSec.</li>
<li>Adds protections against brute attacks against CSRF tokens, reported by <a href="http://systemoverlord.com/">David Tomaschik</a> of the Google Security Team.</li>
<li>Contains some additional security hardening, like preventing cross-site scripting that could be triggered only by administrators.</li>
</ul>
<p>We appreciated responsible disclosure of these issues directly to our security team. For more information, see the <a href="https://codex.wordpress.org/Version_3.9.2">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/3.9?stop_rev=29383&amp;rev=29411">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 3.9.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now&#8221;.</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.9.2 within 12 hours. (If you are still on WordPress 3.8.3 or 3.7.3, you will also be updated to 3.8.4 or 3.7.4. We don&#8217;t support older versions, so please update to 3.9.2 for the latest and greatest.)</p>
<p>Already testing WordPress 4.0? The third beta is <a href="https://wordpress.org/wordpress-4.0-beta3.zip">now available</a> (zip) and it contains these security fixes.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/08/wordpress-3-9-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Jul 2014 21:15:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3261";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:374:"WordPress 4.0 Beta 2 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can download the beta here (zip). For more of what’s new in version 4.0, check out [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1745:"<p>WordPress 4.0 Beta 2 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the <a href="https://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta2.zip">download the beta here</a> (zip).</p>
<p>For more of what’s new in version 4.0, <a href="https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">check out the Beta 1 blog post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Further refinements for the the plugin installation and media library experiences.</li>
<li>Updated TinyMCE, which now includes better indentation for lists and the restoration of the color picker.</li>
<li>Cookies are now tied to a session internally, so if you have trouble logging in, <a href="https://core.trac.wordpress.org/ticket/20276">#20276</a> may be the culprit.</li>
<li>Various bug fixes (there were <a href="https://core.trac.wordpress.org/log?rev=29228&amp;stop_rev=29060&amp;limit=200">nearly 170 changes</a> since last week).</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="https://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.0">everything we’ve fixed</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 10:17:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3248";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"WordPress 4.0 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4031:"<p>WordPress 4.0 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta1.zip">download the beta here</a> (zip).</p>
<p>4.0 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Previews of <a href="https://codex.wordpress.org/Embeds">embedding via URLs</a></strong> in the visual editor and the &#8220;Insert from URL&#8221; tab in the media modal. Try pasting a URL (such as a <a href="http://wordpress.tv/">WordPress.tv</a> or YouTube video) onto its own line in the visual editor. (<a href="https://core.trac.wordpress.org/ticket/28195">#28195</a>, <a href="https://core.trac.wordpress.org/ticket/15490">#15490</a>)</li>
<li>The <strong>Media Library</strong> now has a &#8220;grid&#8221; view in addition to the existing list view. Clicking on an item takes you into a modal where you can see a larger preview and edit information about that attachment, and you can navigate between items right from the modal without closing it. (<a href="https://core.trac.wordpress.org/ticket/24716">#24716</a>)</li>
<li>We&#8217;re freshening up the <strong>plugin install experience</strong>. You&#8217;ll see some early visual changes as well as more information when searching for plugins and viewing details. (<a href="https://core.trac.wordpress.org/ticket/28785">#28785</a>, <a href="https://core.trac.wordpress.org/ticket/27440">#27440</a>)</li>
<li><strong>Selecting a language</strong> when you run the installation process. (<a href="https://core.trac.wordpress.org/ticket/28577">#28577</a>)</li>
<li>The <strong>editor</strong> intelligently resizes and its top and bottom bars pin when needed. Browsers don&#8217;t like to agree on where to put things like cursors, so if you find a bug here, please also let us know your browser and operating system. (<a href="https://core.trac.wordpress.org/ticket/28328">#28328</a>)</li>
<li>We&#8217;ve made some improvements to how your keyboard and cursor interact with <strong>TinyMCE views</strong> such as the gallery preview. Much like the editor resizing and scrolling improvements, knowing about your setup is particularly important for bug reports here. (<a href="https://core.trac.wordpress.org/ticket/28595">#28595</a>)</li>
<li><strong>Widgets in the Customizer</strong> are now loaded in a separate panel. (<a href="https://core.trac.wordpress.org/ticket/27406">#27406</a>)</li>
<li>We&#8217;ve also made some changes to some <strong>formatting</strong> functions, so if you see quotes curling in the wrong direction, please file a bug report.</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.0">everything we’ve fixed</a> so far.</p>
<p><strong>Developers:</strong> Never fear, we haven&#8217;t forgotten you. There&#8217;s plenty for you, too &#8211; more on that in upcoming posts. In the meantime, check out the <a href="https://make.wordpress.org/core/2014/07/08/customizer-improvements-in-4-0/#customizer-panels">API for panels in the Customizer</a>.</p>
<p>Happy testing!</p>
<p><em>Plugins, editor</em><br />
<em>Media, things in between</em><br />
<em>Please help look for bugs</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.9.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2014/05/wordpress-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2014/05/wordpress-3-9-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:385:"After three weeks and more than 9 million downloads of WordPress 3.9, we&#8217;re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3106:"<p>After three weeks and more than 9 million downloads of <a title="WordPress 3.9 “Smith”" href="https://wordpress.org/news/2014/04/smith/">WordPress 3.9</a>, we&#8217;re pleased to announce that WordPress 3.9.1 is now available.</p>
<p>This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video playlists feature and made some adjustments to improve performance. For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=3.9.1">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/3.9?rev=28353&amp;stop_rev=28154">changelog</a>.</p>
<p>If you are one of the millions already running WordPress 3.9, we&#8217;ve started rolling out automatic background updates for 3.9.1. For sites <a href="https://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 3.9.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.9.1: <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="https://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="https://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="https://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="https://profiles.wordpress.org/imath">imath</a>, <a href="https://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="https://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, and <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/05/wordpress-3-9-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"https://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"https://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23571:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="https://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>
<div id="v-sAiXhCfV-1" class="video-player"><embed id="v-sAiXhCfV-1-video" src="https://v0.wordpress.com/player.swf?v=1.03&amp;guid=sAiXhCfV&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'https://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'https://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'https://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'https://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'https://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'https://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; height: 448px; " class="wp-video"><video class="wp-video-shortcode" id="video-3154-3" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=3" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="https://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/kawauso">Adam Harley (Kawauso)</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/adelval">adelval</a>, <a href="https://profiles.wordpress.org/ajay">Ajay</a>, <a href="https://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="https://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="https://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="https://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="https://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="https://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="https://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="https://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="https://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="https://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="https://profiles.wordpress.org/barry">Barry</a>, <a href="https://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="https://profiles.wordpress.org/bassgang">bassgang</a>, <a href="https://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="https://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="https://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="https://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="https://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="https://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="https://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="https://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="https://profiles.wordpress.org/bramd">Bram Duvigneau</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="https://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="https://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="https://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="https://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="https://profiles.wordpress.org/chouby">Chouby</a>, <a href="https://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="https://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="https://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="https://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="https://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="https://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="https://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="https://profiles.wordpress.org/ciantic">ciantic</a>, <a href="https://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="https://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="https://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="https://profiles.wordpress.org/corphi">Corphi</a>, <a href="https://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="https://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="https://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="https://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="https://profiles.wordpress.org/dpe415">DaveE</a>, <a href="https://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="https://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="https://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="https://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="https://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="https://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="https://profiles.wordpress.org/plocha">edik</a>, <a href="https://profiles.wordpress.org/oso96_2000">Eduardo Reveles</a>, <a href="https://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="https://profiles.wordpress.org/enej">enej</a>, <a href="https://profiles.wordpress.org/ericlewis">Eric Lewis</a>, <a href="https://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="https://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="https://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="https://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="https://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="https://profiles.wordpress.org/fboender">fboender</a>, <a href="https://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="https://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="https://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/genkisan">genkisan</a>, <a href="https://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="https://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="https://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="https://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="https://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="https://profiles.wordpress.org/tivnet">Gregory Karpinsky (@tivnet)</a>, <a href="https://profiles.wordpress.org/hakre">hakre</a>, <a href="https://profiles.wordpress.org/hanni">hanni</a>, <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="https://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="https://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="https://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="https://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="https://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="https://profiles.wordpress.org/janrenn">janrenn</a>, <a href="https://profiles.wordpress.org/jaycc">JayCC</a>, <a href="https://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="https://profiles.wordpress.org/jenmylo">Jen</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jesin">Jesin A</a>, <a href="https://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="https://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="https://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="https://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="https://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="https://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="https://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="https://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="https://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="https://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="https://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="https://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="https://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="https://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="https://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="https://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="https://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="https://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="https://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="https://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="https://profiles.wordpress.org/kerikae">kerikae</a>, <a href="https://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="https://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="https://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="https://profiles.wordpress.org/kitchin">kitchin</a>, <a href="https://profiles.wordpress.org/klihelp">klihelp</a>, <a href="https://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/ldebrouwer">ldebrouwer</a>, <a href="https://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="https://profiles.wordpress.org/lpointet">lpointet</a>, <a href="https://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="https://profiles.wordpress.org/lkwdwrd">Luke Woodward</a>, <a href="https://profiles.wordpress.org/nofearinc">Mario Peshev</a>, <a href="https://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="https://profiles.wordpress.org/marventus">Marventus</a>, <a href="https://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="https://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="https://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="https://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="https://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="https://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="https://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="https://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="https://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="https://profiles.wordpress.org/meloniq">meloniq</a>, <a href="https://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="https://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="https://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="https://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="https://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="https://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="https://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="https://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="https://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="https://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="https://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="https://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="https://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="https://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="https://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="https://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="https://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="https://profiles.wordpress.org/nivijah">Nivi Jah</a>, <a href="https://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="https://profiles.wordpress.org/olivm">olivM</a>, <a href="https://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="https://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="https://profiles.wordpress.org/patricknami">patricknami</a>, <a href="https://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="https://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="https://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="https://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="https://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="https://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="https://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="https://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="https://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="https://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="https://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="https://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="https://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="https://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="https://profiles.wordpress.org/richard2222">Richard</a>, <a href="https://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="https://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="https://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/robmiller">robmiller</a>, <a href="https://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="https://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="https://profiles.wordpress.org/roothorick">roothorick</a>, <a href="https://profiles.wordpress.org/ruudjoyo">Ruud Laan</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="https://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="https://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="https://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="https://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="https://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="https://profiles.wordpress.org/scribu">scribu</a>, <a href="https://profiles.wordpress.org/sdasse">sdasse</a>, <a href="https://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="https://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="https://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="https://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="https://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="https://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="https://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="https://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="https://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="https://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="https://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="https://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="https://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="https://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="https://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="https://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="https://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="https://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="https://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="https://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="https://profiles.wordpress.org/tbrams">tbrams</a>, <a href="https://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="https://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="https://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="https://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="https://profiles.wordpress.org/topquarky">topquarky</a>, <a href="https://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="https://profiles.wordpress.org/toru">Toru Miki</a>, <a href="https://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="https://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="https://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="https://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="https://profiles.wordpress.org/wawco">wawco</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="https://profiles.wordpress.org/xsonic">xsonic</a>, <a href="https://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="https://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="https://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="https://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="https://make.wordpress.org/">Make WordPress</a> and our <a href="https://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"https://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2273:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="//wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="//make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="//make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="//make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="//make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"https://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2341:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="https://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:32:"https://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 21 Oct 2014 04:37:18 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:37:"https://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Wed, 15 Oct 2014 13:39:33 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130910170210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (516, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1413909439', 'no') ; 
INSERT INTO `wp_options` VALUES (517, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1413866239', 'no') ; 
INSERT INTO `wp_options` VALUES (518, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1413909441', 'no') ; 
INSERT INTO `wp_options` VALUES (519, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: Easily Edit a Post or Page Using The Slash Edit Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=32149";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wptavern.com/easily-edit-a-post-or-page-using-the-slash-edit-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2060:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/SlashEditFeaturedImage.png" rel="prettyphoto[32149]"><img class="aligncenter size-full wp-image-32264" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/SlashEditFeaturedImage.png?resize=650%2C200" alt="Slash Edit Featured Image" /></a></p>
<p>If you&#8217;re not a fan of the admin bar or it&#8217;s disabled and you want a shortcut to edit posts in WordPress, you might be interested in a new plugin called <a title="https://wordpress.org/plugins/slash-edit/" href="https://wordpress.org/plugins/slash-edit/">Slash Edit</a>. Developed by <a title="http://www.ronalfy.com/" href="http://www.ronalfy.com/">Ronald Huereca</a>, Slash Edit adds the ability to edit the following items by adding <strong>/edit</strong> to the end of a url.</p>
<ul>
<li>Posts</li>
<li>Pages</li>
<li>Custom Post Types</li>
<li>Author and Taxonomy Archives</li>
</ul>
<p>To load the appropriate editing interface, visit a post or page while logged into WordPress and add <strong>/edit</strong> to the end of the url. It can also be used as a shortcut to login to the backend of WordPress.</p>
<p>Huereca works in an environment where the admin bar is consistently disabled. He created the plugin to provide a convenient way to edit pages or posts without having to search for them in the backend. &#8220;I thought, wouldn&#8217;t it be cool to just add &#8220;/edit&#8221; to the end of a post or page and be redirected to the right place in the admin panel?&#8221;</p>
<p>Huereca doesn&#8217;t know what else could be added to the plugin to fulfill its basic purpose. &#8220;I&#8217;m not sure how much farther this plugin can go, but the WordPress community is ingenious as far as feature requests, so I&#8217;m eager to get feedback on the base feature set.&#8221; I tested the plugin on WordPress 4.0 and it works as advertised. To keep tabs on development, you can <a title="https://github.com/ronalfy/slash-edit" href="https://github.com/ronalfy/slash-edit">follow the project</a> on Github.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 21 Oct 2014 03:06:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: Jason Schuller to Re-Enter WordPress Theme Market with Niche Admin Designs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=32202";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:94:"http://wptavern.com/jason-schuller-to-re-enter-wordpress-theme-market-with-niche-admin-designs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7575:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/pickle-preview.jpg" rel="prettyphoto[32202]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/pickle-preview.jpg?resize=972%2C462" alt="pickle-preview" class="aligncenter size-full wp-image-32216" /></a></p>
<p><a href="http://jason.sc/" target="_blank">Jason Schuller</a>, the original founder of the <a href="http://press75.com/" target="_blank">Press75</a> theme company, has been off the radar for a few years as he pursued experiments with alternative publishing platforms. He officially exited the commercial WordPress theme business earlier this year when <a href="http://wptavern.com/press75-acquired-by-westwerk-for-undisclosed-amount" target="_blank">Press75 was acquired by Westwerk</a>, following a sharp decline in the shop&#8217;s monthly revenue.</p>
<p>Prior to selling his company, Schuller had begun to focus more on his experimental projects, <a href="http://dropplets.com/" target="_blank">Dropplets</a>, <a href="https://leeflets.com/" target="_blank">Leeflets</a>, and <a href="https://cinemati.co/" target="_blank">Cinematico</a>. Over the years, he had become disillusioned with the software, as he watched WordPress become increasingly more complex. This frustration, coupled with the weight of complex frameworks that started devouring the WordPress theme market, essentially vaporized his passion for the software and pushed him out to make something new.</p>
<p>Earlier this year, in an <a href="http://wptavern.com/interview-with-jason-schuller-founder-of-press75-com" target="_blank">interview</a> with Jeff Chandler, Schuller expressed his dissatisfaction with trying to make WordPress do what he wanted and said that he wouldn&#8217;t be concentrating his efforts on WordPress in the immediate future.</p>
<h3>Video Preview of Custom WordPress Admin for the &#8220;Pickle&#8221; Project</h3>
<p>In his never-ending quest to simplify publishing online, Schuller has once again picked up WordPress to experiment with creating a radically simplified admin design for <a href="https://leeflets.com/templates?template=pickle" target="_blank">Pickle</a>, his restaurant-themed HTML template.</p>
<blockquote class="twitter-tweet" width="550"><p>A short video preview of my <a href="https://twitter.com/hashtag/WordPress?src=hash">#WordPress</a> admin redesign for “Pickle”: <a href="http://t.co/lvQtgIaAWP">http://t.co/lvQtgIaAWP</a> <a href="https://twitter.com/hashtag/design?src=hash">#design</a></p>
<p>&mdash; Jason Schuller (@jschuller) <a href="https://twitter.com/jschuller/status/524235736166330368">October 20, 2014</a></p></blockquote>
<p></p>
<p>Traditionally, making a template like that editable in WordPress ends up being a complex thing for your average user to navigate in the admin. The <a href="http://jason.sc/pickle-preview" target="_blank">preview video</a> shows how Schuller has re-imagined the admin for his niche one page template.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/pickle-admin.jpg" rel="prettyphoto[32202]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/pickle-admin.jpg?resize=964%2C520" alt="pickle-admin" class="aligncenter size-full wp-image-32235" /></a></p>
<p>He has essentially removed the admin, de-registered all the styles and many of the components, in an effort to create a custom CMS for this particular template. The result is a better correlation between the content editing experience and the actual website, with simplified action buttons.</p>
<p>If you watch the preview, you&#8217;ll hear Schuller summarize why he created the simplified admin:</p>
<blockquote><p>This is my biggest issue with WordPress right now. It doesn&#8217;t scale backward for minimalist websites like this. The CMS should reflect, in my opinion, what you&#8217;re trying to accomplish with your website, and all of these unnecessary components of WordPress just really don&#8217;t need to be here unless you need them for what you&#8217;re trying to accomplish.</p></blockquote>
<p>Schuller said that it took him approximately two days to customize the WordPress admin to suit his template. <strong>&#8220;I&#8217;m nearly finished with it. It’s going to launch as a downloadable theme first and then I’ll be launching a hosted version as well,&#8221;</strong> he said.</p>
<p>The theme will not be launching on Leeflets but rather on a new domain, yet to be determined, bringing Schuller back into the WordPress theme market. Why is he returning?</p>
<p>&#8220;With this particular project, I really just wanted to get my vision out of my head as quick as possible,&#8221; he said. &#8220;With that in mind, I couldn&#8217;t see creating a custom CMS just for Pickle, so I figured WordPress would be the best way to do that quickly. Plus, you still can’t ignore WordPress’s reach.&#8221;</p>
<p>I asked Schuller if the Pickle admin theme is a one time project or if he plans to create more niche admin themes to accompany his designs. &#8220;If Pickle goes well, I have a few other niche admins in mind for specific templates,&#8221; he replied.</p>
<p><strong>&#8220;My goal is really simple &#8211; to help my customers/users create and manage websites. If WordPress helps me do that in an efficient way, I’m all for it. But I’ll be doing it my way this time around,&#8221;</strong> he emphasized.</p>
<p>Schuller&#8217;s minimalist approach to the WordPress admin is something that he hopes will be easier for his target market to wrap their brains around. The popularity of the Pickle template is what spurred him on to create an editable version using WordPress. &#8220;I wasn’t expecting much when I released the Pickle HTML template,&#8221; he said. &#8220;But it was an instant hit. There are quite a few people helping restaurants create websites with it. That’s what triggered the idea to make a WordPress version.&#8221;</p>
<p>At the moment Schuller is in touch with his market on a very small scale, but he hopes that it will expand with a successful launch of the Pickle theme. &#8220;My hope is that the WordPress version makes it even more enticing for businesses looking for a minimalist website/solution.&#8221;</p>
<p>Schuller has identified a problem that many developers are hoping to solve. WordPress core is moving towards bridging the separation between the editing experience and the display of the content, with improvements to the customizer and experimental projects like the frontend editor. Others hope that the new JSON REST API will make it easier for developers to create custom admins.</p>
<p>These changes cannot come soon enough, but will they be fully able to provide a more natural editing experience for users? Those, like Schuller, who have wrestled with dissatisfaction, have a decent shot at creating a revolutionary editing experience for the 10 year old platform. His inspiring work on the Pickle admin breaks WordPress out of the box and forces developers to look at the content editing experience in a new way.</p>
<p>A more modular admin that can easily be scaled back for minimalist websites is something that would allow developers to truly customize the CMS for any niche template or project. The WordPress admin then becomes a chameleon of sorts, able to disappear into its surroundings with the content in focus. Schuller&#8217;s <a href="http://jason.sc/pickle-preview" target="_blank">Pickle experiment</a> is a good example of this, and likely part of a trend that we&#8217;ll see more in the future.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Oct 2014 22:14:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: The First “Rate and Review a Plugin Day” is a Success";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=32151";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wptavern.com/the-first-rate-and-review-a-plugin-day-is-a-success";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7981:"<p>Thanks to everyone who participated in the first &#8220;<a title="http://wptavern.com/rate-and-review-a-wordpress-plugin-day-set-for-october-17th" href="http://wptavern.com/rate-and-review-a-wordpress-plugin-day-set-for-october-17th">Rate and Review a plugin day&#8221;</a>. After reviewing the #<a title="https://twitter.com/hashtag/wppluginreviewday?src=hash" href="https://twitter.com/hashtag/wppluginreviewday?src=hash">wppluginreviewday</a> hashtag on Twitter, it&#8217;s clear that a lot of people submitted reviews to their favorite plugins. Based on an <a title="https://twitter.com/richardtape/status/523331218973405184" href="https://twitter.com/richardtape/status/523331218973405184">estimate by Richard Tape</a>, 455 reviews were published on October 17th. When compared to 254 reviews on October 16th, that&#8217;s an increase of 180%. Here are a few noteworthy mentions of the hashtag in action.</p>
<blockquote class="twitter-tweet" width="550"><p>Wrote a review for <a href="https://twitter.com/eddwp">@eddwp</a> here <a href="https://t.co/zvwWNJaGtu">https://t.co/zvwWNJaGtu</a> Awesome feeling! <a href="https://twitter.com/hashtag/wppluginreviewday?src=hash">#wppluginreviewday</a></p>
<p>&mdash; Bharath Mandava  (@_mandava) <a href="https://twitter.com/_mandava/status/523321112222900225">October 18, 2014</a></p></blockquote>
<p></p>
<blockquote class="twitter-tweet" width="550"><p>So I delivered a plugin review on .org today. <a href="http://t.co/4ua0iG0XjQ">http://t.co/4ua0iG0XjQ</a> <a href="https://twitter.com/hashtag/wppluginreviewday?src=hash">#wppluginreviewday</a> /cc: <a href="https://twitter.com/stevengliebe">@stevengliebe</a> :)</p>
<p>&mdash; David Decker (@deckerweb) <a href="https://twitter.com/deckerweb/status/523217428311191552">October 17, 2014</a></p></blockquote>
<p></p>
<blockquote class="twitter-tweet" width="550"><p>For Rate &amp; Review a <a href="https://twitter.com/hashtag/WordPress?src=hash">#WordPress</a> Plugin Day I gave kudos to <a href="https://twitter.com/iThemesSecurity">@iThemesSecurity</a> <a href="https://twitter.com/hashtag/wppluginreviewday?src=hash">#wppluginreviewday</a></p>
<p>&mdash; BobWP (@bobWP) <a href="https://twitter.com/bobWP/status/523121578268041216">October 17, 2014</a></p></blockquote>
<p></p>
<h2>Observations I Made While Submitting Reviews</h2>
<p>It took 90 minutes to rate and review the plugins I&#8217;ve depended on for years. I noticed some of the plugins haven&#8217;t been updated since 2010. In some cases, the last review a plugin received was from 2012 or earlier.</p>
<p>When I announced the holiday, I asked users to browse to the bottom of the plugin’s description page and click on the <em>broken</em> or <em>works</em> box. As I submitted my reviews, I forgot about the compatibility box. When submitting a review, there is a drop down menu to select which version of WordPress I&#8217;m using. I used this in combination with my review to tell people if the plugin works or not.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/WPPluginReviewSubmissionForm.png" rel="prettyphoto[32151]"><img class="size-full wp-image-32152" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/WPPluginReviewSubmissionForm.png?resize=752%2C502" alt="WordPress Plugin Review Submission Form" /></a>WordPress Plugin Review Submission Form
<p>Clicking the works or doesn&#8217;t work button is an easy task but it&#8217;s a <strong>separate action</strong> from submitting a review. It&#8217;s also the last widget on the description page and depending on the length of the description, may be hidden from view. I suggest merging the compatibility box into the process of submitting a review so it&#8217;s one action. Even though submitting compatibility information can be as simple as pressing a mouse button, not many do it.</p>
<h2>The Disconnect Between WordPress.org and The Backend of WordPress</h2>
<p>Your ratings, reviews, and compatibility checks are contributions to WordPress. It’s actionable data that millions of people use to determine whether or not to use a plugin. The backend of WordPress is an area millions of users interact with yet, the option to rate and review plugins as well as submit compatibility information doesn&#8217;t exist. The plugin details modal doesn&#8217;t show the compatibility box on the plugin&#8217;s description page and although you can read reviews, you can&#8217;t rate or review plugins.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/PluginDetailsModal.png" rel="prettyphoto[32151]"><img class="size-full wp-image-32173" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/PluginDetailsModal.png?resize=684%2C723" alt="Current Plugin Details Modal" /></a>Plugin Details Modal
<p>The plugin management page in WordPress hasn&#8217;t seen a visual upgrade in a long time. Here&#8217;s what it looks like in WordPress 4.0.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/PluginManagementPage.png" rel="prettyphoto[32151]"><img class="size-full wp-image-32176" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/PluginManagementPage.png?resize=1025%2C530" alt="WordPress 4.0 Plugin Management Page" /></a>WordPress 4.0 Plugin Management Page
<p>WordPress 3.9 <a title="http://wptavern.com/wordpress-4-0-benny-now-available-for-download" href="http://wptavern.com/wordpress-4-0-benny-now-available-for-download">revamped the theme browsing experience</a> while 4.0 introduced a refreshed <a title="http://wptavern.com/wordpress-4-0-benny-now-available-for-download" href="http://wptavern.com/wordpress-4-0-benny-now-available-for-download">plugin install and search experience</a>. Perhaps it&#8217;s time to refresh the plugin management page. One suggestion is to create two different list views. The management page in 4.0 could be the slim, detailed view. The enhanced view could use the card concept as seen on the Add Plugins page. Instead of displaying the crowd sourced information, you&#8217;d be able to rate and review the plugin and submit compatibility info from within the card.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordPressAddNewPluginCards.png" rel="prettyphoto[32151]"><img class="size-full wp-image-32179" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordPressAddNewPluginCards.png?resize=1025%2C485" alt="WordPress 4.0 Plugin Cards" /></a>WordPress 4.0 Plugin Cards
<p>The problem with two different views is that a sub-set of users wouldn&#8217;t see the card view and stick with the default. In order to maximize the potential of obtaining crowd sourced data, the submission points have to be accessible by as many people as possible.</p>
<h2>Tighter Integration Between The Backend and WordPress.org</h2>
<p>In order to submit ratings and reviews, you need to be logged into a WordPress.org user account. I&#8217;m unsure on how to properly address this issue. One idea is for WordPress to provide a connection similar to Jetpack where I connect a WordPress powered site to my WordPress.org account. This could also act as an opt-in mechanism. Ultimately, I&#8217;d like to see better integration between the WordPress backend and the WordPress.org website.</p>
<p>I&#8217;m not advocating that I be able to browse the WordPress.org website from the backend of WordPress, that&#8217;s what browsers are for. I see plenty of opportunities to connect certain actions on WordPress.org to the backend of WordPress, such as the ability to create a forum post to receive support.</p>
<h2>A New Annual Tradition</h2>
<p>While you don&#8217;t need a special day to review plugins, it&#8217;s a unique feeling to do something so many others across the world are doing at the same time. I&#8217;m encouraged to see so many people who have rated and reviewed their favorite plugins. Based on the feedback we&#8217;ve received, this will likely become an annual tradition.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Oct 2014 18:54:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:101:"WPTavern: Some Like It Neat: A Free WordPress Starter Theme Built with Underscores, Bourbon, and Neat";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=32135";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:108:"http://wptavern.com/some-like-it-neat-a-free-wordpress-starter-theme-built-with-underscores-bourbon-and-neat";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6075:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/bourbon-neat.jpg" rel="prettyphoto[32135]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/bourbon-neat.jpg?resize=1024%2C488" alt="photo credit: j03 - cc" class="size-full wp-image-32137" /></a>photo credit: <a href="https://www.flickr.com/photos/j03/2035547120/">j03</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc/2.0/">cc</a>
<p><a href="https://wordpress.org/themes/some-like-it-neat" target="_blank">Some Like it Neat</a> is a new starter theme for WordPress, based on the popular ultra-minimal <a href="http://underscores.me" target="_blank">Underscores</a> theme. It also incorporates <a href="http://bourbon.io" target="_blank">Bourbon</a>, a lightweight mixin library for <a href="http://sass-lang.com/" target="_blank">Sass</a>. On top of that it adds <a href="http://neat.bourbon.io" target="_blank">Neat</a>, which applies a semantic grid framework for Sass and Bourbon, enabling you to build any responsive layout that you can dream up.</p>
<p>Since Some Like It Neat is a simple starter theme, there&#8217;s not much to see in the screenshot, apart from a relatively blank canvas, waiting to be shaped and styled.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/some-like-it-neat.png" rel="prettyphoto[32135]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/some-like-it-neat.png?resize=880%2C660" alt="some-like-it-neat" class="aligncenter size-full wp-image-32140" /></a></p>
<p>The power of this theme lies in the tools that it incorporates. Some Like It Neat expedites the creation of a modern frontend development workflow for WordPress theming with responsive grids and a few prepackaged styles. The theme offers support for the following tools:</p>
<ul>
<li><a href="http://bourbon.io/" target="_blank">Bourbon</a>: A simple and lightweight mixin library for Sass</li>
<li><a href="http://neat.bourbon.io" target="_blank">Neat</a>: A lightweight semantic grid framework for Sass and Bourbon</li>
<li><a href="http://bitters.bourbon.io/" target="_blank">Bitters</a>: Scaffold styles, variables and structure for Bourbon projects</li>
<li><a href="http://refills.bourbon.io/" target="_blank">Refills</a>: Prepackaged patterns and components, built on top of Bourbon, Bitters, and Neat</li>
<li><a href="http://bower.io/" target="_blank">Bower</a>: A frontend package manager</li>
</ul>
<p>This is essentially everything you need for a Bourbon-soaked development workflow. Developers starting with this theme should already be familiar with Sass, since it&#8217;s the foundation for using Bourbon and Neat. If you need a Sass primer, Sitepoint has a great <a href="http://www.sitepoint.com/sass-for-wordpress-developers/" target="_blank">tutorial</a> on the basics. WP Beginner also has a <a href="http://www.wpbeginner.com/wp-tutorials/introduction-to-sass-for-new-wordpress-theme-designers/" target="_blank">quick introduction</a> to help WordPress theme designers get started with Sass.</p>
<p>Some Like It Neat also allows for <a href="http://gulpjs.com/" target="_blank">Gulp.js</a> task automation. <a href="http://alexhasnicehair.com/" target="_blank">Alex Vasquez</a>, the theme&#8217;s creator, says that this feature still has room for improvement. The theme currently includes support for the following tasks:</p>
<ul>
<li><code>gulp watch</code> &#8211; Starts up Gulp and watches your scss, js and php folder for changes, writes them out and refreshes the browser for you</li>
<li><code>gulp build</code> &#8211; Removes unnecessary files and packs up the required files into a nice and neat, installable, zip package</li>
</ul>
<p>Additionally, Some Like It Neat adds support for the <a href="https://github.com/zamoose/themehookalliance" target="_blank">Theme Hook Alliance</a> (THA), a community-driven project that offers a standardized set of third-party action hooks to theme developers to implement for more flexibility. THA has a growing list of <a href="https://github.com/zamoose/themehookalliance#tha-compatible-themes" target="_blank">compatible themes</a>. Vasquez opted for adding it to help keep things within the theme cleaner and easier to maintain.</p>
<h3>Why Use Bourbon and Neat?</h3>
<p>Incorporating Bourbon and its parallel projects into your WordPress theme is a matter of personal preference. In the past, Vasquez had used frontend frameworks such as Bootstrap and Foundation, but after discovering Bourbon+Neat, he found that it gave him a more efficient approach to theme creation:</p>
<blockquote><p>To achieve the responsiveness required of various projects, I would have to tear up my HTML, input my own selector classes and what have you, in addition to changing my CSS. I didn&#8217;t like it. I heard about <a href="http://neat.bourbon.io" target="_blank">Neat</a> and really liked its approach to a grid framework. You keep your HTML structure the way you like and all of the styling in your Sass files.</p></blockquote>
<p>If that sounds like a better workflow for you, then you may want to set aside some time to give this starter theme a try. It can be used  as a parent theme from which you create a highly customized child theme. Vasquez has outlined how to <a href="https://github.com/digisavvy/some-like-it-neat#getting-started" target="_blank">get started</a> in the documentation, which will walk you through installing Node, Sass, Gulp.js, etc. He also posted a handy <a href="https://github.com/digisavvy/some-like-it-neat#folder-structure" target="_blank">folder structure</a> as an example for how projects are structured with the starter theme.</p>
<p><a href="https://wordpress.org/themes/some-like-it-neat" target="_blank">Some Like It Neat</a> is <a href="http://alexhasnicehair.com/" target="_blank">Alex Vasquez</a>&#8216;s first submission to the official WordPress Themes Directory. You can download it via your admin theme browser or from its <a href="https://github.com/digisavvy/some-like-it-neat" target="_blank">GitHub</a> repository.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Oct 2014 18:04:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"Matt: Life and Work at the Distributed Wonderland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44293";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://ma.tt/2014/10/life-and-work-at-the-distributed-wonderland/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:229:"<p>Luca Sartoni writes <a href="http://lucasartoni.com/2014/10/14/how-i-fell-into-the-rabbit-hole-life-and-work-at-the-distributed-wonderland/">How I fell into the rabbit hole: life and work at the distributed wonderland</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Oct 2014 16:26:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Matt: Run Better";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44263";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:32:"http://ma.tt/2014/10/run-better/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:544:"<p>Joe Boydston, the self-described &#8220;crazy running guy&#8221; who runs as far as 90+ miles from the airport to WordCamps or meetups when he lands, has <a href="http://crazyrunningguy.wordpress.com/2014/10/06/run-better/">written a bit about how to run better</a>. At our <a href="http://ma.tt/2014/09/automattic-grand-meetup-2014/">company meetup</a> he ran running workshops and coached a lot of people including myself, and applying his suggestions <a href="http://ma.tt/2014/10/streak/">I&#8217;ve been able to do a lot better</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 19 Oct 2014 23:51:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Matt: Pink Drill Bits";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44261";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:37:"http://ma.tt/2014/10/pink-drill-bits/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:335:"<p><a href="http://www.salon.com/2014/10/08/susan_g_komen_teams_up_with_fracking_company_introduces_pink_drill_bits_for_the_cure/">Fracking company teams up with Susan G. Komen, introduces pink drill bits for the cure</a>, presented without comment. <cite>Hat tip: <a href="http://spitfirestrategies.com/">Kristin Grimm</a>.</cite></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 18 Oct 2014 23:27:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: Themosis Object-Oriented Development Framework for WordPress Now Available";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=32082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:94:"http://wptavern.com/themosis-object-oriented-development-framework-for-wordpress-now-available";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4107:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/routes.png" rel="prettyphoto[32082]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/routes.png?resize=1025%2C598" alt="routes" class="aligncenter size-full wp-image-26649" /></a></p>
<p>Version 1.0 of the <a href="http://wptavern.com/themosis-object-oriented-development-framework-for-wordpress-now-in-beta" target="_blank">Themosis development framework</a> is now available. Belgium-based application developer <a href="http://jlambe.be/" target="_blank">Julien Lambé</a> created Themosis in order to accelerate object-oriented development with WordPress. It offers a routing system for managing WordPress behavior on an application level and also includes a Laravel-esque templating engine for view files. Last week Lambé announced that the framework is now out of beta and ready for public use.</p>
<p><a href="http://framework.themosis.com/" target="_blank">Themosis</a>, which Lambé describes as <strong>“a mix between WordPress best practices and a typical MVC framework,”</strong> has evolved considerably since its beta period. Version 1.0 includes dozens of improvements based on developer feedback.</p>
<p>The website has been updated to provide complete <a href="http://framework.themosis.com/docs/" target="_blank">documentation</a> and code examples to help developers get started. <a href="http://framework.themosis.com/docs/installation/" target="_blank">Installation</a> is quick and easy, as Themosis uses <a href="https://getcomposer.org/" target="_blank">Composer</a> for dependency package management, so you can install and update everything needed in a matter of seconds. The framework is designed with respect to WordPress best practices and should work seamlessly with its APIs and plugins.</p>
<p>Themosis comes with local and production environments pre-configured in order to facilitate collaboration. Once you register your database credentials and application URLS, you&#8217;ll be able to define the different environment configurations, making it easy to move between development and production.</p>
<p>The <a href="http://framework.themosis.com/docs/framework/" target="_blank">framework guide</a> contains everything you need to know to get started structuring and building your application. The <a href="http://framework.themosis.com/docs/routing/" target="_blank">route API</a> docs cover all the conditional tags available with code samples for basic routing methods. Lambé describes the route system as &#8220;an enhanced &#8216;if&#8217; statement,&#8221; which is essentially based on WordPress conditional template tags and a closure callback.</p>
<p>The framework includes classes for handling AJAX requests, custom post types, metaboxes, custom fields, taxonomies, options, validation, and more. It also adds a unique set of <a href="http://framework.themosis.com/docs/helpers/" target="_blank">Helpers</a> which act as framework utility functions that run on the global scope.</p>
<p>Lambé has now separated the <a href="http://www.themosis.com/" target="_blank">Themosis studio</a> from the framework, which can be found at <a href="http://framework.themosis.com" target="_blank">framework.themosis.com</a>. He is launching a Themosis web agency, specializing in WordPress design and development, in order to fund future development of the framework to ensure its future.</p>
<p>The Themosis framework is an interesting option that could be very helpful for new WordPress developers, especially those who are used to using Laravel or those who simply want to structure and organize their code like a typical MVC framework. It provides another avenue for getting started using a structure that may be more approachable for PHP developers who are new to working with WordPress.</p>
<p>Themosis is an open source tool that Lambé decided to share with the community, and it will remain free to use. If you want to contribute to the project or report any issues, the framework can also be found on <a href="https://github.com/themosis/" target="_blank">GitHub</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Oct 2014 22:27:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:92:"WPTavern: Watch The Q&amp;A Session Between Matt Mullenweg and Om Malik From WordCamp Europe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=32059";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wptavern.com/watch-the-qa-session-between-matt-mullenweg-and-om-malik-from-wordcamp-europe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1950:"<p>Some of the sessions recorded at <a title="http://wordpress.tv/event/wordcamp-europe-2014/" href="http://wordpress.tv/event/wordcamp-europe-2014/">WordCamp Europe</a> are now available to watch on <a title="http://wordpress.tv" href="http://wordpress.tv">WordPress.TV</a>. The rest of the sessions will be added in the coming weeks. Included in the first batch of videos is the <a title="http://wordpress.tv/2014/10/03/matt-mullenweg-om-malik-qa/" href="http://wordpress.tv/2014/10/03/matt-mullenweg-om-malik-qa/">question and answer session</a> between Matt Mullenweg and Om Malik.</p>
<p>The session is an hour long and includes Mullenweg&#8217;s thoughts on the current status of WordPress, the media library, and what the platform may evolve into. One of the questions asked during the session is the role of women in the WordPress ecosystem.</p>
<p>At the 47 minute mark, you can hear the infamous &#8220;we love women&#8221; comment from a member of the audience. Mullenweg responds with &#8220;come onnnnn&#8221; with applause from the audience. Helen Hou-Sandí, who lead the release of WordPress 4.0, explains why saying &#8220;we love women&#8221; can cause <a title="http://helenhousandi.com/2014/09/unintentional-destruction/" href="http://helenhousandi.com/2014/09/unintentional-destruction/">unintentional destruction</a>.</p>
<p>Near the 53:40 minute mark, Mullenweg is asked, &#8220;How much should WordPress businesses be contributing to WordPress and involved with the project?&#8221; This is the question that prompted the 5% figure and his post, <a title="http://ma.tt/2014/09/five-for-the-future/" href="http://ma.tt/2014/09/five-for-the-future/">Five for the Future</a>.</p>
<p></p>
<p>This is a great session filled with information related to WordPress, Automattic, open source in general, and the future of the platform. If you attended the session live or watched the video, let us know your thoughts in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Oct 2014 18:36:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Matt: Moving into Management";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44170";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2014/10/moving-into-management/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:384:"<p>&#8220;The biggest misconception engineers have when thinking about moving into management is they think it&#8217;s a promotion.&#8221; &#8212; Lindsay Holmwood writes <a href="http://fractio.nl/2014/09/19/not-a-promotion-a-career-change/">It&#8217;s not a promotion &#8211; it&#8217;s a career change</a>. <cite>Hat tip: <a href="http://pento.net/">Gary Pendergast</a>.</cite></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Oct 2014 18:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: New Plugin Adds Open Source Emoji One Support to WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31456";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://wptavern.com/new-plugin-adds-open-source-emoji-one-support-to-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4669:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/emoji-one.jpg" rel="prettyphoto[31456]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/emoji-one.jpg?resize=831%2C376" alt="emoji-one" class="aligncenter size-full wp-image-31461" /></a></p>
<p><a href="http://emojione.com/" target="_blank">Emoji One</a> is a new open source emoji set that is the first of its kind, designed specifically for the web. The set boasts more than 840 emoji. It was created to solve the perennial problem of translating emoji code from mobile devices while legally displaying the corresponding emoji icon on the web. The idea is to avoid displaying those ugly blank squares that you see so often, as illustrated on the Emoji One website:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/emoji-one-problem-1.jpg" rel="prettyphoto[31456]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/emoji-one-problem-1.jpg?resize=795%2C392" alt="emoji-one-problem-1" class="aligncenter size-full wp-image-32029" /></a></p>
<p>Emoji One was also created to provide consistency across various mobile and web platforms. As things currently stand, you tend to get a slight variation in display depending on the mobile platform used to input the emoji.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/emoji-one-problem-2.jpg" rel="prettyphoto[31456]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/emoji-one-problem-2.jpg?resize=824%2C464" alt="emoji-one-problem-2" class="aligncenter size-full wp-image-32033" /></a></p>
<p>Emoji One is tackling both of these problems head on with its new open source emoji set. It&#8217;s released under the MIT license, which is GPL-compatible. Check out a <a href="http://emojione.com/demo" target="_blank">live demo</a> of Emoji One to see the set in action.</p>
<h3>WP Emoji One</h3>
<p><a href="https://wordpress.org/plugins/wp-emoji-one/" target="_blank">WP Emoji One</a> is the first plugin to bring Emoji One support to WordPress posts and pages. It is based on work from the <a href="https://wordpress.org/plugins/typepad-emoji-for-tinymce/" target="_blank">TypePad Emoji For TinyMCE</a> plugin. The emoji chooser can be launched via a button added to the visual editor.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/visual-editor-emoji-one.jpg" rel="prettyphoto[31456]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/visual-editor-emoji-one.jpg?resize=822%2C264" alt="visual-editor-emoji-one" class="aligncenter size-full wp-image-32047" /></a></p>
<p>Clicking on the button opens a modal window with the Emoji One library, along with the option to choose the pixel size of the emoji inserted into the content.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/emoji-one-modal.jpg" rel="prettyphoto[31456]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/emoji-one-modal.jpg?resize=818%2C598" alt="emoji-one-modal" class="aligncenter size-full wp-image-32049" /></a></p>
<p>You don&#8217;t have to install anything on your mobile device to use Emoji One; just continue to use emoji as you have been. The WordPress plugin simply provides a more consistent experience for displaying emoji on the web.</p>
<p>I checked with the WP Emoji One plugin author to inquire about using the emoji in comments. He plans to add them to comments in the next release. BuddyPress and bbPress integration would also be very handy, as social sites are likely to derive greater benefits from offering emoji support.</p>
<p>Emoji One only recently launched on September 11, 2014. The team is currently working on creating the 250 new emojis that <a href="http://www.unicode.org/" target="_blank">Unicode</a> approved in June 2014, and will make those available soon.</p>
<p>You may have already seen Emjoi One icons in the wild here and there. The WordPress-powered Emoji One blog recently highlighted <a href="http://www.emojione.com/blog/slack-adds-emoji-one-gets-more-awesome/" target="_blank">Slack&#8217;s integration of Emoji One</a> as one of its default emoji options. As more companies and services begin to recognize the need for a universal emoji set, you can expect to see Emoji One popping up around the web in more places.</p>
<p>Better emoji support may someday find its way into WordPress core with enough popular support. In the meantime, you can use <a href="https://wordpress.org/plugins/wp-emoji-one/" target="_blank">WP Emoji One</a> to extend WordPress&#8217; capabilities to provide a more consistent and colorful emoji display on your site.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Oct 2014 17:06:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Matt: Dave Winer’s 20th";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44291";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2014/10/dave-winers-20th/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:352:"<p>The Observer writes <a href="http://www.theguardian.com/technology/2014/oct/12/happy-20th-anniversary-dave-winer-inventor-of-the-blog">Happy 20th anniversary to Dave Winer – inventor of the blog</a>. I&#8217;ve gotten a huge amount of inspiration, help, and feedback from Dave over the years, and I&#8217;m really happy he&#8217;s still at it.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Oct 2014 22:37:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"Post Status: Postmatic wants to revitalize your WordPress email, starting with comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=7197";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://www.poststat.us/postmatic-wordpress-email/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4912:"<p><img class="aligncenter size-large wp-image-7200" src="http://www.poststat.us/wp-content/uploads/2014/10/postmatic-752x307.gif" alt="postmatic" width="627" height="255" /></p>
<p><a href="http://gopostmatic.com/">Postmatic</a> is a new WordPress plugin that I think is quite promising. It&#8217;s aim is to eventually change the way you utilize WordPress email in many ways, but its comment functionality is what intrigued me immediately.</p>
<p>Postmatic currently allows users to subscribe to comments and posts by email; but what sets it apart is that it enables <em>reply by email</em> functionality as well. That&#8217;s something that has been high on my list of wants for a WordPress plugin for a long time, and I wanted it without switching to a third party system like Disqus.</p>
<p>All in all &#8212; aside from enabling replies by email &#8212; the current feature set is quite similar to Jetpack&#8217;s Subscriptions module. Postmatic has widgets for post subscriptions and will send subscribers new posts and allow them to get emailed comment notifications as well.</p>
<p></p>
<p>I asked Jason Lemieux, a co-founder of Postmatic, if they were considering a way to import from Jetpack or otherwise integrate with it, and they are. They&#8217;re working now to make it so that your old posts using Jetpack&#8217;s subscription module for comment notifications will still work, and your new posts will use Postmatic.</p>
<p>I had a pretty thorough conversation with Jason and got to see Postmatic in action. For a free plugin especially, the functionality is quite impressive. I tested subscribing to comments, replying by email, and opting into subscriptions, and it is all very smooth. Here&#8217;s a sample reply notification to my email.<span id="more-7197"></span></p>
<div id="attachment_7201" class="wp-caption aligncenter"><img class="wp-image-7201 size-large" src="http://www.poststat.us/wp-content/uploads/2014/10/postmatic-email-752x816.gif" alt="postmatic-email" width="627" height="680" /><p class="wp-caption-text">Sample Postmatic notification email</p></div>
<p>Postmatic is already in beta with their API as well. With a little legwork, you can utilize Postmatic for a variety of custom use cases. I know I&#8217;d love to play with it to see if I could create email campaigns for custom post types or multiple lists. They also intend to monetize the plugin via a few avenues &#8212; including ensuring mail delivery and functionality add-ons.</p>
<p>Postmatic &#8212; available for <a href="https://wordpress.org/plugins/postmatic/">download on WordPress.org</a> &#8212; is and will remain completely free. At some point they&#8217;ll exit beta and they will offer paid delivery of outgoing mail for larger sites. They understand the limitations of sending email through your own server and are using Mailgun to ensure delivery. They also have an extensive &#8212; and for now private &#8212; list of features they aim to introduce to Postmatic.</p>
<p>The product is definitely version 1.0. Advanced list management, and more advanced campaign delivery is still not ready. But I was impressed by how good of a 1.0 Postmatic is, and how much effort Jason and his business parter, Dylan Kuhn, have clearly invested heavily into the product. For instance, subscriber importing is already possible, so you could move to Postmatic for post delivery right away. They <a href="http://gopostmatic.com/setup/">have videos show how to do that and more</a> already available.</p>
<p>They tell me as well that Postmatic is in very early stages. Right now they are working on more advanced template building and other features to help tame your WordPress emails. I think they definitely have other services like <a href="http://jetpack.me">Jetpack&#8217;s</a> Subscriptions and <a title="WYSIJA is now MailPoet" href="http://www.poststat.us/wysija-now-mailpoet/">MailPoet</a> in their sights.</p>
<p>I think WordPress email is ripe for disruption. Imagine, currently, all the ways users can get emails from a website, with little continuity: WordPress itself, Mailchimp or other newsletter provider, Jetpack / WordPress.com, eCommerce solutions, form solutions. Each of these sends email and each has their own quirks, look and feel, and otherwise.</p>
<p>I&#8217;d love to see a service like <a href="http://gopostmatic.com/">Postmatic</a> help tame WordPress email as a whole, and offer a more seamless experience for my website visitors that receive email from me.</p>
<p>In the short term, I doubt any service will be able to do this perfectly. But I think as WordPress sites send more and more mail, continuity in this arena will be very important. I know, for me, as I prepare to enable <a title="The future of Post Status" href="http://www.poststat.us/radical/">club memberships on Post Status</a>, it&#8217;s top of my mind to provide a quality email experience to my members.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Oct 2014 21:51:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WPTavern: WPWeekly Episode 166 – Interview With The Project Lead For XWP, Frankie Jarrett";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=32015&preview_id=32015";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:96:"http://wptavern.com/wpweekly-episode-166-interview-with-the-project-lead-for-xwp-frankie-jarrett";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4393:"<p>Back in September, <a title="http://wptavern.com/stream-morphs-from-a-plugin-into-a-service" href="http://wptavern.com/stream-morphs-from-a-plugin-into-a-service">Stream 2.0 was released</a> with some significant changes. The most notable change is the transition from a plugin into a service.</p>
<p>In this episode of WordPress Weekly, <a title="http://marcuscouch.com/" href="http://marcuscouch.com/">Marcus Couch</a> and I are joined by the project lead For <a title="https://xwp.co/" href="https://xwp.co/">XWP</a>, <a title="http://frankiejarrett.com/" href="http://frankiejarrett.com/">Frankie Jarrett</a>. Jarrett goes in-depth on the decision to turn Stream into a service. He also explains why it needs to be connected to a WordPress.com ID, what the team is doing regarding the enterprise, and why record data is stored in the cloud. Near the end of the interview, we discuss the lessons learned from how the plugin was shipped and communicated to customers.</p>
<h2>Stories Discussed:</h2>
<p><a title="http://wptavern.com/webdesign-com-is-now-ithemes-training" href="http://wptavern.com/webdesign-com-is-now-ithemes-training">WebDesign.com Is Now iThemes Training</a><br />
<a title="http://wptavern.com/troubleshooting-handbook-for-new-wordpress-support-forum-volunteers-is-live" href="http://wptavern.com/troubleshooting-handbook-for-new-wordpress-support-forum-volunteers-is-live">Troubleshooting Handbook For New WordPress Support Forum Volunteers Is Live</a><br />
<a title="http://wptavern.com/how-to-obtain-the-total-download-count-for-plugins-attached-to-a-wordpress-org-username" href="http://wptavern.com/how-to-obtain-the-total-download-count-for-plugins-attached-to-a-wordpress-org-username">How to Obtain The Total Download Count For Plugins Attached to a WordPress.org Username</a><br />
<a title="http://wptavern.com/rate-and-review-a-wordpress-plugin-day-set-for-october-17th" href="http://wptavern.com/rate-and-review-a-wordpress-plugin-day-set-for-october-17th">Rate and Review a WordPress Plugin Day Set For October 17th</a><br />
<a title="http://wptavern.com/twenty-fifteen-officially-added-to-the-development-version-of-wordpress" href="http://wptavern.com/twenty-fifteen-officially-added-to-the-development-version-of-wordpress">Twenty Fifteen Officially Added to The Development Version of WordPress </a><br />
<a title="http://wptavern.com/loopconf-a-conference-catered-to-wordpress-developers" href="http://wptavern.com/loopconf-a-conference-catered-to-wordpress-developers">LoopConf: A Conference Catered to WordPress Developers </a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a title="https://wordpress.org/plugins/wc-vendors/" href="https://wordpress.org/plugins/wc-vendors/">WC Vendors</a> is a WooCommerce extension that lets you create your own Etsy or Amazon style marketplace, allowing multiple vendors to sell their goods. This allows other users to sell tangible products, virtual products or downloads on your site. Vendors receive the commissions you set on products they sell from your store.</p>
<p><a title="https://wordpress.org/plugins/wp-comment-fields/" href="https://wordpress.org/plugins/wp-comment-fields/">WordPress Comments Fields</a> is a plugin that allows admins to add custom fields to the comment area. These fields are saved as comment meta and are displayed under the comment. The plugin support four different field types: Drag and drop, text, radio, radio and select inputs.</p>
<p><a title="https://wordpress.org/plugins/comic-sans-roulette/" href="https://wordpress.org/plugins/comic-sans-roulette/">Comic Sans Roulette</a> randomly changes all fonts on your site to Comic Sans. You have a 10% chance that all of the fonts will be Comic Sans!</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, October 22nd 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #166:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Oct 2014 17:41:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: LoopConf: A Conference Catered to WordPress Developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=32006";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wptavern.com/loopconf-a-conference-catered-to-wordpress-developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2653:"<p>&nbsp;</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/LoopConfFeaturedImage.png" rel="prettyphoto[32006]"><img class="aligncenter size-full wp-image-32007" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/LoopConfFeaturedImage.png?resize=650%2C200" alt="LoopConf Featured Image" /></a>Scheduled to take place <strong>May 7-8th, 2015</strong> at Westin Lake in Las Vegas, NV, <a title="http://loopconf.io/" href="http://loopconf.io/">LoopConf</a> is a conference dedicated to WordPress developers. The two-day event has six speakers confirmed with more on the way. They include:</p>
<ul>
<li>Joost de Valk</li>
<li>Jenn Schiffer</li>
<li>John O&#8217; Nolan</li>
<li>Helen Hou-Sandí</li>
<li>Andrew Nacin</li>
<li>Syed Balkhi</li>
</ul>
<p>LoopConf is a single track conference where a bulk of the content will consist of 30 minute sessions and 60 minute developer work shops. It gives developers an opportunity to dive deep into advanced engineering and development topics in a relaxed atmosphere surrounded by like-minded individuals.</p>
<p>If you&#8217;re interested in speaking at the event, LoopConf is <a title="http://loopconf.io/apply/" href="http://loopconf.io/apply/">calling for speakers</a>. The deadline to submit a speaker application is November 4th, 2014. If you&#8217;re interested in financially supporting the event, there&#8217;s a <a title="http://loopconf.io/sponsor/" href="http://loopconf.io/sponsor/">sponsor application available</a>.</p>
<p>Like <a title="http://prestigeconf.com/" href="http://prestigeconf.com/">PrestigeConf</a>, LoopConf is not a WordCamp or associated with the WordPress foundation. Even though it&#8217;s an independent event, there is at least one trait similar to WordCamps. One of the rules to be a speaker is to embrace the open source spirit.</p>
<blockquote><p>We want all of our speakers to show up with an attitude to give freely. This isn’t an opportunity to pitch your company, it’s the chance to share knowledge that you’ve picked up as you’ve perfected your craft.</p></blockquote>
<p>Event organizer, Ryan Sullivan, says the plan is to &#8220;sell 600-700 tickets in two rounds&#8221;. He also told the Tavern, &#8220;we&#8217;ll have an exclusive deal with the hotel for attendees to take advantage of. For those who can&#8217;t make it or would like to attend virtually, the event will be <strong>streamed live for free</strong>.&#8221;</p>
<p>Tickets have yet to go on sale as the organizing team works to complete the details. However, those who sign up to the LoopConf email list will be the first to know when tickets go on sale.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Oct 2014 21:58:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: Twenty Fifteen Officially Added to The Development Version of WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31991";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://wptavern.com/twenty-fifteen-officially-added-to-the-development-version-of-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5572:"<p>The default theme slated to ship with WordPress 4.1 dubbed &#8220;<a title="http://wptavern.com/first-look-at-designs-for-the-twenty-fifteen-default-wordpress-theme" href="http://wptavern.com/first-look-at-designs-for-the-twenty-fifteen-default-wordpress-theme">Twenty Fifteen</a>&#8221; has <a title="https://make.wordpress.org/core/2014/10/14/twenty-fifteen-is-here/" href="https://make.wordpress.org/core/2014/10/14/twenty-fifteen-is-here/">officially been added</a> to the development version of WordPress. In sharp contrast to <a title="https://wordpress.org/themes/twentyfourteen" href="https://wordpress.org/themes/twentyfourteen">Twenty Fourteen</a>, Twenty Fifteen is a simple, two column, blog focused theme. The typography features Google’s Noto Serif and Sans, a font family designed to be visually harmonious across many of the worlds languages.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/twenty-fifteen.png" rel="prettyphoto[31991]"><img class="aligncenter size-full wp-image-30226" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/twenty-fifteen.png?resize=1024%2C825" alt="twenty-fifteen" /></a></p>
<p>Here&#8217;s what the Tavern looks like with Twenty Fifteen activated. In the screenshot, you&#8217;ll notice a scrollbar between the sidebar and content. Being able to scroll the sidebar separate from the content reminds me of the Visual Editor in WordPress 3.9. I&#8217;d like to see both columns be a cohesive unit for a better experience and to eliminate the <strong>ugly</strong> scrollbar. <em>This issue has already been <a title="https://core.trac.wordpress.org/ticket/29979" href="https://core.trac.wordpress.org/ticket/29979">reported</a>.</em></p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/TwentyFifteenTavernHomepage.png" rel="prettyphoto[31991]"><img class="size-full wp-image-31993" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/TwentyFifteenTavernHomepage.png?resize=1025%2C718" alt="Twenty Fifteen Tavern Home Page" /></a>Twenty Fifteen Tavern Home Page
<p>In Twenty Fifteen, the comment reply link is aligned to the left. While not a deal breaker, I prefer the comment link to be aligned to the right.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/TwentyFifteenCommentReplyLink.png" rel="prettyphoto[31991]"><img class="size-full wp-image-31994" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/TwentyFifteenCommentReplyLink.png?resize=660%2C258" alt="Comment Reply Link on The Left" /></a>Comment Reply Link on The Left
<p>On the Tavern, we routinely use the featured image as the first image in a post. This works well since the Tavern theme is configured to show only the excerpts and featured image on the homepage. The Twenty Fifteen homepage displays full posts which shows the same image twice, creating a <em>post title sandwich</em>. Keep this in mind if you use featured images and are thinking of switching to Twenty Fifteen in the future.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/TwentyFifteenSandwhich.png" rel="prettyphoto[31991]"><img class="size-full wp-image-31995" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/TwentyFifteenSandwhich.png?resize=750%2C887" alt="A Featured Image Sandwich" /></a>A Post Title Sandwich
<p>&nbsp;</p>
<p>Each post on the homepage is separated by blank space. Featured images that are not at least 826 pixels wide are padded by an equal amount of blank space on each side. Similar to Twenty Fourteen, images that span the entire width change the visual look and feel of the theme. Posts on the homepage look great when the image is more than 826 pixels wide, while smaller images don&#8217;t have the same visual pop.</p>
<p>Since featured images touch the top of the content box, smaller images give me the impression that something is broken. For example, maybe there&#8217;s an alignment issue where the top of the image is being cut off. It&#8217;s not, but that&#8217;s what I&#8217;m thinking when I see it. This is all a moot point though if you use a full width featured image.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/TooSmallOfaFeaturedImage.png" rel="prettyphoto[31991]"><img class="size-full wp-image-31997" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/TooSmallOfaFeaturedImage.png?resize=789%2C905" alt="Featured Image is Too Small" /></a>Featured Image is Too Small
<h2>It&#8217;s Still Early</h2>
<p>There is a long way to go before Twenty Fifteen is ready for prime time. Initial feedback I&#8217;ve seen so far labels Twenty Fifteen as a breath of fresh air. Twenty Fifteen goes back to the blogging roots of WordPress, but it does so in a modern, elegant way. Once the bugs have been squashed and the theme polished, I think a lot of people will either switch to or use Twenty Fifteen when WordPress 4.1 is released. If you&#8217;d like to see Twenty Fifteen in the wild, check out <a title="http://www.brandonkraft.com/" href="http://www.brandonkraft.com/">Brandon Kraft&#8217;s personal site</a>.</p>
<h2>How You Can Help Improve Twenty Fifteen</h2>
<p>The Twenty Fifteen development team is holding meetings on IRC, every Tuesday at 15:30 UTC, in the #wordpress-dev channel. The meetings are opportunities to discuss all things Twenty Fifteen and to <a title="https://core.trac.wordpress.org/query?status=!closed&component=Bundled+Theme" href="https://core.trac.wordpress.org/query?status=!closed&component=Bundled+Theme">collaborate on tickets</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Oct 2014 20:49:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"WordPress.tv Blog: The Future of WordPress: Great videos from Matt Mullenweg and Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.wordpress.tv/?p=400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:110:"http://blog.wordpress.tv/2014/10/15/the-future-of-wordpress-great-videos-from-matt-mullenweg-and-andrew-nacin/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1936:"<p>Here are some recent videos from <a href="http://wordpress.tv/event/wordcamp-europe-2014/" target="_blank">WordCamp Europe 2014</a> covering the past, present, and future of WordPress development.</p>
<h2>Matt Mullenweg: Q&amp;A with Om Malik</h2>
<div id="v-xBhclaAc-1" class="video-player">
</div>
<p>Matt Mullenweg, the founder of WordPress, in conversation with tech writer Om Malik on the WordPress past and present, as well as where we are going for the future.  </p>
<p><a href="http://wordpress.tv/2014/10/03/matt-mullenweg-om-malik-qa/" target="_blank">View on WordPress.tv</a></p>
<h2>Andrew Nacin: Post-Modern WordPress</h2>
<div id="v-4Lx4dIRH-1" class="video-player">
</div>
<p>Andrew Nacin, lead developer for the WordPress open source project, discusses the philosophy of WordPress development, and the course it should and will take to keep growing.</p>
<p><a href="http://wordpress.tv/2014/10/13/andrew-nacin-post-modern-wordpress/" target="_blank">View on WordPress.tv</a></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptvblog.wordpress.com/400/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptvblog.wordpress.com/400/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.wordpress.tv&blog=5310177&post=400&subd=wptvblog&ref=&feed=1" width="1" height="1" /><div><a href="http://blog.wordpress.tv/2014/10/15/the-future-of-wordpress-great-videos-from-matt-mullenweg-and-andrew-nacin/"><img alt="Matt Mullenweg & Om Malik: Q&A" src="http://videos.videopress.com/xBhclaAc/video-b445f277f2_scruberthumbnail_1.jpg" width="160" height="120" /></a></div><div><a href="http://blog.wordpress.tv/2014/10/15/the-future-of-wordpress-great-videos-from-matt-mullenweg-and-andrew-nacin/"><img alt="Andrew Nacin: Post-Modern WordPress" src="http://videos.videopress.com/4Lx4dIRH/video-ed23aaca26_scruberthumbnail_3.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Oct 2014 19:29:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Jerry Bates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Matt: Listen Completely";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44245";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:39:"http://ma.tt/2014/10/listen-completely/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:441:"<blockquote><p>Listen now . When people talk listen completely. Don’t be thinking what you’re going to say. Most people never listen. Nor do they observe. You should be able to go into a room and when you come out know everything that you saw there and not only that. If that room gave you any feeling you should know exactly what it was that gave you that feeling. Try that for practice.</p></blockquote>
<p>&#8212; Ernest Hemingway</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Oct 2014 15:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Matt: Among the Marchers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44254";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://ma.tt/2014/10/among-the-marchers/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:231:"<p>Bill McKibben writes from <a href="http://www.newyorker.com/news/news-desk/among-marchers">Among the Marchers of the climate change march</a> the other week. <cite>Hat tip: <a href="http://grist.org/">Chip Giller</a>.</cite></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Oct 2014 22:46:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"Post Status: LoopConf: A new WordPress conference that’s only for developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=7188";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://www.poststat.us/loopconf-new-wordpress-conference-thats-developers/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3300:"<p>&nbsp;</p>
<p><img class="aligncenter size-large wp-image-7191" src="http://www.poststat.us/wp-content/uploads/2014/10/loopconf1-752x295.png" alt="loopconf" width="627" height="245" /></p>
<p>Early May 2015 will be the first ever <a href="http://loopconf.io/">LoopConf</a>, a WordPress conference that&#8217;s geared solely toward developers. Ryan Sullivan, the owner of <a href="http://wpsitecare.com">WP Site Care</a>, is hosting the conference that is to be held in Las Vegas.</p>
<p>LoopConf describes itself like this:</p>
<blockquote><p>LoopConf is the greatest conference ever created for WordPress developers. LoopConf came about as we heard technically-minded folks talk about wanting to get together and dive deep into advanced engineering and development topics. We&#8217;ve assembled an amazing group of speakers to get this inaugural event started off on the right foot, and we&#8217;re excited to share our excitement and passion for WordPress with all of you in an exciting two-day event. We hope that you join us to celebrate the software we love, enjoy each other&#8217;s company, and learn from one another.</p></blockquote>
<p>There are already six speakers confirmed:</p>
<ul>
<li><a href="http://nacin.com">Andrew Nacin</a>: WordPress lead developer, works at Audrey Capital</li>
<li><a href="http://helenhousandi.com/">Helen Hou-Sandí</a>: Lead developer of WordPress 4.0, works at 10up</li>
<li><a href="http://ghost.org">John O&#8217;Nolan</a>: Founder of Ghost and former WordPress contributor</li>
<li><a href="http://www.balkhis.com/about/">Syed Balkhi</a>: Owner of Awesome Motive, the parent company for WP Beginner, List 25, OptinMonster, and others</li>
<li><a href="http://jennmoney.biz/">Jenn Schiffer</a>: Open web engineer at Bocoup</li>
<li><a href="http://yoast.com">Joost de Valk</a>: owner of Yoast and maker of the WordPress SEO plugin, amongst others</li>
</ul>
<p>The initial speaker line-up is pretty fantastic. I&#8217;d love to learn more from each one of them.</p>
<p>LoopConf is not a WordCamp or associated with the WordPress foundation. It&#8217;s an independent WordPress conference, and Ryan says it&#8217;s the first in-person developer only WordPress conference he knows of. Most WordCamps are very catered to a diverse audience.</p>
<p>This could be a good way for people to have more developer centric conversations. I&#8217;m certainly interested to see how it goes, and would like to make it myself. They are seeking sponsors and speaker submissions now. I don&#8217;t know how much the tickets will be exactly, but Ryan tells me he hopes for LoopConf to have a prestige and quality similar to An Event Apart events, but for WordPress &#8212; so I imagine the tickets won&#8217;t be cheap.</p>
<p>As the WordPress conference ecosystem continues to blossom, I&#8217;m sure this isn&#8217;t the only one we&#8217;ll see like this. Non-WordCamp, niche events like <a href="http://pressnomics.com">PressNomics</a> helped lead the way for those that are happening now, and I think generally it&#8217;s been good to have a diverse array of options for people to attend and learn from one another.</p>
<p>You can keep up with <a href="http://twitter.com/loopconf">@LoopConf</a> on Twitter or <a href="http://loopconf.io">via the website</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Oct 2014 18:22:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: Rate and Review a WordPress Plugin Day Set For October 17th";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31977";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wptavern.com/rate-and-review-a-wordpress-plugin-day-set-for-october-17th";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3065:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/RateReviewPluginDayFeaturedImage.png" rel="prettyphoto[31977]"><img class="aligncenter size-full wp-image-31979" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/RateReviewPluginDayFeaturedImage.png?resize=666%2C211" alt="Rate Review Plugin Day Featured Image" /></a></p>
<p>Mark your calendars and schedule some free time on <strong>Friday, October 17th</strong> for the first &#8220;<strong>Rate and Review a WordPress Plugin Day</strong>&#8220;. On October 17th, visit the page of your favorite plugin in the <a title="https://wordpress.org/plugins/" href="https://wordpress.org/plugins/">WordPress.org plugin directory</a>, give it a star rating, and write a review.</p>
<h2>Why The Special Day?</h2>
<p>If you&#8217;re anything like me, you get caught up in the day-to-day activities without getting around to rating and reviewing the plugins you depend on. Some of the plugins I rely on have served me well for years, but I&#8217;ve yet to rate or review them. The only time I stop by a plugin&#8217;s page after installing it is to visit the support forum. Since disgruntled users are more vocal than those with positive experiences, this day is an excuse to share those positive experiences with the community and the plugin author.</p>
<h2>Quick Tip</h2>
<p>Since you can&#8217;t rate and review plugins from the backend of WordPress, here is a quick tip. Login to your WordPress.org account and navigate to the installed plugins page in the backend of WordPress. Each plugin should have a view details link that will load the plugin details modal. On the details screen, open the link to the WordPress.org Plugin Page in a new browser tab. These steps save you the trouble of manually browsing to each plugin&#8217;s page on WordPress.org.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/WPPluginPageNewTab.png" rel="prettyphoto[31977]"><img class="size-full wp-image-31978" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/WPPluginPageNewTab.png?resize=761%2C576" alt="Open The WordPress.org Plugin Page In A New Browser Tab" /></a>Open The WordPress.org Plugin Page In A New Browser Tab
<h2>An Easy Way to Contribute Back to WordPress</h2>
<p>Start with your favorite plugin. Review it based on your experience and try to write more than one-five words. As an additional courtesy, browse to the bottom of the plugin&#8217;s description page and click on the <em>broken</em> or <em>works</em> box. This helps determine which versions of the plugin are compatible with WordPress. Your ratings, reviews, and compatibility checks are indirect contributions to WordPress. It&#8217;s actionable data that millions of people will use to determine whether or not to use a plugin.</p>
<p>One thing to keep in mind is that ratings and reviews are not set in stone. If you&#8217;d like to change the content or star ratings, find your review and scroll to the bottom of the page. From there, you&#8217;ll be able to change the text and rating.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Oct 2014 16:39:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Alex King: WordPress vs. a Roll-Your-Own Blog Engine";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:48:"http://pinboard-9c824ddfe7946cbde24dbe9eb552eb42";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://alexking.org/blog/2014/10/14/do-you-need-a-new-blog-engine";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6167:"<p>Inspired by Brent&#8217;s <a href="http://inessential.com/2014/10/02/need_new_blog_engine">consideration of an off-the-shelf blog engine</a>, Santiago Valdarrama has written a post outlining <a href="https://blog.svpino.com/2014/10/03/do-you-need-a-new-blog-engine">the problems he has with off-the-shelf blog engines</a>. What was so interesting to me about this was that a self-hosted WordPress site addresses nearly every one of his concerns.</p>
<blockquote><p>
  1) You don&#8217;t have to deal with updates to the platform. Updates and new features are nice, unless they break all the custom code you&#8217;ve developed over time.
</p></blockquote>
<p>WordPress has well abstracted APIs that make it easy for your custom code to live alongside the WP core code. I can&#8217;t remember the last time I needed to make a change to code I&#8217;d written for this site because of a WP core update.</p>
<blockquote><p>
  2) You can&#8217;t control when bugs are fixed or new features released. If there&#8217;s something missing, the only thing you can do is file a request and wait.
</p></blockquote>
<p>Fiddlesticks. You can <a href="https://make.wordpress.org/core/handbook/">submit a patch</a>, you can hack your local copy, and you can write plugins to add any features you feel are missing.</p>
<blockquote><p>
  3) There&#8217;s always a learning curve. Every platform is different, specially when you want to fine tune your layout and deviate from the provided templates.
</p></blockquote>
<p>This one strikes me as a bit silly. There is a learning curve when building your own system too &#8211; especially if you haven&#8217;t written your layout/templating system yet.</p>
<blockquote><p>
  4) Sometimes there&#8217;re things you can&#8217;t do. Period. (I wanted to use a specific format to display the date of my posts but Blogger doesn&#8217;t support it. I had to settle with something else.)
</p></blockquote>
<p>Using a hosted service and using an off-the-shelf blog engine are <em>not</em> the same thing. Self-hosting WordPress removes all of the hosted service restrictions.</p>
<blockquote><p>
  5) You have to deal with features you don&#8217;t need. Comments? Related posts? Search? Templating engine? Image carousel? I don&#8217;t need these, but I&#8217;d have to pay the price anyway.
</p></blockquote>
<p>Just as you can customize WordPress to add features, you can also customize it to hide features. Don&#8217;t use comments? An included setting and couple of lines of CSS will make it so you never know they were there. And WordPress doesn&#8217;t include bloated features out of the box; it wisely leaves that to plugins so that you add what you want instead of removing things you don&#8217;t.</p>
<blockquote><p>
  6) You can always export your content (sometimes you can&#8217;t), but even when the option is right there, the exported format is so messed up that you can&#8217;t use it again without a huge clean up. (One time I got my posts exported in a text file with no formatting.)
</p></blockquote>
<p>Again &#8211; this is only a problem with hosted solutions. With a self-hosted WordPress site you have full access to your MySQL database, as well as the built-in export features of WordPress.</p>
<blockquote><p>
  7) What&#8217;s true today might change tomorrow. What you like about the platform might go away some day. They won&#8217;t ask for your opinion.
</p></blockquote>
<p>WordPress is Open Source. Anyone can create a fork based on their own needs and preferences.</p>
<blockquote><p>
  8) It will never be as fast as you want it to be. If it&#8217;s hosted, your traffic will be shared. If you host it yourself, you might never be able to fine tune it to perfection.
</p></blockquote>
<p>WordPress powers around 20% of the internet &#8211; you don&#8217;t grow that big if you can&#8217;t handle scale. Dedicated WordPress hosts will solve these problems for you, and installing a few simple plugins (caching, CSS and JS concatenation and optimization, etc.) will do a ton to optimize a site on an server that isn&#8217;t tuned for WordPress.</p>
<blockquote><p>
  9) I will never be sure what my content is being used for. I know it&#8217;s public anyway, but it&#8217;s also in somebody else&#8217;s database I don&#8217;t control.
</p></blockquote>
<p>Another assumption of a hosted platform. NA for a self-hosted WordPress site.</p>
<blockquote><p>
  10) You&#8217;ll never get to experience the satisfaction of engaging in a conversation about how you developed your own platform from scratch.
</p></blockquote>
<p>As someone who has hacked on WordPress and related code for the last 12 years, I find this statement absurd. There are plenty of &#8220;from scratch&#8221; opportunities within the WordPress community, even now. And if what you want is engagement then joining a bountiful and vibrant community of developers is a much bigger opportunity than the potential for a conversation with another NIH hacker.</p>
<p>I&#8217;m not saying that there is anything wrong with building your own X. Every time you do that it&#8217;s a great learning experience. I&#8217;m saying I don&#8217;t think it is necessary to get pride of ownership.</p>
<blockquote><p>
  There might be something out there that offsets all my concerns, I&#8217;m not sure (but I don&#8217;t believe so.) My blog is my hobby, and I think I&#8217;d never give control again. Every single bit you see here was a labor of love, and I&#8217;m not ready to stop thinking about it that way.
</p></blockquote>
<p>I think a self-hosted WordPress site is really close. And I feel exactly the same about my site &#8211; it&#8217;s mine and I am in control of it. Even though I&#8217;ve released much of the code for this site as Open Source, no one else has a site that&#8217;s exactly like mine. I&#8217;ve made the decisions about how to present my content, how to distribute it to Twitter and Facebook, how to integrate with the responses on those platforms, and how I represent myself online. And I do so while building on a robust base platform that allows me to concentrate on building just the features that are unique to my site.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Oct 2014 15:10:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:97:"WPTavern: How to Obtain The Total Download Count For Plugins Attached to a WordPress.org Username";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31955";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:107:"http://wptavern.com/how-to-obtain-the-total-download-count-for-plugins-attached-to-a-wordpress-org-username";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3818:"<p>Over the weekend, the <a title="https://easydigitaldownloads.com/" href="https://easydigitaldownloads.com/">Easy Digital Downloads</a> team launched a new side project called <a title="http://wptally.com/" href="http://wptally.com/">WP Tally</a>. WP Tally is a tool that displays the total download count for plugins attached to a WordPress.org username. The project is the result of a conversation about the lack of an easy way to determine the total amount of plugin downloads a WordPress.org user has.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WPTallyHomePage.png" rel="prettyphoto[31955]"><img class="size-full wp-image-31956" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WPTallyHomePage.png?resize=736%2C568" alt="WP Tally Home Page" /></a>WP Tally Home Page
<p><a title="http://ghost1227.com/" href="http://ghost1227.com/">Daniel Griffiths</a>, who worked on the backend of the project, tells the Tavern, &#8220;it only took 10 minutes to come up with a name.&#8221; <a title="http://seandavis.co/" href="http://seandavis.co/">Sean Davis</a>, a full-time support manager and theme developer for EDD, is credited with the name. The founder of Easy Digital Downloads, <a title="https://pippinsplugins.com/" href="https://pippinsplugins.com/">Pippin Williamson</a>, asked Griffiths if he was interested in creating a new plugin, &#8220;I&#8217;m always looking for a new pet project, so I happily agreed.&#8221; The first version of WP Tally took about an hour and a half of development time. Due to other things going on throughout the day, the estimated time to complete the project is half a day.</p>
<h2>The WP Tally API</h2>
<p>While the site didn&#8217;t have an <a title="http://wptally.com/api-docs/" href="http://wptally.com/api-docs/">API initially</a>, one was added after being suggested by Williamson. Griffiths says the API is public and passes the same data that is displayed on WP Tally. While the extent of what the API can do is small, the team is open to suggestions. &#8220;We&#8217;ve already had someone express interest in writing a widget to allow users to display their personal data on their own website.&#8221;</p>
<h2>WP Tally in Action</h2>
<p>Since Scott Reilly known as <a title="https://profiles.wordpress.org/coffee2code/" href="https://profiles.wordpress.org/coffee2code/">Coffee2Code</a> on WordPress.org, has 70 plugins attached to his account, I used his name as an example. According to WP Tally, he has <a title="http://wptally.com/?wpusername=Coffee2Code" href="http://wptally.com/?wpusername=Coffee2Code">911, 256 total downloads</a>. Meanwhile, <a title="https://profiles.wordpress.org/joostdevalk/" href="https://profiles.wordpress.org/joostdevalk/">Joost de Valk</a> has a total of <a title="http://wptally.com/?wpusername=joostdevalk" href="http://wptally.com/?wpusername=joostdevalk">22.3 million downloads</a> from 29 different plugins. Results are displayed in a vertical list without a way to sort them.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/Coffer2CodeTotalPluginDownloads.png" rel="prettyphoto[31955]"><img class="size-full wp-image-31958" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/Coffer2CodeTotalPluginDownloads.png?resize=723%2C405" alt="Coffee2Code Total Download Count" /></a>Coffee2Code Total Download Count
<p>It would be nice to be able to sort through the list by the most downloads, most popular based on ratings, and alphabetical order. I&#8217;d also like to see the total number of plugins displayed in the same area as the total download count. As an added bonus, it would be neat if the information could be embedded into a text widget as a badge.</p>
<p>What do you think of the site and is there anything else you&#8217;d like to see it tally?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Oct 2014 01:21:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"Lorelle on WP: You’re Invited: Vancouver WordPress Social Meetup October 19";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://lorelle.wordpress.com/?p=11966";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://lorelle.wordpress.com/2014/10/13/youre-invited-vancouver-wordpress-social-meetup-october-19/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:504:"The last WordPress Social Meetup in Vancouver, Washington, was such a success, we&#8217;re going forward with these monthly meetings. Vancouver, Washington, is just a few minutes from downtown Portland, and our next meeting is this Sunday, October 19, from 4-7PM. Please arrive by 4:15PM to be allowed into the building. It is normally closed on [&#8230;]<img alt="" border="0" src="http://pixel.wp.com/b.gif?host=lorelle.wordpress.com&blog=72&post=11966&subd=lorelle&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Oct 2014 00:30:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WPTavern: Troubleshooting Handbook For New WordPress Support Forum Volunteers Is Live";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31953";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:95:"http://wptavern.com/troubleshooting-handbook-for-new-wordpress-support-forum-volunteers-is-live";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5370:"<p>Providing WordPress support is an important but often, thankless job. From <a title="https://wordpress.org/support/" href="https://wordpress.org/support/">support forums</a> to <a title="https://make.wordpress.org/support/handbook/other-support-locations/introduction-to-irc/" href="https://make.wordpress.org/support/handbook/other-support-locations/introduction-to-irc/">IRC</a>, there&#8217;s no shortage of people who need help with WordPress. However, participating in the various support channels is one of the easiest ways to contribute back to WordPress. In particular, if you&#8217;re interested in becoming a volunteer on the support forums, there&#8217;s a new guide available that walks you through the process.</p>
<p>It&#8217;s called the <a title="https://make.wordpress.org/support/trouble/" href="https://make.wordpress.org/support/trouble/">Troubleshooting Handbook</a>. It explains how the forum works and teaches volunteers how to troubleshoot common WordPress issues they&#8217;re likely to see in the forum. In the second section of the handbook, there are several items known as <a title="https://make.wordpress.org/support/trouble/section-2-breakfix-lessons/" href="https://make.wordpress.org/support/trouble/section-2-breakfix-lessons/">Break/Fix lessons</a>. Break/Fix is meant to be a hands-on guide to troubleshooting broken WordPress sites. Each lesson represents a common problem you may come across when helping others in the WordPress.org support forums.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/TroubleShootingHandbookHomePage.png" rel="prettyphoto[31953]"><img class="size-full wp-image-31964" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/TroubleShootingHandbookHomePage.png?resize=753%2C578" alt="Troubleshooting Handbook Home Page" /></a>Troubleshooting Handbook Home Page
<h2>How to Contribute</h2>
<p>For the past several months, volunteers have been working hard to get the handbook in tip-top shape. On <a title="https://make.wordpress.org/support/2014/10/support-team-update-for-october-2nd/" href="https://make.wordpress.org/support/2014/10/support-team-update-for-october-2nd/">October 2nd</a>, the project reached a point where it was ready for public viewing. Since it&#8217;s still a work in progress, I asked <a title="http://macmanx.com/" href="http://macmanx.com/">James Huff</a>, a member of the support team, how others can contribute. &#8220;At the moment, contributing to the handbook is limited. If you see anything that needs to be changed, please leave a comment at the bottom of the page with the problem.&#8221;</p>
<h2>The Potential Merge of Handbooks</h2>
<p>The <a title="https://make.wordpress.org/support/handbook/" href="https://make.wordpress.org/support/handbook/">Support Handbook</a> is a secondary project used primarily by forum moderators. Since moderators make up a small portion of the people who provide support, the initial plan is to merge the Troubleshooting handbook into the Support Handbook. Then, replace or combine the sections that overlap and relegate the moderator-only resources to a small Moderators Only section. Much of the work is planned to happen at the <a title="http://2014.sf.wordcamp.org/schedule/contributor-team-meetups/" href="http://2014.sf.wordcamp.org/schedule/contributor-team-meetups/">WordPress Contributor Team Meetup</a> during <a title="http://2014.sf.wordcamp.org/" href="http://2014.sf.wordcamp.org/">WordCamp San Francisco 2014. </a></p>
<p>&nbsp;</p>
<h2>Solid Foundation For New Support Volunteers</h2>
<p>The Troubleshooting Handbook is a welcome addition to both moderators and volunteers. While attending a WordCamp contributor day last year, I along with a few others sat in a group and plowed through several threads on the support forum. <a title="http://halfelf.org/" href="http://halfelf.org/">Mika Epstein</a>, who contributes a lot of her time to the WordPress support forums, guided us along the way. If it were not for her guidance, we may have ended up causing more problems than solving them.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/TroubleShootingHandbookFeaturedImage.png" rel="prettyphoto[31953]"><img class="size-full wp-image-31966" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/TroubleShootingHandbookFeaturedImage.png?resize=638%2C411" alt="TroubleShootingHandbookFeaturedImage" /></a>photo credit: <a href="https://www.flickr.com/photos/pinkpurse/5282398538/">pinkpurse</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a>
<p>Providing support on WordPress.org is an intimidating experience. It seems like new threads are created every second. I made a few mistakes by not having a set of canned responses or knowing how to handle certain question in the forums. By having this information in an easy to read format, new volunteers should have an easier time providing support without feeling like they&#8217;re doing something wrong.</p>
<p>If you want to contribute back to WordPress by providing support, I encourage you to read through the <a title="https://make.wordpress.org/support/trouble/" href="https://make.wordpress.org/support/trouble/">Troubleshooting Handbook</a>. Not only is it information you can use, it&#8217;s also a helpful guide for employees who provide customer support through forums.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Oct 2014 00:27:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: New Yorker on WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44251";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://ma.tt/2014/10/new-yorker-on-wp-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1029:"<blockquote><p>With the relaunch, <a href="http://newyorker.com/">NewYorker.com</a> runs on WordPress, a more robust, user-friendly CMS. &#8220;We&#8217;re looking at almost total upside there,&#8221; Thompson tells me. Because the tools are no longer getting in the way of producers doing their job, NewYorker.com is now able to publish a greater volume of stories every day. The site used to top out at 10 or 12 stories each day: now, it publishes around 20 per day. &#8220;It&#8217;s a lot easier to be productive now, and we can now make the site fresh a lot more quickly than we used to,&#8221; says Thompson.</p></blockquote>
<p><a href="http://www.fastcodesign.com/3035381/how-the-new-yorker-finally-figured-out-the-internet-3-lessons-from-its-web-redesign">How The New Yorker Finally Figured Out The Internet in Fast Company</a>. Still my favorite magazine in the world. Also the reason I started spending more time in New York. <cite>Hat tip: <a href="http://kellychoffman.wordpress.com/">Kelly Hoffman</a>.</cite></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 13 Oct 2014 20:27:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"Matt: Beats Studio Wireless vs Samsung Level Over";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44275";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://ma.tt/2014/10/beats-studio-wireless-vs-samsung-level-over/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7474:"<p>I listen to music pretty much constantly, and it&#8217;s not unusual to see me on the road with just a carry-on and still have 3 or 4 headphones on me that I&#8217;m testing.</p>
<p>First off, Bluetooth changes everything. It&#8217;s so nice to not ever worry about cables, or even proximity for the most part, like having your phone charging by the laptop and still able to walk around the room. Audio quality is great now, only downside is having to charge something, but they&#8217;re all pretty good about battery now.</p>
<p>I&#8217;ve been enjoying a category I&#8217;ll call: Bluetooth, over ear headphones that let people know not to bother you, that you feel kind of cool wearing, that are great for planes, and cost around $300-400. The pioneer in this category is Beats, and I bought a pair of their Studio Wireless (in <a href="http://www.beatsbydre.com/headphones/studio-wireless/titanium/900-00199-01.html" title="Like a bosse.">matte titanium</a>, natch) after <a href="http://techcrunch.com/2014/05/28/apple-buys-beats-electronics-for-3b/" title="Apple has made a series of interesting buys and hires this year.">Apple bought them</a> because I wanted to see what the fuss is about. More recently I got some horribly named but well-reviewed <a href="http://www.samsung.com/us/mobile/cell-phones-accessories/EO-AG900BWESTA" title="Oh, Samsung.">Samsung Level Overs</a>, so this is a comparison of those two. (Another contender in this category would be the <a href="http://www.parrot.com/zik/usa/" title="I wanted to love these.">Parrot Zik ones</a>, but just skip those. Great idea, annoying in practice.)</p>
<p><img class="alignleft wp-image-44276" src="http://i0.wp.com/ma.tt/files/2014/10/overear-studio-wireless-titanium-standard-thrqrtleft-O.png?resize=256%2C298" alt="Beats Studio Wireless" />Let me start with how the Beats are better: they fold up, look cool, sound pretty decent on calls, and everything works nicely with the iPhone. For me they have two fatal flaws: comfort and noise. The earcups are kind of small, or my ears are kind of huge; whichever it is, sometimes after wearing them for a few hours my left ear starts to become quite sore. Second is they have active noise cancellation (ANC) that causes what can only be described as a constant hiss you can hear both while music is playing and while it&#8217;s off, it&#8217;s like like noise addition rather than noise cancellation. The fit and finish of the Beats are nice, as well as the accessories like cables, how it indicates how much power is left, et cetera.</p>
<p><img class="alignright  wp-image-44277" src="http://i1.wp.com/ma.tt/files/2014/10/71joq-txpaL._SL1500_.jpg?resize=272%2C360" alt="Samsung LEVEL over" />The <a href="http://www.amazon.com/dp/B00KGGK738/" title="Reviews on Amazon are pretty good too.">LEVEL overs</a> (wow that&#8217;s awkward to write) are big, and they don&#8217;t fold, but they float around in my backpack pretty much the same as the Beats, especially if you don&#8217;t use the included case. The battery seems to go forever. The ANC can be turned on and off (battery goes longer with it off), and when it&#8217;s on it&#8217;s <em>good</em>, like miss-the-announcement-for-your-flight good. For me this is the deal-maker &#8212; I didn&#8217;t realize what I was missing with mediocre ANC before on the Beats, I&#8217;m now able to concentrate and relax much better on planes. I&#8217;ve flown every third day in the past month, so this is a big deal to me. They also feel like they&#8217;re better made &#8212; less plastic feeling than the Beats. The have a <a href="http://ecx.images-amazon.com/images/I/316Rt2g8EEL.jpg" title="Pretty intuitive.">touch gesture control</a> on the right cup like on the Zik, but it actually works well. The cups fit completely over my ears and in general it feels more comfortable on my head, I can wear it for hours at a time and it&#8217;s totally comfortable. I don&#8217;t think they look as cool, but that&#8217;s probably because I haven&#8217;t been conditioned with pictures of my favorite musicians and athletes wearing them. (<a href="http://recode.net/2014/10/04/nfl-bans-beats-headphones-on-camera/" title="Why is the NFL a non-profit, again?">Though not in football anymore</a>.)</p>
<p>Main downsides: the cable it comes with doesn&#8217;t &#8220;work&#8221; with an iPhone or Mac as a mic or control device, and is also clunky. (Bluetooth control works fine.) This is apparently because <a href="http://shaddack.twibright.com/projects/reveng_RemoteControlHeadphones/">the remote control resistor on Apple-targeted cables</a> work <a href="http://www.androidcentral.com/head-headphones-samsung-level-over-vs-beats-studio-wireless">differently from everyone else&#8217;s</a>, which I think we can all agree in 2014 is ridiculous for both sides. My fix for this was to use the cable from the Beats, which you <a href="http://www.amazon.com/dp/B00ILV7VGG/" title="This one might be not-real, but look around.">can also buy online</a>, which looks cooler, is smaller, and works great with my Mac for G+ Hangouts and Skype calls. Perhaps related to this is when the Beats or many other Bluetooth headsets I&#8217;ve used are connected to the iPhone there&#8217;s a battery indicator and the Samsung doesn&#8217;t support this, but since the battery life is so good I don&#8217;t worry about this too much.</p>
<p><strong><img class=" wp-image-44278 alignleft" src="http://i0.wp.com/ma.tt/files/2014/10/720311395_5520467755400174836.jpg?resize=190%2C190" alt="Matt with Samsungs" />Too long; skipped to the end:</strong> The Samsung sounds better, is more comfortable, and is better made. Try it out if you&#8217;re considering buying headphones in this category. I don&#8217;t expect this to be a long-term advantage because I&#8217;m fairly certain Apple will do amazing things with Beats in the future, even if that just means a lightning connector, but I&#8217;m guessing that&#8217;s a 2015 thing.</p>
<p><strong>Extra credit:</strong> What headphones do I use in other categories? (An update to <a href="http://ma.tt/2009/07/headphone-recommendations/" title="Oldie but goodie.">my 2009 post</a>.) For in-ear wired I use <a href="http://pro.ultimateears.com/en-us/home/18-Pro" title="Best sound, best comfort, but my ears get waxy when I wear them too much.">Ultimate Ears 18 Pro Custom</a> molded to my ears, but I also recommend <a href="http://www.amazon.com/dp/B003WV391Q/" title="This is the one with the remote mic, the newer 80s don\'t, for no good reason.">Sennheiser IE 8i</a> for friends who don&#8217;t want to go to audiologist, for running/exercise or when being discreet like on a subway I use the <a href="http://www.amazon.com/dp/B00DIOAM4Y/" title="Been putting a lot of miles on these.">Plantronics BackBeat GO 2 with charging case</a>, at home I like <a href="http://www.audeze.com/products/headphones/lcd-3" title="Indefensible.">the Auduze LCD3</a> usually with a <a href="http://redwineaudio.com/" title="Cavier on the kobe.">Red Wine Audio</a> amp. I agree with many of the assessments in <a href="http://www.marco.org/headphones-closed-portable" title="I love how obsessed Marco gets.">Marco Arment&#8217;s mega-review</a>, and I got turned on to the Samsung&#8217;s by <a href="http://thewirecutter.com/reviews/best-noise-cancelling-headphones/" title="For the record, I was an OG Wirecutter supporter.">Wirecutter&#8217;s noise cancelling review</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 12 Oct 2014 17:15:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Matt: Oculus";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44265";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://ma.tt/2014/10/oculus/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:767:"<p><a href="http://i2.wp.com/ma.tt/files/2014/10/oculus.jpg"><img class="alignright wp-image-44268" src="http://i2.wp.com/ma.tt/files/2014/10/oculus.jpg?resize=206%2C238" alt="" /></a> I got a chance to try the <a href="http://www.oculus.com/dk2/">Oculus Rift Development Kit 2 (DK2)</a> the other day, specifically <a href="http://www.roadtovr.com/sightline-the-chair-oculus-rift-dk2-vr-reference-demo/">Sightline: The Chair</a>. I&#8217;m not sure what to say except it was magical. I don&#8217;t think it replaces screens, but Oculus-style VR is definitely the future of entertainment. Thanks to (the <a href="http://www.ea.com/news/a-goodbye-to-john-vechey">newly retired</a>) <a href="http://johnvechey.wordpress.com/">John Vechey</a> for sharing it with me.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 11 Oct 2014 21:02:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"Jen Mylo: Site Setup Journal: Act II";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://jenmylo.com/?p=4587";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://jenmylo.com/2014/10/11/site-setup-journal-act-ii/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:17922:"<h2>Act II: Setting Up WordPress</h2>
<p><em>Previously in Site Setup Journal: <a href="http://jenmylo.com/2014/10/05/site-setup-journal-prologue/">Prologue</a> and <a href="http://jenmylo.com/2014/10/11/site-setup-journal-act-i/%20">Act I: Domains and Hosting</a>.</em></p>
<h3>One-Click Install Attempts</h3>
<p>1-click installs are totally the way to go, right? I mean, 1-click sounds faster and easier than <em>the famous 5-minute install</em> that you get if you do it manually over FTP (according to the Codex). I immediately go into the Dreamhost control panel and went for a 1-click.</p>
<p><img class="aligncenter size-full wp-image-4584" src="https://jenmylo.files.wordpress.com/2014/10/screen-shot-2014-10-05-at-6-36-55-am.png?w=520&h=132" alt="Screen shot 2014-10-05 at 6.36.55 AM" width="520" height="132" /></p>
<p>Okay, so 1-click, but 10 minutes. That doesn&#8217;t seem right, that it should take twice as long for the automated 1-click install as for a manual one. Well, too late now, right? Guess I&#8217;ll go feed the cats while I wait.</p>
<p>I have to kill a little more time than just feeding the cats, but eventually I get an email from Dreamhost telling me my WordPress install is ready for me, and linking me to install.php to set up an admin user and get going. I click the link and get a white screen. Hm. Try again. Hm. Open up FTP to see if the files are there, and they are. Start wondering if maybe 1-clicks can&#8217;t handle being in a subdirectory (where I&#8217;d put it), so think I&#8217;ll try another one in the root. Same thing, the 10-minute notice. Set up web email for the domain and send a test email so I can see if it&#8217;s just the website, or if it&#8217;s everything on the domain. Webmail is also whitescreened. Hm. Status on Dreamhost says my server is going to be getting some software updates and will be offline during this maintenance, but it doesn&#8217;t look like I&#8217;m in that time window. I get a 2nd automated email saying the 2nd 1-click has failed. I head into the support section.</p>
<p>The Live Chat support option shows as available, but when I click it it says that due to heavy activity there will be a 5-hour wait. Come on, just take down the Live Chat option when it&#8217;s 4am and you don&#8217;t have people on staff. I send an email, then another (first one re white screen, 2nd re install failure). In the meantime I start scrubbing through the Dreamhost support wiki.</p>
<p>I find the answer to the 2nd install failure before support gets back to me. Apparently, 1-clicks don&#8217;t work if there is anything in there already. So since I already have a subfolder in the root domain (from the 1st 1-click), trying to do a 1-click into the root won&#8217;t work. I have to empty it out first. That doesn&#8217;t make sense to me, but whatever. I wind up deleting everything via FTP and doing a manual install instead. Two, actually.</p>
<h3>Manual Install</h3>
<p>Well, then, back to the WordPress.org!</p>
<p><img class="aligncenter size-full wp-image-4589" src="https://jenmylo.files.wordpress.com/2014/10/screen-shot-2014-10-11-at-8-04-50-am.png?w=520&h=185" alt="Screen shot 2014-10-11 at 8.04.50 AM" width="520" height="185" /></p>
<p>The &#8220;handy guide&#8221; is the Codex&#8217;s installation instructions page. Let&#8217;s take a look.</p>
<h4>Before You Start</h4>
<p><img class="aligncenter size-full wp-image-4591" src="https://jenmylo.files.wordpress.com/2014/10/screen-shot-2014-10-11-at-8-22-15-am.png?w=520&h=212" alt="Screen shot 2014-10-11 at 8.22.15 AM" width="520" height="212" /></p>
<p><strong>1. Minimum server requirements</strong>. As it happens, I had checked the php version stuff when I re-upped the hosting account for this domain, and had upped the version of PHP. Someone setting things up without my account gymnastics wouldn&#8217;t have encountered that, though, so I set out to find my hosting versions as specified in the ask-for-it text on the requirements page on wordpress.org:</p>
<ul>
<li>PHP 5.2.4 or greater</li>
<li>MySQL 5.0 or greater</li>
<li>The mod_rewrite Apache module</li>
</ul>
<p>I log into the Dreamhost control panel. I look for a navigation label that says something like hosting environment, version information, about, etc. Don&#8217;t see anything. Click into <em>Manage Account</em>, nothing. Click into <em>Manage Domains</em>. Oh ho!</p>
<p><img class="aligncenter size-full wp-image-4592" src="https://jenmylo.files.wordpress.com/2014/10/screen-shot-2014-10-11-at-8-28-41-am.png?w=520" alt="Screen shot 2014-10-11 at 8.28.41 AM" /></p>
<p>Clearly I&#8217;d only upped the version on the one domain, not both on that account, but even so, I can see that the php versions are both above the minimum requirement to run WordPress.</p>
<p>Next up, MySQL version. Clicking the <em>MySQL Databases</em> navigation item seems the most likely, so I do. Nope. No information shown here about MySQL versions. You&#8217;d really think you would see that on the page labeled MySQL Databases, wouldn&#8217;t you? There is a link on that screen to <em>phpMyAdmin</em>, so maybe I can find it there. Wait &#8212; Authentication Required!</p>
<p><img class="aligncenter size-full wp-image-4593" src="https://jenmylo.files.wordpress.com/2014/10/screen-shot-2014-10-11-at-8-39-09-am.png?w=520" alt="Screen shot 2014-10-11 at 8.39.09 AM" /></p>
<p>Bah, which username and password combination does it want? The hosting account (server?) or a database user? A note here saying which password is needed would be helpful. I can&#8217;t get in with the ones I know off the top of my head so I close out of that and go back to the main Dreamhost control panel (the phpMyAdmin attempt had bumped me into a new tab). In the search box at the top, I type &#8220;MySQL version&#8221; and hit enter. The page refreshes, but I&#8217;m still on the MySQL Databases page where there is no version info displayed. I think maybe there&#8217;s some documentation with version info, so I look for support.</p>
<p>Now, having been around a long time, I know that Wiki, a small link in the upper right corner, means documentation. But a lot of people don&#8217;t (I doubt my mom &#8212; the most recent person to ask me to set up a site &#8212; would), so for the sake of the experiment I go looking for a Help or Docs or Support link. I find it (Support) in the bottom left navigation after scrolling down (below the fold), because for some reason the &#8220;Goodies&#8221; navigation section is open. Why? Because apparently that&#8217;s where the MySQL Databases page actually lives, despite being in the navigation up above as a top-level item. Come on, Dreamhost, who&#8217;s your information architect, and what are they doing?</p>
<p>Anyway, I click on Support. It drops a layer with 3 options. Contact, History, and Data Centers. Why not have a link here for Wiki (or better, Documentation, which is less jargony)? Hmph. If you do click on Contact Support, it takes you into a form. There&#8217;s a live chat button, but no links here to documentation either. Hm, what&#8217;s this &#8220;Help is Off&#8221; button?</p>
<p><img class="aligncenter size-full wp-image-4594" src="https://jenmylo.files.wordpress.com/2014/10/screen-shot-2014-10-11-at-8-48-09-am.png?w=520&h=167" alt="Screen shot 2014-10-11 at 8.48.09 AM" width="520" height="167" /></p>
<p>I decide to click it. Then I see this:</p>
<p><img class="aligncenter size-full wp-image-4595" src="https://jenmylo.files.wordpress.com/2014/10/screen-shot-2014-10-11-at-8-48-47-am.png?w=520&h=169" alt="Screen shot 2014-10-11 at 8.48.47 AM" width="520" height="169" /></p>
<p>Oh, how handy, a link to documentation and forums. Why it&#8217;s even optional to hide that text is ridiculous. Anyway, to the wiki!</p>
<p>On the Wiki Home there is a nice little menu, and MySQL is listed there, so I click it. I come to another list of topics. None of them say Version, so I start clicking them in the order that makes the most sense. <em>MySQL and</em> PHP does not have version info. Neither does <em>phpMyAdmin</em>, but it does tell me that the authentication password request was for the database user password. <em>Upgrading from MySQL 4.1 to 5.0 </em>tells me that, &#8220;DreamHost is currently slowly upgrading your MySQL servers from version 4.1 to 5.0. You can also email support and request they upgrade your databases. There are some incompatibilities between versions 4.1 and 5.0, particularly with JOINs. This upgrade could cause some breakage of your application(s).&#8221; It does not say how to tell which version you are currently on. At this point, some people might email support, but I think a lot would just shrug and decide to take a chance and hope they were already on 5.0. So I do that. Because let&#8217;s face it, any host that is listed on wordpress.org/hosting had better be running the minimum requirements, right?</p>
<p>Mod_rewrite! Since I&#8217;m already in the wiki, I do a search for &#8220;mod_rewrite Apache module,&#8221; the last item in the &#8216;email your host&#8221; list. The 4 search results are not helpful in any way. I remove &#8220;Apache module&#8221; from the search term and try again. Lots of results, none of them helpful. I decide again to shrug and assume, because this documentation is for the birds when it comes to confirming minimum requirements, and who has time to wait for support emails? Not me!</p>
<p>Around now I get an email from support about my earlier white screen issue. They say that it&#8217;s because the DNS hasn&#8217;t finished replicating. I might add that there&#8217;s a &#8220;works for me&#8221; comment in there that makes me purse my lips. But I stop to think about DNS. Yes, in the past I&#8217;ve had to set up a temp site on a dreamhosters subdomain if I wanted to work on a site before DNS caught up. Pain in the ass, yeah? Having to then do a move once the real domain is showing up? I hadn&#8217;t thought about that this time because the GoDaddy registration of the domain had been pointing at Dreamhost servers all along. I guess the hosting being down and then up created a DNS interruption. It was not explained to me satisfactorily, but I move on. Specifically, to step 2 of preparing for the install.</p>
<p><strong>Step 2. Download the latest release of WP. </strong>Easy. Go to wordpress.org, click the big Download button. Oh, okay. That wasn&#8217;t really a download button, that was a navigation link to a download page. Okay. I skim the content in the middle and go to click on the&#8230; oh, that button at the bottom of the content area is to find a mobile app, and goes to a site at get.wp.com. That&#8217;s not right. Oh, there&#8217;s the real download button up in the sidebar. It seems like those should have been switched, but whatever. Click! Download! 6.3MB, it takes 7 seconds.</p>
<p><strong>Step 3. Unzip the file.</strong> Also easy. Do <em>Show in Finder</em> from the download bar on the bottom of my browser, double click the file, see the <em>wordpress</em> folder appear. 3 seconds.</p>
<p><strong>Step 4. Secure password for secret key. </strong>Click on the link to read about it. Get distracted by the big-ass blue-i information icon alert at the top that says, &#8220;Interested in functions, hooks, classes, or methods? Check out the new <a class="external text" title="http://developer.wordpress.org/reference" href="http://developer.wordpress.org/reference">WordPress Code Reference</a>!&#8221; Why is that following me around on every page of the Codex? For someone installing WordPress for the first time, that is not helpful. At all. Further, there&#8217;s no <em>x</em> to dismiss the box, so if I&#8217;m not interested, I still have to scroll past it every time, and it pushes the content farther down on the page, not to mention making me feel like I&#8217;m probably not in the right place because they obviously think I am way technical. (Tangent: People keep saying that the fold is dead, but I think they are wrong.) Anyway, I&#8217;m already confused. I clicked on a link that said  <em>Secure password for secret key, </em>but I don&#8217;t see that language on this page. It doesn&#8217;t anchor link me to the specific section I needed, so I guess I have to read this whole page? With multiple mentions of passwords but no headlines that say secret key? I command+f to do a search for text on the page, which shows that &#8220;secret key&#8221; is mentioned in the section titled <em>Security Keys</em>. Hmph. Would a little consistency here be so much to ask?</p>
<p>Read the section. Questions that should be answered in this section <strong>before</strong> jumping into the history of adding stuff.</p>
<ul>
<li>What is a key?</li>
<li>What is a salt?</li>
</ul>
<p>Then it shows what secret keys look like from the online generator. Cool, I like online generators. But the wording all over is inconsistent and confusing &#8212; is it one secret key, or four, or eight? And where do I set a secure password for the key (or keys)? I don&#8217;t understand this! So! Many! Words! Used! Indiscriminately!</p>
<p>I cheat and use the fact that I know what all that confusing language means, and what it wants, which is simply the block of generated keys and salts, not a password for them.</p>
<p><strong>Step 5. Print this page. </strong>So I have it handy during installation? I&#8217;m thinking this list was written in the days before browser tabs, because why would I print it when I can just keep a tab open? Silly directions. But! On to the actual install!</p>
<h4>Famous 5-Minute Install</h4>
<p>That sure was a lot to do before doing the install, but I&#8217;m ready now!</p>
<p><img class="aligncenter size-full wp-image-4590" src="https://jenmylo.files.wordpress.com/2014/10/screen-shot-2014-10-11-at-8-06-30-am.png?w=520&h=381" alt="Screen shot 2014-10-11 at 8.06.30 AM" width="520" height="381" /></p>
<p><strong>Download and unzip &#8212; check.</strong> This step, which was 2 of the steps in the <em>Before You Install</em> list, took under a minute total, about 20% of a 5-minute install.</p>
<p><strong>Create a database and a MySQL user &#8212; check.</strong> This takes a couple of minutes. I have to log in to the hosting panel, locate <em>MySQL Databases</em> in the menu, and scan the resulting page to orient myself. The first thing on the page is creating a new hostname, and the WP instructions didn&#8217;t say anything about creating a new hostname. Below that is create a database, which has fields to create the first user at the same time. There&#8217;s no instruction on the difference between a database user, an ftp user, and an account user. I go ahead and made new host, db, and user (and while I&#8217;m in there I delete the databases left from the aborted 1-clicks), but I think it would intimidate someone who hadn&#8217;t done it before and didn&#8217;t really know what a database was in relation to a hosting account or a website. This takes me a minute or two, but would probably take someone who&#8217;d never done something like this a little longer, maybe up to 5 while they tried to grok the setup page on the host panel.</p>
<p><strong>Edit wp-config.php &#8212; check. </strong>This step is labeled optional, but I&#8217;m not sure why. If you click the <em>Editing wp-config.php</em> link, it says WP will create the config file for you from info you enter, and that turning wp-config-sample.php into a real wp-config.php file is for advanced users. If it works fine to have it be auto-generated, then why have this step in there at all? If it&#8217;s really better to do it manually, then why have the auto-create version? In any case, I&#8217;m used to editing the config file at this step, so I do it. Takes a couple of minutes because I had to go back and forth between tabs and copy/paste stuff. I happen to have Coda installed so the file opened in that program, but normally I&#8217;d have used textedit.</p>
<p>At this point I&#8217;ve passed 5 minutes.</p>
<p><strong>Upload files via FTP &#8212; check. </strong>I open Transmit and start the transfer. It takes <strong>twelve</strong> minutes. Why? My first guess is that it is shipping with 3 default themes now, all with retina-ready images. But I don&#8217;t know, I could be wrong. I know I don&#8217;t need all those themes, so I delete Twenty Fourteen and Twenty Thirteen while I&#8217;m in FTP, and plan to start out with Twenty Twelve.</p>
<blockquote><p>Tangent: Why do I want to start with Twenty Twelve? I think Twenty Thirteen is really aimed at bloggers and it has an overwhelming brand/design to it. The site I&#8217;m making is for a class, and needs to be chill. Twenty Fourteen I just personally don&#8217;t like, for the same reasons I don&#8217;t like the general mp6 coloring/style, which I&#8217;ve posted about elsewhere before.</p></blockquote>
<p><strong>Run the script at the URL where you installed &#8212; screeech! </strong>Screech to a halt here, because I wind up on another white screen. Side note: the wordpress.org instructions say to go right to the root URL, not to install.php directly (like the 1-click email tells you). Are they two different locations? Does install.php automatically load at root? Bah.</p>
<p>I go ahead and do a second manual install, so now I have one in root and one in a subdirectory. White screens on both. So it seems that the DNS stuff is really going to hold things up. I decide to go to school and finish it off when I get home that night.</p>
<h4>INTERMISSION</h4>
<p>Stay tuned for the exciting conclusion in Act III, which will cover finishing the WP install, installing BuddyPress and other plugins, and setting up BuddyPress.</p>
<p>&nbsp;</p><img alt="" border="0" src="http://pixel.wp.com/b.gif?host=jenmylo.com&blog=45389656&post=4587&subd=jenmylo&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 11 Oct 2014 20:04:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"Jen Mylo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: HostingReviews.io – Webhosting Reviews Without The Affiliate Links";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31873";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wptavern.com/hostingreviews-io-webhosting-reviews-without-the-affliate-links";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3738:"<p>How many times have you found reviews of webhosting companies only to discover they&#8217;re filled with affiliate links? The presence of an affiliate link leaves the validity of content in question. <a title="http://hostingreviews.io/" href="http://hostingreviews.io/">HostingReviews.io</a> by Steven Gliebe, hopes to solve this problem by documenting micro reviews without any affiliate links attached.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/FarAboveAverage.png" rel="prettyphoto[31873]"><img class="size-full wp-image-31926" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/FarAboveAverage.png?resize=778%2C397" alt="The Far Above Average Hosts Per Customer Reviews" /></a>The Far Above Average Hosts Per Customer Reviews
<p>HostingReviews.io works by documenting what people say about their webhosting provider on social media sites such as Twitter. These micro reviews are stored in a queue that Gliebe and his helpers process. Tweets that clearly express happiness or dissatisfaction are marked as such.</p>
<h2>The Technical Details</h2>
<p>Gliebe collects tweets matching certain keywords into a database using Twitter&#8217;s stream API. There are keywords setup to cover each host as best as possible. For example, Site Ground, SiteGround, and @siteground. This process means there is nothing special people have to do other than mention their host.</p>
<p>It is not really a submissions site where someone can say &#8220;I want what I say to be there&#8221; which can be abused. Gliebe describes the process being similar to a researcher taking a sample large enough to draw conclusions from. &#8220;I want to cover a lot of hosts eventually and that would be expensive to human-process so again that means not everything will be included, but whatever is excluded, will always be done so across the board at random as not to unfairly affect scoring.&#8221;</p>
<p>&#8220;Some people have asked me to add specific tweets. I decided not to do that because it will skew results (ie. someone submits only good or only bad ones for specific hosts). I&#8217;m sticking with the data Twitter themselves automatically roll in 24/7.&#8221;</p>
<p>If the user&#8217;s statement is in regard to a specific aspect of hosting (support, uptime, etc.), that is noted too. The micro-reviews and the data derived from them are presented on the site. Since users are more likely to Tweet dissatisfaction with their webhost, the overall scores are low. Gliebe notes that comparison is key.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/FlyWheelHostingReviews.png" rel="prettyphoto[31873]"><img class="size-full wp-image-31927" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/FlyWheelHostingReviews.png?resize=1025%2C635" alt="FlyWheel Reviews With Pretty Charts" /></a>FlyWheel Reviews With Pretty Charts
<p>The site is relatively new so there isn&#8217;t a lot of data to work with but what I&#8217;ve seen so far matches what I&#8217;ve noticed in my Twitter feed. Flywheel leading the pack doesn&#8217;t surprise me as I&#8217;m consistently reading tweets raving about their service and support.</p>
<p>In the past few months, there&#8217;s been more positive tweets about Pagely than I can remember. So being the number two webhosting company on HostingReviews matches what I&#8217;ve seen.</p>
<p>The site is a great resource as long as it keeps its promise of not using affiliate links. While 140 character tweets leave out a lot of context, I still think they have value. If you&#8217;re looking for webhosting reviews without an agenda, consider browsing <a title="http://hostingreviews.io/" href="http://hostingreviews.io/">HostingReviews.io</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Oct 2014 20:59:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"WPTavern: WebDesign.com Is Now iThemes Training";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31920";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://wptavern.com/webdesign-com-is-now-ithemes-training";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1569:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/iThemesTrainingImage.png" rel="prettyphoto[31920]"><img class="aligncenter size-full wp-image-31921" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/iThemesTrainingImage.png?resize=598%2C148" alt="iThemes Training Image" /></a>iThemes <a title="https://ithemes.com/webdesign-has-moved/" href="https://ithemes.com/webdesign-has-moved/">has announced</a> that WebDesign.com is now called <a title="http://training.ithemes.com" href="http://training.ithemes.com">iThemes Training.</a> According to the announcement, this change will lessen confusion and place everything under the iThemes umbrella.</p>
<blockquote><p>We&#8217;re making this transition in order to bring everything we do at iThemes under one roof (themes, plugins &amp; training) and eliminate confusion caused by having multiple domain names and two separate brands.</p></blockquote>
<p>If you&#8217;re a member of WebDesign.com, not much changes. You&#8217;ll be able to use the same credentials to login to iThemes Training and access the same content as before.</p>
<p>If you have any questions concerning the move, iThemes is <a title="https://www2.gotomeeting.com/register/392183786" href="https://www2.gotomeeting.com/register/392183786">hosting a webinar</a> on Monday, October 13th at 1PM CDT. You can also stop by the iThemes Training <a title="https://ithemes.com/forum/topic/64915-ithemes-training-webdesigncom/" href="https://ithemes.com/forum/topic/64915-ithemes-training-webdesigncom/">member forum</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Oct 2014 19:37:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"WPTavern: First PodsCamp Is a Success";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31900";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wptavern.com/first-podscamp-is-a-success";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3614:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/PodsDevTeamFeaturedImage.png" rel="prettyphoto[31900]"><img class="size-full wp-image-31901" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/PodsDevTeamFeaturedImage.png?resize=663%2C300" alt="PodsCamp Dev Team Featured Image" /></a>Image Courtesy of <a title="http://podscamp.org/" href="http://podscamp.org/">PodsCamp</a>
<p>October 3rd, 2014 will live in the history books as the day when the <a title="http://podscamp.org/" href="http://podscamp.org/">first conference</a> devoted to <a title="http://pods.io/" href="http://pods.io/">Pods</a> took place. Organized by Scott Kingsley Clark, <a title="http://podscamp.org/" href="http://podscamp.org/">PodsCamp</a> not only focused on the Pods plugin, but it was also the first time the development team was in the same physical location. In the following interview, Clark tells me how he thinks it went and whether it will become an annual event.</p>
<p><strong>Overall, what is your impression for how the first ever PodsCamp went?</strong></p>
<p>It was awesome! It could have only been made better by perhaps more tickets being available for WCDFW which was a barrier for folks coming from out-of-town. When tickets ran out for WCDFW, people couldn&#8217;t justify just coming out for PodsCamp, but could justify it if they were able to go to WCDFW that weekend too. Almost all (if not every single one) of our attendees went to WCDFW the next day.</p>
<p><strong>What was accomplished by having the entire Pods development team under the same roof?</strong></p>
<p>This was the first time we were together and it gave us an opportunity to have face to face conversations. We talked about all sorts of things like where we&#8217;ve been, where we&#8217;re going, and ideas on what we want to improve upon. One killer idea that came out of the weekend was from Joshua Pollock. We&#8217;re nailing down the specifics right now and should have an announcement post published as soon as we get things in place.</p>
<p><strong>Do you have any initial feedback concerning the event?</strong></p>
<p>We didn&#8217;t make enough from sponsors, Tilt, or ticket sales to cover the cost of the event. Our highest expense was bringing in four people from out-of-town and covering their accommodations. I hope in the future we can secure enough to at least break even.</p>
<p><strong>Is PodsCamp something you&#8217;ll try to turn into an annual event?</strong></p>
<p>Yes, we&#8217;re going to do this again next year just before WCDFW and will go over new topics now that we have established a baseline. We&#8217;re also considering 1-3 smaller meetup-based events near where our team members are located. One of which may be a mini-PodsCamp type of event in Austin, TX. I think that PodsCamp DFW will be our flagship one, which we would bring the whole crew out for, but the smaller ones could be more workshop and less camp.</p>
<p>I just want to again thank everyone who made this possible, especially Chris Lema, Jake Goldman, Tom McFarlin, WPEngine, and SiteGround. I’m so stoked we could pull this off!</p>
<h2>Let Us Know if You Attended PodsCamp</h2>
<p>If you attended PodsCamp, let us know about your experience in the comments! Slides from each presentation can <a title="http://www.slideshare.net/podsframework/" href="http://www.slideshare.net/podsframework/">be found here</a>. Sessions recorded at the event will be added to the Pods Framework <a title="https://www.youtube.com/user/podsframework" href="https://www.youtube.com/user/podsframework">YouTube channel</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Oct 2014 18:32:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: Chicago FAA Fire";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44243";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2014/10/chicago-faa-fire/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:430:"<p><a href="http://www.bloomberg.com/news/2014-10-02/contact-lost-with-planes-one-by-one-as-faa-center-fire-spread.html">This story about how a man sabotaged a FAA facility is terrifying and inspiring in how people worked together to overcome it</a>, and also includes this unintentionally funny line, &#8220;He had worked at the Chicago Center for eight years, according to an FBI affidavit. The company has fired him.&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Oct 2014 15:33:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WPTavern: WPWeekly Episode 165 – Contributions Galore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=31903&preview_id=31903";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://wptavern.com/wpweekly-episode-165-contributions-galore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3083:"<p>Since there is no guest this week, <a href="http://marcuscouch.com/" title="http://marcuscouch.com/">Marcus Couch</a> and I used this opportunity to spend more time than usual with the news. We spend a considerable amount of time discussing WordPress contributions and I provide insight into my distinction between<strong> direct</strong> and <strong>indirect</strong> contributions. I share my experience of attending the first WordCamp event for Ann Arbor, MI. Last but not least, we end the show with a shout-out to <a href="http://hostingreviews.io/" title="http://hostingreviews.io/">HostingReviews.io</a>, a resource filled with webhosting reviews from current or past customers without affiliate links.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/my-experience-at-wordcamp-ann-arbor-2014" title="http://wptavern.com/my-experience-at-wordcamp-ann-arbor-2014">My Experience at WordCamp Ann Arbor 2014</a><br />
<a href="http://wptavern.com/contributing-back-to-wordpress" title="http://wptavern.com/contributing-back-to-wordpress">Contributing Back to WordPress</a><br />
<a href="http://wptavern.com/webdevstudios-acquires-wordpress-support-services-company-maintainn" title="http://wptavern.com/webdevstudios-acquires-wordpress-support-services-company-maintainn">WebDevStudios Acquires WordPress Support Services Company, Maintainn</a><br />
<a href="http://www.poststat.us/pagely-growth-wordpress-hosting/" title="http://www.poststat.us/pagely-growth-wordpress-hosting/">5 years into business, Pagely is growing faster than ever</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href="https://wordpress.org/plugins/duplicate-title-validate/" title="https://wordpress.org/plugins/duplicate-title-validate/">Duplicate Title Validation</a> looks for posts and pages with the same name and prevents you from using the same title twice.</p>
<p><a href="https://wordpress.org/plugins/flexible-widget-title/" title="https://wordpress.org/plugins/flexible-widget-title/">Flexible Widget Title</a> enables you to hide widget titles in the frontend of WordPress, while the widget title is still visible in the backend.</p>
<p><a href="https://wordpress.org/plugins/wp-double-protection/" title="https://wordpress.org/plugins/wp-double-protection/">WP Double Protection</a> adds the ability to have a second password option. Instead of needing one password to login, you&#8217;ll need two.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, October 15th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #165:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Oct 2014 04:53:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: New WordPress Plugin Prevents Duplicate Titles From Being Published";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31892";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wptavern.com/new-wordpress-plugin-prevents-duplicate-titles-from-being-published";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1686:"<p>By default, if a post or page uses a title that&#8217;s already been used, WordPress appends a -2 to the end of the slug to prevent conflicts. Not only do duplicate titles cause conflicts, they&#8217;re not good for SEO. Developed by <a href="https://profiles.wordpress.org/wallfa_hm/">wallfa_hm,</a> the <a title="https://wordpress.org/plugins/duplicate-title-validate/" href="https://wordpress.org/plugins/duplicate-title-validate/">Duplicate Title Validation</a> plugin checks the title and displays a notice if it&#8217;s considered a duplicate.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/DuplicateTitleDetected.png" rel="prettyphoto[31892]"><img class="size-full wp-image-31893" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/DuplicateTitleDetected.png?resize=941%2C358" alt="Duplicate Title Detected" /></a>Duplicate Title Detected
<p>I tried to publish a post with a duplicate title but the plugin prevented it from being published and saved it as a draft instead. This is a nice touch and forces the writer to use a unique title.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/DuplicatePostSavedAsDraft.png" rel="prettyphoto[31892]"><img class="size-full wp-image-31895" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/DuplicatePostSavedAsDraft.png?resize=924%2C407" alt="Duplicate Post Saved as a Draft" /></a>Duplicate Post Saved as a Draft
<p>It&#8217;s not difficult to determine what the plugin is doing but the notices could be improved so they&#8217;re easier to understand. If you publish a lot of content, this plugin is an easy way to make sure each post or page has a unique title.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Oct 2014 03:23:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WPTavern: A Simple Way to Hide Widget Titles From The Frontend of WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31876";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://wptavern.com/a-simple-way-to-hide-widget-titles-from-the-frontend-of-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1019:"<p>Developed by <a title="https://profiles.wordpress.org/hyyan/" href="https://profiles.wordpress.org/hyyan/">Hyyan</a>, <a title="https://wordpress.org/plugins/flexible-widget-title/" href="https://wordpress.org/plugins/flexible-widget-title/">Flexible Widget Title</a> is a new plugin that enables users to hide widget titles from the frontend of WordPress. When activated, apply brackets to the titles you want to hide. For example,<strong> [A Text Widget Title].</strong></p>
<a href="http://wptavern.com/a-simple-way-to-hide-widget-titles-from-the-frontend-of-wordpress#gallery-31876-1-slideshow">Click to view slideshow.</a>
<p>Although the same effect can be accomplished by leaving the title field blank, it makes administering several text widgets in the backend of WordPress more difficult. This plugin allows you to keep the titles in the backend for easier administration but still be able to hide them on the frontend.</p>
<p>I tested the plugin on WordPress 4.0 and didn&#8217;t experience any issues.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Oct 2014 01:27:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Matt: Most Fascinating Newsletter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44241";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://ma.tt/2014/10/most-fascinating-newsletter/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:388:"<p><a href="http://techcrunch.com/2014/10/03/the-internets-most-fascinating-newsletter-writer-dave-pell/">The Internet&#8217;s Most Fascinating Newsletter Writer, Dave Pell</a>. Still one of my favorite reads, though I don&#8217;t look at it every day because it&#8217;d make me lazy about blogging and you all would get tired of seeing &#8220;Hat tip: Dave Pell&#8221; on every post.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 09 Oct 2014 13:47:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Matt: Players’ Tribune";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44257";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:37:"http://ma.tt/2014/10/players-tribune/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:794:"<blockquote><p>Introducing The Players’ Tribune, a new media platform that will present the unfiltered voices of professional athletes, bringing fans closer to the games they love than ever before. Founded by Derek Jeter, The Players’ Tribune aims to provide unique insight into the daily sports conversation and to publish first-person stories directly from athletes. From video to podcasts to player polls and written pieces, The Tribune will strive to be “The Voice of the Game.”</p></blockquote>
<p><a href="http://www.theplayerstribune.com/">The Players&#8217; Tribune, powered by WordPress</a>. <a href="http://www.theplayerstribune.com/introducing-derek-jeter/">Here&#8217;s Jeter&#8217;s intro</a>. <cite>Hat tip: <a href="http://daringfireball.net/">John Gruber</a>.</cite></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 09 Oct 2014 06:09:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"Matt: Become a Longreads Member";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44247";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://ma.tt/2014/10/become-a-longreads-member/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:766:"<blockquote><p>Our goal is to create a sustainable membership with a large enough base that it will fund reporting and writing at rates that are competitive with the best print magazines in the world.</p></blockquote>
<p>You might not have heard of a <a href="http://longreads.com/member">Longreads Membership</a> yet &#8212; you join for a monthly fee and 100% of that goes to independent publishers and writers. <a href="http://blog.longreads.com/2014/10/06/the-longreads-membership-is-now-twice-as-powerful/">We&#8217;re announcing an update to the program to match every dollar in, so it doubles your contribution</a>. I just joined Longreads at $10/mo, about what I pay for Netflix, and I can&#8217;t wait to see what comes out from the editorial team next.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 08 Oct 2014 20:22:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"Post Status: 5 years into business, Pagely is growing faster than ever";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=7174";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://www.poststat.us/pagely-growth-wordpress-hosting/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9862:"<p><img class="aligncenter size-full wp-image-7177" src="http://www.poststat.us/wp-content/uploads/2014/10/pagely.png" alt="pagely" width="640" height="220" /></p>
<p><a href="http://pagely.com">Pagely</a> is celebrating their fifth year of business right now. They have just launched their newly designed website (<em>note to early readers</em>: it&#8217;s in process of launching at this moment, so some links may not work until later today) to reflect some of the ways they&#8217;ve changed over the years. They are also growing, rapidly.</p>
<p>The new website is a complete rebrand. They&#8217;ve tweaked their logo many times over the years, but they&#8217;ve completely changed it now. It&#8217;s much more modern and can be used in a variety of ways.</p>
<p>The new website is flat, geometric, modern, and as sassy as ever (like with their <a href="https://pagely.com/about-us/investors/">Investors page</a> they are quite proud of). In all, the redesign attempts to showcase happy customers and what makes them different.</p>
<p><a href="http://www.poststat.us/pagely-growth-wordpress-hosting/pagely-new-homepage/" rel="attachment wp-att-7181"><img class="aligncenter size-large wp-image-7181" src="http://www.poststat.us/wp-content/uploads/2014/10/pagely-new-homepage-752x547.png" alt="pagely-new-homepage" width="627" height="456" /></a></p>
<p>They are introducing <a href="https://pagely.com/ambassadors/">brand ambassadors</a> &#8212; a kind of super testimonial &#8212; that includes names you&#8217;ll surely recognize from the WordPress community.</p>
<p>Additionally, they are giving other managed hosts a bit of a sting with what they call <a href="https://pagely.com/turnthepage/">#turnthepage</a>, a dedicated page to highlight that they don&#8217;t charge for pageviews, something that most managed WordPress hosting companies do.<span id="more-7174"></span></p>
<p>Pagely has implemented the new branding and design elements across most of their platform, including their Support sub-site.</p>
<p><img class="aligncenter size-large wp-image-7176" src="http://www.poststat.us/wp-content/uploads/2014/10/support-pagely-752x491.png" alt="support-pagely" width="627" height="409" /></p>
<p>In addition to branding and a web redesign, Pagely is attempting to showcase that they were first to market with managed WordPress hosting, but also that they are best in class. The strategy &#8212; and particularly their recent all-in <a title="Pagely has new plans, a new dashboard, and a new Amazon Web Services infrastructure" href="http://www.poststat.us/pagely-wordpress-hosting-amazon/">move to being an AWS-based service</a> &#8212; appear to be working.</p>
<h3>Record growth</h3>
<p>I discussed the Pagely redesign and their recent growth with Joshua Strebel, Pagely co-founder and CEO. He told me that they&#8217;ve seen an enormous amount of growth this year.</p>
<p>Revenue is up 28% in the last month alone and between 40-45% quarter over quarter. This means that Pagely is on pace to more than double in size between this summer and next.</p>
<p>To some this may seem a surprise, but it&#8217;s part of some slow and steady investments Pagely has made in recent years.</p>
<p>They certainly did not scale at the pace of other players in the market &#8212; most notably <a href="http://wpengine.com">WP Engine</a>. They also (as noted above with the Investors page) have bootstrapped their company from the beginning.</p>
<p>Noone knows exactly how big Pagely is today, and that&#8217;s part of what you get with their owners. Though I&#8217;m told they are &#8220;more than 10 people but fewer than 50.&#8221;</p>
<p><img class="aligncenter size-large wp-image-6550" src="http://www.poststat.us/wp-content/uploads/2014/05/pagely-team-752x378.jpg" alt="pagely-team" width="627" height="315" /></p>
<p>The Strebel&#8217;s (on the left of the picture above) own the company &#8212; only sharing equity with some key employees &#8212; and they are proud of their independence.</p>
<p>It&#8217;s nearly impossible to be a Pagely customer without feeling the presence of Josh and Sally Strebel&#8217;s own personalities. And while Josh is an opinionated figure in the WordPress community, Pagely customers seem quite happy with that.</p>
<h3>Managed host customer satisfaction</h3>
<p>Steven Gliebe started a new project recently called <a href="http://hostingreviews.io/">HostingReviews.io</a>, a website that attempts to collect non-biased reviews from social media about various hosting solutions. Pagely has a 94% happiness rating according to HostingReviews.io &#8212; matched only by <a href="http://getflywheel.com">Flywheel&#8217;s</a> 95% rating.</p>
<p>I like Steven&#8217;s project because he is not using affiliates at all with this project, an aspect that spoils most hosting review websites. Here&#8217;s a breakdown of some others:</p>
<p><a href="http://www.poststat.us/pagely-growth-wordpress-hosting/hosting-reviews-io/" rel="attachment wp-att-7175"><img class="aligncenter size-large wp-image-7175" src="http://www.poststat.us/wp-content/uploads/2014/10/hosting-reviews-io-752x757.png" alt="hosting-reviews-io" width="627" height="631" /></a></p>
<p>&nbsp;</p>
<h3>Changes in managed WordPress hosting markets</h3>
<p>It&#8217;s been an interesting time to analyze the managed WordPress hosting market. For one, the term &#8220;managed WordPress hosting&#8221; is here to stay. Nearly every large player &#8212; including the likes of GoDaddy, Bluehost, Dreamhost, and more &#8212; offer a managed WordPress hosting product.</p>
<p>The differences between these large company products and the original smaller players &#8212; players like Pagely, WP Engine, Pressable, and later entrants like Flywheel, Siteground, and Pantheon &#8212; are beyond the name of the product. You really have to dig into each service and business model to get a full grasp of how they are unique.</p>
<p>And this is really hard.</p>
<p>For one, you can find positive and negative things about every host in the world. But also, these companies are often targeting different audiences. For instance, GoDaddy and the other large hosts pretty clearly want the smaller website audience, but to upsell them with a more WordPress-specific package. And that&#8217;s fine; they can offer some great functionality for that.</p>
<p>But Pagely, Pantheon, and some others are going after bigger fish; and they are marketing themselves appropriately.</p>
<h3>Going after WordPress.com VIP</h3>
<p><a href="http://vip.wordpress.com/">WordPress.com VIP</a> is the king of the big-WordPress mountain. They have the promise of infinite scale and excellent reliability. It&#8217;s Automattic&#8217;s own product and an excellent business model for them.</p>
<p>They are able to charge big companies big dollars (relative to other WordPress hosting, not compared to some enterprise software these companies are used to) to get the assurance that their website is hosted safely and reliably.</p>
<p>WordPress.com <a href="http://vip.wordpress.com/stats/">serves billions of pageviews every month</a>. It&#8217;s simply a massive platform and a comfortable place for companies to take their WordPress hosting needs.</p>
<p>Pagely wants to be an alternative to WordPress.com VIP. They see themselves as a viable and attractive alternative. For one, they&#8217;ll tell you that you can run anything on Pagely; whereas WordPress VIP has a restricted ecosystem that involves approved-only plugins and stringent code reviews for any custom code, that often requires one of their VIP service partners to perform the work.</p>
<blockquote><p>VIP is a great service. However it is no longer the only service capable of serving clients at scale. We are winning more of those high-caliber clients that need the extra flexibility our stack offers.</p>
<p>&#8211; Joshua Strebel, Pagely CEO</p></blockquote>
<p>Pagely and others seeking the high end market are still relatively early on in their efforts; WordPress.com VIP is a behemoth in that market.</p>
<h3>A changing tide</h3>
<p>I&#8217;ve noticed &#8212; and I&#8217;m sure some of you have too &#8212; a change in tide of WordPress managed hosting. This year has no doubt been a very tough one for some managed hosts.</p>
<p>It&#8217;s been painful to see customers that were once happy with their service &#8212; to the point of being huge brand ambassadors themselves &#8212; to quietly leaving and moving on to something else, now with warranted skepticism.</p>
<p>Personally, I try to stay pretty host-agnostic. It is a very difficult market to say anything about, due to its incredibly competitive nature. However, I think it&#8217;s obvious that Pagely &#8212; accompanied by the likes of <a href="http://siteground.com">SiteGround</a> and <a href="http://getpantheon.com">Pantheon</a> &#8212; is on the rise while some of the other early entrants to WordPress managed hosting are struggling to consistently deliver on their promises.</p>
<p>However, with new-found popularity and fast growth, Pagely too can be susceptible to some of the same growing pains of their competition. But they say they&#8217;re ready for it.</p>
<p>They&#8217;ve invested heavily in AWS and put all their technology chips in Amazon&#8217;s basket. And they assure me that they have been hiring some of the best support techs and engineers in the business. Additionally, they tell me that because they aren&#8217;t investing a ton of money into marketing, their customer influx is more natural and less likely to strain more linear growth levels.</p>
<p>Time will tell if <a href="http://pagely.com">Pagely</a> is ready to scale with players that have more money and resources than they do, but they&#8217;re definitely excited about the recent growth, the new brand and website, their brand ambassadors, and the challenges ahead.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 08 Oct 2014 19:41:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"WPTavern: My Experience at WordCamp Ann Arbor 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31846";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wptavern.com/my-experience-at-wordcamp-ann-arbor-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9897:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampAnnArbor2014.png" rel="prettyphoto[31846]"><img class="aligncenter wp-image-31783 size-full" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampAnnArbor2014.png?resize=680%2C265" alt="WordCamp Ann Arbor 2014 Header" /></a></p>
<p>After a <a title="http://wptavern.com/5-wordpress-conferences-taking-place-this-weekend" href="http://wptavern.com/5-wordpress-conferences-taking-place-this-weekend">busy weekend of WordPress conferences</a>, among those that took place is the first ever <a title="http://2014.annarbor.wordcamp.org/" href="http://2014.annarbor.wordcamp.org/">WordCamp Ann Arbor</a>. Situated on the University of Michigan campus at the <a title="http://uunions.umich.edu/league/" href="http://uunions.umich.edu/league/">Michigan League</a>, nearly 150 people from all walks of life gathered to learn about WordPress.</p>
<h2>Beginner&#8217;s Guide to WordCamps</h2>
<p>I started the day with a session by <a title="http://serverpress.com/" href="http://serverpress.com/">Marc Benzakein</a> entitled &#8220;<a title="http://2014.annarbor.wordcamp.org/session/how-to-rock-a-wordcamp-even-if-youre-a-total-noob/" href="http://2014.annarbor.wordcamp.org/session/how-to-rock-a-wordcamp-even-if-youre-a-total-noob/">How to Rock a WordCamp Even if You’re a Total n00b</a>.&#8221; When Benzakein asked how many in the room were attending their first WordCamp, the majority raised their hands. After attending more than a dozen WordCamps, Benzakein offers advice to first-time attendees and explains how to get the most out of the event.</p>
<a href="http://wptavern.com/my-experience-at-wordcamp-ann-arbor-2014#gallery-31846-2-slideshow">Click to view slideshow.</a>
<p>&nbsp;</p>
<p>I&#8217;d like to see more WordCamps incorporate the same or a similar session at the beginning of the event, especially if it&#8217;s the first one for the area. It breaks the ice and gives attendees a realistic expectation of what a WordCamp is all about. Those who attended the presentation had the opportunity to meet Benzakein&#8217;s son, Eli.</p>
<p>His son contributed to the conversation and helped break the ice with his humorous questions and commentary. He contributed so much that if he <del>registers an account on WordPress.org</del>, I&#8217;d like to see the speakers badge added to <a title="https://profiles.wordpress.org/Elijahbenzak" href="https://profiles.wordpress.org/Elijahbenzak">his profile</a>. If you&#8217;d like more information on how to survive your first WordCamp, Carrie Dils has an excellent <a title="http://www.carriedils.com/wordcamp-tips/" href="http://www.carriedils.com/wordcamp-tips/">survival guide</a> available.</p>
<h2> Child Themes and Theme Frameworks</h2>
<p>Next up, I sat in on <a title="http://philhoyt.com/" href="http://philhoyt.com/">Phil Hoyt&#8217;s</a> presentation on using <a title="http://2014.annarbor.wordcamp.org/session/using-frameworks-and-child-themes/" href="http://2014.annarbor.wordcamp.org/session/using-frameworks-and-child-themes/">Frameworks and Child Themes</a>. He described the benefits of what a theme framework offers and the proper way of editing themes via child themes. His theme framework is called <a title="https://wordpress.org/themes/generic-framework" href="https://wordpress.org/themes/generic-framework">Generic</a> and is available for free on the WordPress Theme Directory.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/156.jpg" rel="prettyphoto[31846]"><img class="size-large wp-image-31860" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/156.jpg?resize=500%2C375" alt="Child Themes and Theme Frameworks" /></a>Learning about Child Themes and Theme Frameworks
<h2>Be The Peacock</h2>
<p>My favorite session of the day was &#8220;<a class="wcpt-session-title" href="http://2014.annarbor.wordcamp.org/session/be-the-peacock-creating-and-loving-your-online-brand/">Be the Peacock: Creating and Loving Your Online Brand</a>&#8221; by <a title="http://www.web-savvy-marketing.com/" href="http://www.web-savvy-marketing.com/">Rebecca Gill</a>. The idea behind her presentation is that a peacock has beautiful, vibrant colors, and is not afraid to strut them. Likewise, individuals need to stand out and make themselves and their brand distinguishable. In the presentation, she tells the story of how she was once a shy individual, afraid to strut her colors and diagnosed with <a title="http://wordpress.tv/2014/02/14/chris-lema-escaping-the-impostor-syndrome/" href="http://wordpress.tv/2014/02/14/chris-lema-escaping-the-impostor-syndrome/">Imposter Syndrome</a>. After receiving a pep talk from <a title="http://chrislema.com/" href="http://chrislema.com/">Chris Lema</a>, she embraced her inner peacock.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/157.jpg" rel="prettyphoto[31846]"><img class="size-large wp-image-31862" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/10/157.jpg?resize=500%2C375" alt="Be The Peacock Not The Peahen" /></a>Be The Peacock Not The Peahen
<p>&nbsp;</p>
<h2>Wise Words From a Mentor</h2>
<p>When <a title="http://3.7designs.co/" href="http://3.7designs.co/">Ross Johnson</a> put the wheels in motion to organize WordCamp Ann Arbor, he didn&#8217;t have a reference level of interest. Although the Ann Arbor area has a <a title="http://www.meetup.com/WordPress-Ann-Arbor/" href="http://www.meetup.com/WordPress-Ann-Arbor/">monthly meetup group</a> with 40-50 rotating attendees, he didn&#8217;t know if people would feel compelled to travel from Detroit. Because of the uncertainty, attendance for the event was capped at 150 tickets. &#8220;We ended up selling out early and having nearly seventy people on the waiting list. We of course had made all of our accommodations based on 150 people,&#8221; Johnson told the Tavern.</p>
<p>John Hawkins who organized WordCamp Las Vegas 2013 and is putting together <a title="http://2014.vegas.wordcamp.org/" href="http://2014.vegas.wordcamp.org/">the event for 2014</a> mentored Johnson along with a few other first-time organizers. Hawkins suggested to Johnson that he should release more tickets and that 10-15% of people wouldn&#8217;t show up. &#8220;As predicted, a large group of people didn&#8217;t show up and we were able to accommodate everyone without issue.&#8221;</p>
<h2>Finding a Venue</h2>
<p>Finding a venue can be one of the more challenging aspects of organizing a WordCamp. Most speakers appreciate being able to walk to the venue from their hotel room. After ruling out corporate venues due to cost, Johnson was left to choose between donated office space, public space, or the University of Michigan.</p>
<p><a title="http://www.lyndsayjohnson.com/" href="http://www.lyndsayjohnson.com/">Lyndsay Johnson</a> who studied at the University recommended that he try contacting the <a title="http://uunions.umich.edu/league/" href="http://uunions.umich.edu/league/">Michigan League</a> event services department. &#8220;After touring the facilities we knew it was the spot we wanted to try. It was central to downtown and had an incredible classic vibe to it which brought an interesting contrast for a tech event.&#8221; Another benefit to using the League is the on site catering as well as a strong technology team to help keep technical hiccups to a minimum.</p>
<h2>Lessons Learned From a First Timer</h2>
<p>Johnson recommends that organizers start early. While WordCamp Ann Arbor took place on October 14th, he sent out the first email related to the event in early February. &#8220;On paper it doesn&#8217;t look like there is <i>that</i> match to do, but it&#8217;s more than it seems.&#8221; Second and third time organizers have the luxury of building off of previous experience. That&#8217;s a luxury first timers don&#8217;t have. &#8220;When starting from scratch you have to design a new website, new badges, new logo, etc.&#8221;</p>
<p>One of the most important aspects of managing a large event such as a WordCamp is the team surrounding you. &#8220;Get a group of organizers that you can really trust and don&#8217;t be afraid to delegate to them.&#8221; In addition to Johnson, the organizing team includes: Justin Ferriman, Kloe Ferriman, Rebecca Gill, Lyndsay Johnson, Kyle Maurer, and Declan O&#8217;Neill. Despite having help, Johnson feels as though he took on too much work and will do a better job next year of asking for help.</p>
<h2>Will There be a WordCamp Ann Arbor 2015?</h2>
<p>Johnson tells me that they&#8217;ll likely have a second WordCamp in Ann Arbor next year and planning will begin sometime in February or earlier.</p>
<h2>Can&#8217;t Wait For Round Two</h2>
<p>For a first time event, WordCamp Ann Arbor didn&#8217;t experience many hiccups. The WiFi speeds at the League were fantastic with a consistent 20Mb up and down throughout the day. Attendees had to fend for themselves at lunch, but the setup offered an opportunity to exercise with a short walk to main street. Downtown Ann Arbor is filled with great places to eat but many of the locations are small, not being able to handle 10 or more people per table.</p>
<p>With only 150 attendees, the atmosphere was relaxed and there was ample opportunity to meet each other. Attending WordCamp Ann Arbor reaffirms my feeling of enjoying smaller WordCamps versus those with 300 or more attendees. Last but not least, the University of Michigan is a beautiful campus, especially this time of year. If you live in or around the Ann Arbor area, keep tabs on the <a title="http://central.wordcamp.org/schedule/" href="http://central.wordcamp.org/schedule/">WordCamp Central schedule</a> and consider attending WordCamp in 2015.</p>
<a href="http://wptavern.com/my-experience-at-wordcamp-ann-arbor-2014#gallery-31846-3-slideshow">Click to view slideshow.</a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 08 Oct 2014 19:32:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"Lorelle on WP: WordPress and Blogging Workshop in Forest Grove, Oregon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://lorelle.wordpress.com/?p=11958";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:95:"http://lorelle.wordpress.com/2014/10/07/wordpress-and-blogging-workshop-in-forest-grove-oregon/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:458:"On Friday, October 10, 2014, from 1-5PM I will be presenting a WordPress and Blogging Workshop in Forest Grove, Oregon, at the Forest Grove Senior and Community Center as a fundraiser for the center and part of the Writers in the Grove group. The price for this 4 hour event is $30 ($5 discount with [&#8230;]<img alt="" border="0" src="http://pixel.wp.com/b.gif?host=lorelle.wordpress.com&blog=72&post=11958&subd=lorelle&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 08 Oct 2014 05:06:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: WebDevStudios Acquires WordPress Support Services Company, Maintainn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31827";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wptavern.com/webdevstudios-acquires-wordpress-support-services-company-maintainn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4189:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2009/02/webdevstudioslogo.png" rel="prettyphoto[31827]"><img class="aligncenter size-full wp-image-533" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2009/02/webdevstudioslogo.png?resize=405%2C81" alt="webdevstudioslogo" /></a></p>
<p>WordPress development agency, <a title="http://webdevstudios.com/" href="http://webdevstudios.com/">WebDevStudios</a>, has acquired <a title="https://maintainn.com/" href="https://maintainn.com/">Maintainn</a> for an undisclosed amount. According to the <a title="http://webdevstudios.com/2014/10/07/webdevstudios-acquires-maintainn-to-bring-wordpress-support-and-maintenance-services-in-house/" href="http://webdevstudios.com/2014/10/07/webdevstudios-acquires-maintainn-to-bring-wordpress-support-and-maintenance-services-in-house/">announcement</a>, the acquisition enables WebDevStudios to provide better maintenance and support to clients. Founded in 2012 by <a title="https://maintainn.com/team/shayne-sanderson/" href="https://maintainn.com/team/shayne-sanderson/">Shayne Sanderson</a>, Maintainn provides maintenance services including 24/7 security monitoring, daily off-site backups, weekly updates to WordPress core, themes and plugins, a dedicated WordPress support desk and custom development.</p>
<p>Sanderson, once an employee for WebDevStudios as a Technical Project Manager, <a title="http://shaynesanderson.com/2013/11/15/on-the-road-again/" href="http://shaynesanderson.com/2013/11/15/on-the-road-again/">left the company in late 2013</a> to work on Maintainn full-time. What started as an individual endeavor, turned into a five person company.</p>
<h2>The Retainer Arm of WebDevStudios</h2>
<p>On paper, the acquisition makes sense. WebDevStudios is able to focus on attracting new clients knowing they have a foundation in place to offer support and maintenance packages to new and existing clients. Maintainn is essentially the retainer arm of WebDevStudios. Retainers are defined as, &#8220;a fee paid in advance to someone, especially an attorney, in order to secure or keep their services when required.&#8221; When applying the definition to development agencies, it&#8217;s not hard to see why most have a retainer program in place.</p>
<p>Brian Krogsgard, who works for WordPress design and development company <a title="http://ran.ge/" href="http://ran.ge/">Range</a>, explains why retainers can be an important part of an agency&#8217;s business model.</p>
<blockquote><p>Retainers can be an excellent business tool for financing growth and forming long-term client relationships. Retainers offer consistent, reliable income that makes financing new hires less scary. They also allow the firm to really get to know the client and their needs over time, versus being limited to a single project scope. An existing retainer also puts the firm in great position to get lump sum projects from the client when those opportunities come up.</p></blockquote>
<p>Not only do clients receive maintenance and support for WordPress, they also have access to a great team of developers. This gives WebDevStudios a competitive edge against companies such as <a title="http://www.wpsitecare.com/" href="http://www.wpsitecare.com/">WP Site Care</a>, <a title="http://wpcurve.com/" href="http://wpcurve.com/">WP Curve</a>, and <a title="http://wpmaintainer.com" href="http://wpmaintainer.com">WP Maintainer</a> that mostly focus mostly on maintenance and support.</p>
<h2>MattReport Interview With Both Parties</h2>
<p>I encourage you to read <a title="http://mattreport.com/webdevstudios-acquires-maintainn/" href="http://mattreport.com/webdevstudios-acquires-maintainn/">this interview</a> published on MattReport.com containing insight from both parties involved in the deal. Communication and keeping financial books in order are just two pieces of advice given within the interview. It also shines a light on the future of Maintainn and what its role will be within the company.</p>
<p>What are your thoughts on the acquisition and will we see other WordPress maintenance companies acquired in the near future? If so, use the comments and give us your best guess.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 07 Oct 2014 23:15:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: Tavern Interview";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44238";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2014/10/tavern-interview/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:276:"<p>Sarah Gooding of the WordPress inside baseball blog <a href="http://wptavern.com/">WP Tavern</a> has an interview with me she titled <a href="http://wptavern.com/matt-mullenweg-on-ensuring-the-future-of-wordpress">Matt Mullenweg on Ensuring the Future of WordPress</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 07 Oct 2014 13:55:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"Post Status: Is WordPress right for eCommerce?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=7165";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://www.poststat.us/wordpress-right-ecommerce/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:11868:"<p><img class="aligncenter size-large wp-image-7170" src="http://www.poststat.us/wp-content/uploads/2014/10/wordpress-ecommerce-discussion-752x352.jpg" alt="wordpress-ecommerce-discussion" width="627" height="293" /></p>
<p>I&#8217;m going to take a leaf out of <a href="http://www.chrislema.com/">Chris Lema&#8217;s</a> book right now to answer whether WordPress should be used for eCommerce: <strong>It depends</strong>.</p>
<p>There are camps of thought that think WordPress isn&#8217;t right for eCommerce, and there are people that think it&#8217;s the only way to go. Having worked with and used several different eCommerce platforms (both hosted and self-hosted), I&#8217;ve definitely developed the mindset that there are use cases for each. WordPress can be the right choice in a lot of circumstances, but not all.</p>
<h3>Hosted vs. self-hosted</h3>
<p>If you&#8217;re not sure about the major differences between hosted vs self hosted platforms, I recommend reading <em>Patrick Rauland&#8217;s</em> <a href="http://speakinginbytes.com/2014/08/hosted-vs-self-hosted-e-commerce/">overview of the major differences</a>. WordPress eCommerce usually falls under self-hosted eCommerce (I don&#8217;t count WordPress.com since it uses external eCommerce solutions). Forbes also <a href="http://www.forbes.com/sites/allbusiness/2014/09/26/which-e-commerce-platform-is-the-best-choice-for-your-online-store/">recently wrote about this</a>, though I don&#8217;t necessarily agree with their conclusions.</p>
<p>The <a href="http://www.practicalecommerce.com/articles/70101-When-to-Avoid-WordPress-Ecommerce">typical viewpoint</a> is that WordPress plugins like WooCommerce or Easy Digital Downloads are great for small stores or people that just want to quickly and easily sell a few items, while hosted platforms like Shopify and Bigcommerce are for &#8220;serious&#8221; stores.</p>
<p>This viewpoint is actually pretty backwards, not to mention the fact that the number of items is a poor way of determining which platform you should use.</p>
<h3 id="give-each-its-due">Give each its due</h3>
<p>Is WordPress the best platform on which to build apps? I don&#8217;t always think so, but it <strong>could be</strong>. Is it always a good choice for eCommerce? Nope. However, it&#8217;s the <strong>right one</strong> for lots of stores, and it&#8217;s the <strong>wrong one</strong> for lots of stores.</p>
<p>There are a few major strengths and weaknesses of both WordPress and hosted solutions. I&#8217;ve worked most with <a href="http://www.woothemes.com/woocommerce/">WooCommerce</a>, <a href="http://easydigitaldownloads.com/">Easy Digital Downloads</a>, and <a href="http://www.shopify.com/">Shopify</a>, but have tried lots of other eCommerce solutions for comparison. Some of the knocks against WordPress aren&#8217;t valid, but we should note that some are.</p>
<h3>WordPress eCommerce weaknesses</h3>
<p>Everyone loves to talk about how easy certain WordPress plugins are to use. When you compare WordPress plugins to something like Shopify, this just <strong>isn&#8217;t true</strong>. They may be easy to use for people that are familiar with WordPress, but not for the average user who wants to start selling online with no experience.</p>
<p>WordPress requires a domain name purchase, hosting setup, installation, plugin installation and setup, theme installation and setup, blah blah blah, you get the drift. With hosted solutions, you don&#8217;t worry about this (though solutions like <a href="http://evermo.re/">Evermore</a> &#8212; which was <a title="Evermore, hosted WordPress with power and ease of use" href="http://www.poststat.us/evermore-interview/">covered by Post Status</a> when it launched &#8212; make this interesting). You pay your monthly bill, and you&#8217;re handed a store website &#8211; you just pick the name and get rolling. You can start adding products right away, and then you might get into changing your theme or other setup.<span id="more-7165"></span></p>
<div id="attachment_7167" class="wp-caption alignright"><img class="wp-image-7167 size-medium" src="http://www.poststat.us/wp-content/uploads/2014/10/easy-300x258.jpg" alt="easy" width="300" height="258" /><p class="wp-caption-text"><a href="https://c2.staticflickr.com/4/3181/3086827283_e9e762331c.jpg">Image Credit</a></p></div>
<p>Some of the site tweaks or setup with hosted solutions aren&#8217;t easy, but the learning curve for a solution like Shopify is far gentler than the learning curve for something like WooCommerce.</p>
<p>There are also <strong>WP Cron</strong> issues for some sites, as it&#8217;s not a perfect system for scheduling actions, like recurring payments. It can work pretty well, but other platforms can make this far easier to implement and more reliable than Cron.</p>
<p>WordPress store owners are also <strong>responsible</strong> for their own hosting, software updates, and security. For many site owners, these are huge responsibilities. Hosted solutions roll all of this into their package so that users don&#8217;t have to know how their website is powered. They just have to use it.</p>
<p>Both WordPress and hosted solutions will scale, but there are considerations with WordPress that users need to be aware of. Database issues (like backups or memory with massive amounts of customers and orders) should be addressed, hosting has to be optimized, and plugins need to scale with the site. With a hosted solution, none of this is your problem as a user.</p>
<h3>WordPress eCommerce strengths</h3>
<p>Bearing these weaknesses in mind, it&#8217;s a bit crazy to me that WordPress is sometimes referred to as the &#8220;easy solution&#8221; or the right tool for &#8220;small stores&#8221;. It&#8217;s not. In many cases, it&#8217;s like bringing a tank to the eCommerce playground.</p>
<p>So what does WordPress do well?</p>
<p>First, WordPress offers the most all-in-one website solution available. WordPress can offer the eCommerce aspects of the website, in addition to its many other CMS features. The ability to create a single, seamless CMS experience for a multi-purpose website makes it quite compelling and more budget-friendly than more &#8220;eCommerce first&#8221; platforms.</p>
<p>Second, it&#8217;s optimized for <strong>SEO</strong>. Your content is crucial here, and WordPress is built for content. More importantly, if you&#8217;ve tried to blog on another platform, you know how painful it can be (don&#8217;t start with me Squarespace fans, that thing is difficult to use). WordPress doesn&#8217;t encourage you to avoid blogging to avoid headache: it&#8217;s built for <strong>complete websites</strong>, and is not simply focused on eCommerce.</p>
<p>WordPress also contains functionality that you can&#8217;t always get with different platforms. There&#8217;s a massive selection of plugins, themes, and all sorts of solutions for WordPress that are readily available. Since it&#8217;s open source, it&#8217;s far easier to find ways to customize it when compared to closed platforms like Bigcommerce.</p>
<p>Speaking of customizations, your ability to customize WordPress or plugins is <strong>far</strong> easier than with hosted solutions. There&#8217;s lots of functionality that can be achieved with WordPress that&#8217;s not even possible in hosted solutions. For example, developers have no control over the Shopify checkout process, but this can be entirely customized with WordPress.</p>
<p>You can also usually find a plugin that will provide a &#8220;starting point&#8221; for a customization project. Even if you find a Shopify or Bigcommerce app that gets <em>close</em> to what you need, but not quite, you&#8217;ll need to create a completely custom solution anyway &#8211; there&#8217;s no &#8220;extending&#8221; there.</p>
<p>Along with customization is the <strong>control over your environment</strong>. You can spin up your eCommerce site on something like Digital Ocean, and you&#8217;ve got control over the entire site, from server to theme.</p>
<h3>Product type</h3>
<p>The biggest difference for me between hosted solutions and self-hosted actually isn&#8217;t usability or scalability &#8211; it&#8217;s <strong>product type</strong>. Can almost every eCommerce platform sell tee shirts? Yes. Even EDD can do that, and it&#8217;s made for digital products.</p>
<p>However, selling complex products becomes infinitely more difficult on hosted platforms, as you&#8217;re restricted to what the API offers for product changes, which isn&#8217;t always a lot. For example, if you&#8217;ve ever tried to add pricing changes for customization options in Shopify, you know that it literally takes some wizardry, black magic, and possibly bubble gum used as tape to do so.</p>
<p>WordPress plugins make this far easier, because the entire platform is open, not just an API. Most eCommerce plugins have more than enough actions or filters to change products, product pages, checkout forms, or any other part of your site.</p>
<h3>Recap</h3>
<p>Hosted eCommerce solutions are typically easy to use, and can provide some customization options via apps or other add-on services. However, it&#8217;s like renting a house versus owning. With a rented house, you can&#8217;t go knocking down walls or completely remodeling &#8211; you&#8217;ve got to work inside of a framework you&#8217;re given. This is exactly how a hosted solution works.</p>
<p>The benefit to this is that you absolve yourself of a lot of responsibility and worry. The entire experience is managed and supported, and is typically very easy to work with.</p>
<p>However, WordPress eCommerce is like buying the house. You can do whatever you want &#8211; add-on, rebuild sections of the house, change layouts around, add tunnels to other houses, you name it. However, when the water heater blows up, it&#8217;s your responsibility.</p>
<p>WordPress also affords the opportunity to sell complex products, such as measurement based products like corks by the pound, that simply can&#8217;t be sold on other platforms. The same ability to customize WordPress so thoroughly lets you customize the eCommerce plugin you&#8217;re using.</p>
<p>You gain the flexibility that comes with the platform, as well as the benefits like tons of plugins, themes, a great content structure, and a consistently maintained and updated core solution. However, the Frankenstein site that you build is your baby, and yours alone &#8211; you need to host it, maintain it, and care for it.</p>
<p>WordPress lets you create advanced functionality via plugins and customizations, but isn&#8217;t right for users looking for an easy, basic shop setup. If you want a move-in ready house or a beautiful rental, you should look at hosted solutions. If you&#8217;re willing to make your dream house from great bones and foundation, or you need to sell fairly complex products, then WordPress might be it for you. It&#8217;s not the &#8220;easy&#8221; solution, but it can be a great one.</p>
<div id="single-hcard-beka" class="loop-meta vcard"><h4 class="author-bio fn n">Beka Rice</h4><div class="author-description"><img alt="Beka Rice" src="http://1.gravatar.com/avatar/5ea957b08d0cf6a1e5e5cf5681519537?s=150&d=http%3A%2F%2F1.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D150&r=G" class="avatar avatar-150 photo" height="150" width="150" /><div class="user-bio author-bio">Beka is the content manager for <a href="http://skyverge.com">SkyVerge</a>, where she writes sales copy, documentation, and website content. She also runs <a href="http://sellwithwp.com">Sell with WP</a>, which is a site devoted to eCommerce using WordPress. When she’s not furiously writing, she’s playing music or leveling up her movie trivia knowledge.</div><!-- .user-bio .author-bio --></div><!-- .loop-description --></div><!-- .loop-meta -->";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 06 Oct 2014 19:03:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Beka Rice";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Matt: Gambino Mixtape STN MTN";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44227";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://ma.tt/2014/10/gambino-mixtape-stn-mtn/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:640:"<p>The ever-creative <a href="http://childishgambino.com/">Childish Gambino</a> has released a <a href="http://stonemounta.in/">new mixtape STN MTN</a> (<a href="http://www.hotnewhiphop.com/childish-gambino-stn-mtn-new-mixtape.115505.html">track by track</a>) which is part of a longer EP Kauai <a href="https://itunes.apple.com/us/album/kauai/id925162758">that was just released on iTunes</a>. Donald is a friend and an artist whose work fluently spans much more than music. And I&#8217;m not just saying that because, as Techcrunch noted, he shouts out to <a href="http://krutal.wordpress.com/">Krutal</a> and I at the end of Go DJ.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 06 Oct 2014 15:49:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:38:"Jen Mylo: Site Setup Journal: Prologue";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://jenmylo.com/?p=4558";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://jenmylo.com/2014/10/05/site-setup-journal-prologue/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2998:"<p>I think that most of the people involved in creating software for the web have completely forgotten what it&#8217;s like to navigate these waters, and that &#8220;our setup is so simple!&#8221; statements are in general full of crap. Over the next few days, I am going to try to set up up a website on a domain I own using <em><strong>only</strong></em> the documentation and support available to the average person (who doesn&#8217;t have access to lead developers and heads of support teams). Is this decision predicated by the fact that none of those people were around when I tried pinging them today at 6am? Well, yes, yes it is. But given the frustration level I have encountered in the first 2 hours alone, I am glad they&#8217;re not around right now. I&#8217;ve been setting up websites since 1999, and I think we are making the process harder, not easier.</p>
<p>Get ready for some painful descriptions of just how janky all our product flows and documentation are. I know I&#8217;m wincing.</p>
<p>I&#8217;m thinking this will wind up being the equivalent of a play in 3 acts, but I could be wrong &#8212; it depends on how complicated things get.</p>
<h3><img class="aligncenter size-full wp-image-4560" src="http://jenmylo.files.wordpress.com/2014/10/screen-shot-2014-10-05-at-8-17-45-am.png?w=520&h=241" alt="Screen shot of unavailable webpage" width="520" height="241" /></h3>
<h3></h3>
<h3>Setting</h3>
<p>A quiet home in the Pacific Northwest featuring cable internet with advertised speeds of 25Mbps down/10Mbps up. A comfortable bed with pillows propped against the headboard, against which our main character lounges at the opening of Act I, equipped with a MacBook Air circa 2010, an iPhone 5s, and a debit card.</p>
<h3>Cast of Characters</h3>
<p><strong>Jen Mylo:</strong> An average web user trying to set up a site for the first time.</p>
<p><strong>GoDaddy:</strong> The registrar holding the domain <em>[Ed. Note: Legacy registrar; I\'ll switch it to namecheap at some point before it\'s time to renew].</em></p>
<p><strong>Dreamhost:</strong> A web hosting company that Jen Mylo has loved forever and that employs one of her favorite people as their resident WP expert. They were hosting non-profits for free before it was cool.</p>
<p><strong>WordPress:</strong> An open source content management system you can use to run a website. Claims a famous 5-minute install, &#8220;well-known for its ease of installation.&#8221; Rumor has it this web app is made by a bunch of weirdos.</p>
<p><strong>BuddyPress: </strong>An open source WordPress plugin that creates a social network on your site. Also made by weirdos.</p>
<p><strong>Rivermark Community Credit Union:</strong> A community credit union in Portland, OR that likes to do everything online; where Jen Mylo keeps some of her money.</p>
<p>Stay tuned for Act I!</p><img alt="" border="0" src="http://pixel.wp.com/b.gif?host=jenmylo.com&blog=45389656&post=4558&subd=jenmylo&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 05 Oct 2014 15:20:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"Jen Mylo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Matt: All About that Bass";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44224";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://ma.tt/2014/10/all-about-that-bass/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:164:"<p>This catchy song has been making the rounds with my friends, see if you can listen and not move just a little bit:</p>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 05 Oct 2014 13:03:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Matt: New Diane Foug Art";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44236";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://ma.tt/2014/10/new-diane-foug-art/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:563:"<p><a href="http://i2.wp.com/ma.tt/files/2014/10/IMG_2422.jpg"><img src="http://i2.wp.com/ma.tt/files/2014/10/IMG_2422.jpg?w=604" alt="IMG_2422.JPG" class="alignnone size-full" /></a></p>
<p><a href="http://i2.wp.com/ma.tt/files/2014/10/IMG_2421.jpg"><img src="http://i2.wp.com/ma.tt/files/2014/10/IMG_2421.jpg?w=604" alt="IMG_2421.JPG" class="alignnone size-full" /></a></p>
<p><a href="http://i1.wp.com/ma.tt/files/2014/10/IMG_2423.jpg"><img src="http://i1.wp.com/ma.tt/files/2014/10/IMG_2423.jpg?w=604" alt="IMG_2423.JPG" class="alignnone size-full" /></a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 05 Oct 2014 03:11:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Matt: Streak";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44229";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://ma.tt/2014/10/streak/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4597:"<p>You might have noticed there have been more posts around here lately. Actually until yesterday (Oct 3) there was an unbroken string of at least one post a day since August 25th, 40 posts in total. It started with a tweet from Colin Devroe:</p>
<blockquote class="twitter-tweet" width="550"><p>I challenge <a href="https://twitter.com/mds">@mds</a> <a href="https://twitter.com/Yarcom">@yarcom</a> <a href="https://twitter.com/kyleruane">@kyleruane</a> <a href="https://twitter.com/garyvee">@garyvee</a> <a href="https://twitter.com/stewart">@stewart</a> <a href="https://twitter.com/TechonomicMan">@TechonomicMan</a> <a href="https://twitter.com/geoffd">@geoffd</a> <a href="https://twitter.com/Clarko">@clarko</a> <a href="https://twitter.com/photomatt">@photomatt</a> to personal blogging every weekday for 30dys</p>
<p>&mdash; Colin Devroe (@cdevroe) <a href="https://twitter.com/cdevroe/status/504630581117063169">August 27, 2014</a></p></blockquote>
<p></p>
<p>Until now I forgot it was only weekdays, so I was doing weekends as well. Friends know I like doing personal experiments just to question assumptions or ingrained behavior, other examples this I&#8217;ve tried this year are giving up drinking for a month, going without a smartphone for 40 days, and more recently training for a half marathon with my friend Rene. I thought blogging every day would be a burden, but it actually became a great source of joy. It was more a shift in mindset than anything &#8212; every day I read things I think are interesting, share links with friends, have thoughts that are 80% of a blog post, and write a ton privately, it was just a matter of catching those moments and turning them into something that was shared with the world.</p>
<p>The tools besides WordPress that I found super-helpful in this were <a href="http://simplenote.com/">Simplenote</a>, which was great for capturing thoughts and drafts when I was on the go, and I&#8217;ve been using the <a href="https://wordpress.org/plugins/editorial-calendar/">Editorial Calendar</a> plugin to help me schedule drafts and keep an eye on my progress. The Editorial Calendar plugin is useful but I don&#8217;t love it &#8212; I wish the calendar view moved week by week rather than replacing the whole table, that it was responsive or worked on mobile, and that it would take over your publish button so you could define a desired posting cadence (in my case every 24 hours) and it would put a finished post in the next free slot, or let you bump something to the front of the queue and push all the other posts back a day. There were a few missteps along the way with timezones but overall I&#8217;m happy with how the experiment turned out.</p>
<p>So what broke the streak? It was actually one of the other experiments: running. I&#8217;ve never considered myself a runner, and never really done it in my life, but a few months ago I started trying it and have been training up for a half marathon on November 16. (<a href="http://ma.tt/2014/10/photo-run-through-stockholm/">It&#8217;s also a great opportunity to take photos</a>.) Yesterday morning I woke up early around 5 AM and as the sun started to come up, and the weather was so nice after <a href="https://cloudup.com/cCYGA3rqlvi">I rounded the Bay Bridge</a> (planned turnaround point) kept going to Crissy Field where <a href="https://cloudup.com/caWpo6oFQ0d">I saw the Golden Gate from afar</a> and thought it would be fun to cross it. <a href="http://matt.wordpress.com/2014/10/04/under-golden-gate/">After crossing</a> I was starving by and figured 3 more miles would be a half marathon and also put me in Sausalito. The last mile or two was really tough, definitely beyond what I was ready for and I walked a lot, but <a href="http://runkeeper.com/user/photomatt/activity/446743645?&activityList=false&tripIdBase36=7dz9lp&channel=web.activity.shorturl">I was very proud of the result</a>, finishing in around 2 hours 45 minutes. But I hadn&#8217;t planned to stay out that long, and the rest of my day was full of meetings. I had moved my scheduled post for the day out so I could talk about the new Childish Gambino mixtape (post coming tomorrow) but the rest of the day was so busy and I got exhausted so early I totally forgot to post.</p>
<p>So achieved one life goal while breaking the streak on another, which is not ideal, but today is another day and I want to see if I can break the 39 day streak next. Everything happens one day at a time. <img src="http://i1.wp.com/s.ma.tt/blog/wp-includes/images/smilies/icon_smile.gif?w=604" alt=":)" class="wp-smiley" /></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 04 Oct 2014 17:42:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 21 Oct 2014 04:37:19 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"209621";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Tue, 21 Oct 2014 04:15:14 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130910170210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (520, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1413909441', 'no') ; 
INSERT INTO `wp_options` VALUES (521, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1413866241', 'no') ; 
INSERT INTO `wp_options` VALUES (522, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1413909442', 'no') ; 
INSERT INTO `wp_options` VALUES (523, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"https://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 21 Oct 2014 04:11:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2141@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"https://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"8321@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast&#039;s WordPress SEO plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"15@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29832@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Google Analytics by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Sep 2007 12:15:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2316@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:124:"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29860@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"32629@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"23862@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"21738@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"The easiest, most effective way to secure WordPress in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"18101@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"132@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"753@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"Black Studio TinyMCE Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Nov 2011 15:06:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"31973@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"The visual editor widget for Wordpress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Marco Chiesi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Meta Slider";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/ml-slider/#post-49521";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Feb 2013 16:56:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"49521@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:145:"Easy to use WordPress slider plugin. Create SEO optimised responsive slideshows with Nivo Slider, Flex Slider, Coin Slider and Responsive Slides.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Matcha Labs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Mass Advertising for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"https://wordpress.org/plugins/mass-advertising/#post-69628";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 12:05:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"69628@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:128:"Grow your -enterprise brand- and your business! Simply install, select your -advertising power- and... you are off to the races!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Mass Advertising";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:46:"https://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 21 Oct 2014 04:37:22 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Tue, 21 Oct 2014 04:46:52 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Tue, 21 Oct 2014 04:11:52 +0000";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130910170210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (524, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1413909442', 'no') ; 
INSERT INTO `wp_options` VALUES (525, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1413866242', 'no') ; 
INSERT INTO `wp_options` VALUES (526, '_transient_timeout_plugin_slugs', '1414130246', 'no') ; 
INSERT INTO `wp_options` VALUES (527, '_transient_plugin_slugs', 'a:9:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:67:"comprehensive-google-map-plugin/comprehensive-google-map-plugin.php";i:3;s:25:"google-maps-ready/gmp.php";i:4;s:9:"hello.php";i:5;s:19:"jetpack/jetpack.php";i:6;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:7;s:27:"woocommerce/woocommerce.php";i:8;s:31:"wp-google-maps/wpGoogleMaps.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (528, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1413909443', 'no') ; 
INSERT INTO `wp_options` VALUES (529, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2014/09/benny/\'>WordPress 4.0 “Benny”</a> <span class="rss-date">September 4, 2014</span><div class="rssSummary">Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader Benny Goodman, is available for download or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we’ve put a little extra polish into it. This release brings you a smoother writing and management experience [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/easily-edit-a-post-or-page-using-the-slash-edit-plugin\'>WPTavern: Easily Edit a Post or Page Using The Slash Edit Plugin</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/jason-schuller-to-re-enter-wordpress-theme-market-with-niche-admin-designs\'>WPTavern: Jason Schuller to Re-Enter WordPress Theme Market with Niche Admin Designs</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/the-first-rate-and-review-a-plugin-day-is-a-success\'>WPTavern: The First “Rate and Review a Plugin Day” is a Success</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'https://wordpress.org/plugins/wysija-newsletters/\' class=\'dashboard-news-plugin-link\'>MailPoet Newsletters</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=wysija-newsletters&amp;_wpnonce=7bd9aa3920&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'MailPoet Newsletters\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (533, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1413882512', 'yes') ; 
INSERT INTO `wp_options` VALUES (534, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"4690";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2907";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2823";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"2344";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2238";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1804";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1619";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1591";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1569";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1533";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1496";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1485";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1403";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1236";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1183";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1133";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:4:"1081";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:4:"1027";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:4:"1018";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"849";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"844";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"838";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"806";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"798";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"747";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"710";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"709";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"673";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"663";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"631";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"626";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"623";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"619";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"613";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"600";}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";s:3:"572";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"564";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"561";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"554";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"553";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (538, 'hmbkp_default_path', '/Users/cyponthemic/Desktop/ARTWORKS/WORDPRESS/FallenGiants/fallengiants/wp-content/backupwordpress-d607ae7b9c-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (539, 'hmbkp_path', '/Users/cyponthemic/Desktop/ARTWORKS/WORDPRESS/FallenGiants/fallengiants/wp-content/backupwordpress-d607ae7b9c-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (540, 'hmbkp_schedule_default-1', 'a:4:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";i:1413932400;s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (541, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1414292400;s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (542, 'hmbkp_plugin_version', '2.6.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (545, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2827830244', 'no') ; 
INSERT INTO `wp_options` VALUES (546, '_transient_hmbkp_schedule_default-1_database_filesize', '1802240', 'no') ; 
INSERT INTO `wp_options` VALUES (573, '_transient_timeout_cgmp_update_routine', '1414640837', 'no') ; 
INSERT INTO `wp_options` VALUES (574, '_transient_cgmp_update_routine', 'execute only once a week', 'no') ; 
INSERT INTO `wp_options` VALUES (579, '_transient_timeout_wc_upgrade_notice_2.2.6', '1414126296', 'no') ; 
INSERT INTO `wp_options` VALUES (580, '_transient_wc_upgrade_notice_2.2.6', '', 'no') ; 
INSERT INTO `wp_options` VALUES (582, '_transient_woocommerce_cache_excluded_uris', 'a:6:{i:0;s:4:"p=35";i:1;s:5:"/cart";i:2;s:4:"p=37";i:3;s:9:"/checkout";i:4;s:4:"p=39";i:5;s:11:"/my-account";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (583, 'product_cat_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (589, 'pa_vintage_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (601, 'rewrite_rules', 'a:199:{s:22:"^wc-api/v([1-2]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-2]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:12:"our-wines/?$";s:27:"index.php?post_type=product";s:42:"our-wines/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:37:"our-wines/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:29:"our-wines/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:55:"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:43:"product-category/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"product-category/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:52:"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:47:"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:40:"product-tag/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:22:"product-tag/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:46:"vintage/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?pa_vintage=$matches[1]&feed=$matches[2]";s:41:"vintage/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?pa_vintage=$matches[1]&feed=$matches[2]";s:34:"vintage/(.+?)/page/?([0-9]{1,})/?$";s:50:"index.php?pa_vintage=$matches[1]&paged=$matches[2]";s:16:"vintage/(.+?)/?$";s:32:"index.php?pa_vintage=$matches[1]";s:46:"variety/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?pa_variety=$matches[1]&feed=$matches[2]";s:41:"variety/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?pa_variety=$matches[1]&feed=$matches[2]";s:34:"variety/(.+?)/page/?([0-9]{1,})/?$";s:50:"index.php?pa_variety=$matches[1]&paged=$matches[2]";s:16:"variety/(.+?)/?$";s:32:"index.php?pa_variety=$matches[1]";s:47:"vineyard/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?pa_vineyard=$matches[1]&feed=$matches[2]";s:42:"vineyard/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?pa_vineyard=$matches[1]&feed=$matches[2]";s:35:"vineyard/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?pa_vineyard=$matches[1]&paged=$matches[2]";s:17:"vineyard/(.+?)/?$";s:33:"index.php?pa_vineyard=$matches[1]";s:45:"winery/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?pa_winery=$matches[1]&feed=$matches[2]";s:40:"winery/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?pa_winery=$matches[1]&feed=$matches[2]";s:33:"winery/(.+?)/page/?([0-9]{1,})/?$";s:49:"index.php?pa_winery=$matches[1]&paged=$matches[2]";s:15:"winery/(.+?)/?$";s:31:"index.php?pa_winery=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:33:"product/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:39:"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:28:"product/([^/]+)(/[0-9]+)?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"product_variation/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"product_variation/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"product_variation/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"product_variation/([^/]+)/trackback/?$";s:44:"index.php?product_variation=$matches[1]&tb=1";s:46:"product_variation/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&paged=$matches[2]";s:53:"product_variation/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&cpage=$matches[2]";s:43:"product_variation/([^/]+)/wc-api(/(.*))?/?$";s:58:"index.php?product_variation=$matches[1]&wc-api=$matches[3]";s:49:"product_variation/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"product_variation/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:38:"product_variation/([^/]+)(/[0-9]+)?/?$";s:56:"index.php?product_variation=$matches[1]&page=$matches[2]";s:34:"product_variation/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"product_variation/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"product_variation/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"shop_order_refund/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"shop_order_refund/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"shop_order_refund/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"shop_order_refund/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"shop_order_refund/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"shop_order_refund/([^/]+)/trackback/?$";s:44:"index.php?shop_order_refund=$matches[1]&tb=1";s:46:"shop_order_refund/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?shop_order_refund=$matches[1]&paged=$matches[2]";s:53:"shop_order_refund/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?shop_order_refund=$matches[1]&cpage=$matches[2]";s:43:"shop_order_refund/([^/]+)/wc-api(/(.*))?/?$";s:58:"index.php?shop_order_refund=$matches[1]&wc-api=$matches[3]";s:49:"shop_order_refund/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"shop_order_refund/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:38:"shop_order_refund/([^/]+)(/[0-9]+)?/?$";s:56:"index.php?shop_order_refund=$matches[1]&page=$matches[2]";s:34:"shop_order_refund/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"shop_order_refund/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"shop_order_refund/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"shop_order_refund/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"shop_order_refund/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"orbit/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"orbit/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"orbit/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"orbit/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"orbit/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"orbit/([^/]+)/trackback/?$";s:32:"index.php?orbit=$matches[1]&tb=1";s:34:"orbit/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?orbit=$matches[1]&paged=$matches[2]";s:41:"orbit/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?orbit=$matches[1]&cpage=$matches[2]";s:31:"orbit/([^/]+)/wc-api(/(.*))?/?$";s:46:"index.php?orbit=$matches[1]&wc-api=$matches[3]";s:37:"orbit/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:48:"orbit/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:26:"orbit/([^/]+)(/[0-9]+)?/?$";s:44:"index.php?orbit=$matches[1]&page=$matches[2]";s:22:"orbit/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"orbit/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"orbit/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"orbit/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"orbit/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:20:"order-pay(/(.*))?/?$";s:32:"index.php?&order-pay=$matches[2]";s:25:"order-received(/(.*))?/?$";s:37:"index.php?&order-received=$matches[2]";s:21:"view-order(/(.*))?/?$";s:33:"index.php?&view-order=$matches[2]";s:23:"edit-account(/(.*))?/?$";s:35:"index.php?&edit-account=$matches[2]";s:23:"edit-address(/(.*))?/?$";s:35:"index.php?&edit-address=$matches[2]";s:24:"lost-password(/(.*))?/?$";s:36:"index.php?&lost-password=$matches[2]";s:26:"customer-logout(/(.*))?/?$";s:38:"index.php?&customer-logout=$matches[2]";s:29:"add-payment-method(/(.*))?/?$";s:41:"index.php?&add-payment-method=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:25:"([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?name=$matches[1]&wc-api=$matches[3]";s:31:"[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (602, '_transient_wc_attribute_taxonomies', 'a:4:{i:0;O:8:"stdClass":5:{s:12:"attribute_id";s:1:"1";s:14:"attribute_name";s:7:"vintage";s:15:"attribute_label";s:7:"Vintage";s:14:"attribute_type";s:6:"select";s:17:"attribute_orderby";s:10:"menu_order";}i:1;O:8:"stdClass":5:{s:12:"attribute_id";s:1:"2";s:14:"attribute_name";s:7:"variety";s:15:"attribute_label";s:7:"Variety";s:14:"attribute_type";s:4:"text";s:17:"attribute_orderby";s:10:"menu_order";}i:2;O:8:"stdClass":5:{s:12:"attribute_id";s:1:"3";s:14:"attribute_name";s:8:"vineyard";s:15:"attribute_label";s:8:"Vineyard";s:14:"attribute_type";s:4:"text";s:17:"attribute_orderby";s:10:"menu_order";}i:3;O:8:"stdClass":5:{s:12:"attribute_id";s:1:"4";s:14:"attribute_name";s:6:"winery";s:15:"attribute_label";s:6:"Winery";s:14:"attribute_type";s:4:"text";s:17:"attribute_orderby";s:10:"menu_order";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (604, 'pa_vineyard_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (605, 'pa_winery_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (617, 'pa_variety_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (629, '_transient_timeout_wc_ship_f6ae3632a3bebf22da7d93ef3c6f8efe', '1414104752', 'no') ; 
INSERT INTO `wp_options` VALUES (630, '_transient_wc_ship_f6ae3632a3bebf22da7d93ef3c6f8efe', 'a:1:{s:13:"free_shipping";O:16:"WC_Shipping_Rate":5:{s:2:"id";s:13:"free_shipping";s:5:"label";s:13:"Free Shipping";s:4:"cost";d:0;s:5:"taxes";a:0:{}s:9:"method_id";s:13:"free_shipping";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (631, '_transient_timeout_wc_ship_3a42a39fc1196f35e22a0904e6e07d83', '1414104771', 'no') ; 
INSERT INTO `wp_options` VALUES (632, '_transient_wc_ship_3a42a39fc1196f35e22a0904e6e07d83', 'a:1:{s:13:"free_shipping";O:16:"WC_Shipping_Rate":5:{s:2:"id";s:13:"free_shipping";s:5:"label";s:13:"Free Shipping";s:4:"cost";d:0;s:5:"taxes";a:0:{}s:9:"method_id";s:13:"free_shipping";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (643, '_transient_timeout_hmbkp_plugin_data', '1414199954', 'no') ; 
INSERT INTO `wp_options` VALUES (644, '_transient_hmbkp_plugin_data', 'O:8:"stdClass":20:{s:4:"name";s:15:"BackUpWordPress";s:4:"slug";s:15:"backupwordpress";s:7:"version";s:5:"2.6.2";s:6:"author";s:47:"<a href="http://hmn.md/">Human Made Limited</a>";s:14:"author_profile";s:32:"//profiles.wordpress.org/willmot";s:12:"contributors";a:7:{s:9:"humanmade";s:34:"//profiles.wordpress.org/humanmade";s:7:"willmot";s:32:"//profiles.wordpress.org/willmot";s:13:"pauldewouters";s:38:"//profiles.wordpress.org/pauldewouters";s:8:"joehoyle";s:33:"//profiles.wordpress.org/joehoyle";s:7:"mattheu";s:32:"//profiles.wordpress.org/mattheu";s:9:"tcrsavage";s:34:"//profiles.wordpress.org/tcrsavage";s:8:"cuvelier";s:0:"";}s:8:"requires";s:5:"3.7.3";s:6:"tested";s:5:"3.9.2";s:13:"compatibility";a:1:{s:3:"4.0";a:1:{s:5:"2.6.2";a:3:{i:0;i:75;i:1;i:8;i:2;i:6;}}}s:6:"rating";d:91.7999999999999971578290569595992565155029296875;s:11:"num_ratings";i:765;s:7:"ratings";a:5:{i:5;i:628;i:4;i:67;i:3;i:13;i:2;i:9;i:1;i:48;}s:10:"downloaded";i:1165841;s:12:"last_updated";s:21:"2014-05-06 2:07pm GMT";s:5:"added";s:10:"2007-09-02";s:8:"homepage";s:18:"http://bwp.hmn.md/";s:8:"sections";a:5:{s:11:"description";s:1433:"<p><a href="https://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">BackUpWordPress</a> will back up your entire site including your database and all your files on a schedule that suits you. Try it now to see how easy it is!</p>

<h4>Features</h4>

<ul>
<li>Super simple to use, no setup required.</li>
<li>Works in low memory, "shared host" environments.</li>
<li>Manage multiple schedules.</li>
<li>Option to have each backup file emailed to you.</li>
<li>Uses <code>zip</code> and <code>mysqldump</code> for faster backups if they are available.</li>
<li>Works on Linux &#38; Windows Server.</li>
<li>Exclude files and folders from your backups.</li>
<li>Good support should you need help.</li>
<li>Translations for Spanish, German, Chinese, Romanian, Russian, Serbian, Lithuanian, Italian, Czech, Dutch, French, Basque.</li>
</ul>

<h4>Help develop this plugin</h4>

<p>The BackUpWordPress plugin is hosted on GitHub, if you want to help out with development or testing then head over to <a href="https://github.com/humanmade/backupwordpress/" rel="nofollow">https://github.com/humanmade/backupwordpress/</a>.</p>

<h4>Translations</h4>

<p>We\'d also love help translating the plugin into more languages, if you can help then please contact <a href="mailto:support@hmn.md">support@hmn.md</a> or visit <a href="http://translate.hmn.md/" rel="nofollow">http://translate.hmn.md/</a>.</p>";s:12:"installation";s:460:"<ol>
<li>Install BackUpWordPress either via the WordPress.org plugin directory, or by uploading the files to your server.</li>
<li>Activate the plugin.</li>
<li>Sit back and relax safe in the knowledge that your whole site will be backed up every day.</li>
</ol>

<p>The plugin will try to use the <code>mysqldump</code> and <code>zip</code> commands via shell if they are available, using these will greatly improve the time it takes to back up your site.</p>";s:11:"screenshots";s:1083:"<ol>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=904756\' title=\'Click to view full-size screenshot 1\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=904756\' alt=\'backupwordpress screenshot 1\' />
		</a>		<p>Manage multiple schedules.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=904756\' title=\'Click to view full-size screenshot 2\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=904756\' alt=\'backupwordpress screenshot 2\' />
		</a>		<p>Choose your schedule, backup type, number of backups to keep and whether to recieve a notification email.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=904756\' title=\'Click to view full-size screenshot 3\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=904756\' alt=\'backupwordpress screenshot 3\' />
		</a>		<p>Easily manage exclude rules and see exactly which files are included and excluded from your backup.</p>
	</li>
</ol>";s:9:"changelog";s:32377:"<h4>2.6.2</h4>

<ul>
<li>Reverts a change to how the home path is calculated as it caused issues on installs where wp-config.php was stored outside of web root. Props to @mikelittle for the bug report.</li>
</ul>

<h4>2.6.1</h4>

<ul>
<li>Bump minimum WP requirement to 3.7.3, the latest security release on the 3.7 branch.</li>
<li>Fix an issues that could cause schedule times to fail to account for timezone differences.</li>
<li>Add a nonce check to the schedule settings.</li>
<li>Fix a possible JS warning when removing an exclude rule.</li>
<li>Our unit tests now run in PHP 5.2 again.</li>
</ul>

<h4>2.6</h4>

<ul>
<li>It\'s now possible to choose the time and day that your schedule will run on.</li>
<li>Introduces several new unit tests around schedule timings.</li>
<li>Fixes a bug that could cause the hourly schedule to run constantly.</li>
<li>Improved the layout of the Constants help panel.</li>
<li>If the backup root directory is unreadable then the plugin will no longer function.</li>
<li>Update the backups table match the standard WordPress table styles.</li>
<li>Improved styling for the settings dialogue.</li>
<li>Improved styling for the Server Info help tab.</li>
<li>/s/back ups/backups.</li>
<li>Remove Deprecated call to <code>screen_icon</code>.</li>
<li>Updated French translation.</li>
<li>Update the <code>WP CLI</code> command to use the new method for registering command.</li>
<li>Reload the schedules when re-setting up the default schedules so they show up straight away.</li>
<li>s/dpesnt\'t/doesn\'t.</li>
<li>Only show the estimated total schedule size when editing an existing schedule.</li>
<li>Stop stripping 0 from the minutes on hourly backups so that backups at 10 (&#38; 20, etc.) past the hour correctly show.</li>
<li>Disable buttons whilst ajax requests are running.</li>
<li>Move spinners outside the buttons as they didn\'t look very good inside.</li>
<li>Improve the detection of the home path on multisite installs which have WordPress in a subdirectory.</li>
<li>Track the time that the running backup is started and display how long a backup has been running for.</li>
<li>Fix an issue that meant it wasn\'t possible to run multiple manual backups at the same time.</li>
<li>Many other minor improvements.</li>
</ul>

<h4>2.5</h4>

<ul>
<li>BackUpWordPress now requires WordPress 3.7.1 as a minimum.</li>
<li>Remove some old back-compat code that was required because we supported older WP versions.</li>
<li>It\'s now possible to change the email address that notification emails are sent from using the <code>hmbkp_from_email</code> filter.</li>
<li>The spinner is now retina!</li>
<li>Close the PHP Session before starting the backup process to work around the 1 request per session issue. Backup status will now work on sites which happen to call <code>session_start</code>.</li>
<li>Pass <code>max_execution_time</code> and the BackUpWordPress Plugin version back to support. * Include the users real name in support requests</li>
<li>Stop passing <code>$_SERVER</code> with support requests as it can contain things like <code>.htaccess</code> passwords on some server configurations.</li>
<li>Improve the display of the server info in the enable support popup.</li>
<li>New screenshots</li>
<li>Use <code>wp_safe_redirect</code> for internal redirects.</li>
<li>Use <code>wp_is_writable</code> instead of <code>is_writable</code>.</li>
</ul>

<h4>2.4.2</h4>

<ul>
<li>In WordPress Multisite the backups admin page is now located in Network admin instead of the wp-admin of the main site.</li>
<li>Fixed an issue with the new intercom support integration that could cause loading the backups page to timeout</li>
<li>Fixed 3 stray PHP warnings.</li>
<li>BackUpWordPress will now always be loaded before any BackUpWordPress Extensions.</li>
<li>Fixed an issue that could cause a long modal (excludes) to show underneath the WP admin bar.</li>
</ul>

<h4>2.4.1</h4>

<ul>
<li>Add missing colorbox images</li>
</ul>

<h4>2.4</h4>

<ul>
<li>Support for new premium extensions for storing backups in a variety of online services.</li>
<li>Exclude the WP DB Manager backups and WP Super Cache cache directories by default.</li>
<li>We now use Intercom to offer support directly from within the plugin, opt-in of course.</li>
<li>More i18n fixes / improvements.</li>
<li>We no longer show download links if your backups directory isn\'t web accessible.</li>
<li>Fix a bug that caused the plugin activation and deactivation hooks from firing.</li>
<li>Correctly handle <code>MYSQL TIMESTAMP</code> columns in database dumps.</li>
<li><code>mysqldump</code> and <code>zip</code> are now correctly recognised on SmartOS.</li>
<li>Schedule names are now translatable.</li>
<li>Avoid having to re-calculate the filesize when a schedules type is set.</li>
<li>Compatibility with WordPress 3.8</li>
</ul>

<h4>2.3.2</h4>

<ul>
<li>Correct version number.</li>
</ul>

<h4>2.3.1</h4>

<ul>
<li>Fix a PHP strict error.</li>
<li>Save and close as separate buttons.</li>
<li>Fix bug that caused multiple notification emails.</li>
<li>Fixes typo in database option name.</li>
<li>Updated translations.</li>
<li>Improve PHP docblocks.</li>
<li>Make schedules class a singleton.</li>
<li>Exclude popular backup plugin folders by default.</li>
<li>Exclude version control folders by default.</li>
<li>Fix broken localisation.</li>
<li>Use <code>wp_safe_redirect</code> instead of <code>wp_redirect</code> for internal form submissions</li>
<li></li>
</ul>

<h4>2.3</h4>

<ul>
<li>Replace Fancybox with Colorbox as Fancybox 2 isn\'t GPL compatible.</li>
<li>Use the correct <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant consistently in the help section.</li>
<li>Correct filename for some mis-named translation files.</li>
<li>Show the total estimated disk space a schedule could take up (max backups * estimated site size).</li>
<li>Fix a typo (your -&#62; you\'re).</li>
<li>Use the new time Constants and define backwords compatible ones for &#62; than 3.5.</li>
<li>Play nice with custom cron intervals.</li>
<li>Main plugin file is now <code>backupwordpress.php</code> for consistency.</li>
<li>Add Paul De Wouters (<code>pauldewouters</code>) as a contributor, welcome Paul!</li>
<li>Don\'t remove non-backup files from custom backup paths.</li>
<li>Fix a regression where setting a custom path which didn\'t exist could cause you to lose existing backups.</li>
<li>When moving paths only move backup files.</li>
<li>Make some untranslatable strings translatable.</li>
<li>Don\'t allow a single schedule to run in multiple threads at once, should finally fix edge case issues where some load balancer / proxies were causing multiple backups per run.</li>
<li>Only highlight the <code>HMBKP_SCHEDULE_TIME</code> constant in help if it\'s not the default value.</li>
<li>Remove help text for deprecated <code>HMBKP_EMAIL</code>.</li>
<li>Default to allways specificing <code>--single-transaction</code> when using <code>mysqldump</code> to backup the database, can be disabled by setting the <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code> to <code>false</code>.</li>
<li>Silence a <code>PHP Warning</code> if <code>mysql_pconnect</code> has been disabled.</li>
<li>Ensure dot directories <code>.</code> &#38; <code>..</code> are always skipped when looping the filesystem.</li>
<li>Work around a warning in the latest version of MySQL when using the <code>-p</code> flag with <code>mysqldunmp</code>.</li>
<li>Fix issues on IIS that could cause the root directory to be incorrectly calculated.</li>
<li>Fix an issue on IIS that could cause the download backup url to be incorrect.</li>
<li>Fix an issue on IIS that could mean your existing backups are lost when moving backup directory.</li>
<li>Avoid a <code>PHP FATAL ERROR</code> if the <code>mysql_set_charset</code> doesn\'t exist.</li>
<li>All unit tests now pass under IIS on Windows.</li>
<li>Prefix the backup directory with <code>backupwordpress-</code> so that it\'s easier to identify.</li>
<li>Re-calculate the backup directory name on plugin update and move backups.</li>
<li>Fix some issues with how <code>HMBKP_SECURE_KEY</code> was generated.</li>
</ul>

<h4>2.2.4</h4>

<ul>
<li>Fix a fatal error on PHP 5.2, sorry! (again.)</li>
</ul>

<h4>2.2.3</h4>

<ul>
<li>Fix a parse error, sorry!</li>
</ul>

<h4>2.2.2</h4>

<ul>
<li>Fix a fatal error when uninstalling.</li>
<li>Updated translations for Brazilian, French, Danish, Spanish, Czech, Slovakian, Polish, Italian, German, Latvian, Hebrew, Chinese &#38; Dutch.</li>
<li>Fix a possible notice when using the plugin on a server without internet access.</li>
<li>Don\'t show the wp-cron error message when <code>WP_USE_ALTERNATE_CRON</code> is defined as true.</li>
<li>Ability to override the max attachment size for email notifications using the new <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant.</li>
<li>Nonce some ajax request.</li>
<li>Silence warnings created if <code>is_executable</code>, <code>escapeshellcmd</code> or <code>escapeshellarg</code> are disabled.</li>
<li>Handle situations where the mysql port is set to something wierd.</li>
<li>Fallback to <code>mysql_connect</code> on system that disable <code>mysql_pconnect</code>.</li>
<li>You can now force the <code>--single-transaction</code> param when using <code>mysqldump</code> by defining <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code>.</li>
<li>Unit tests for <code>HM_Backup::is_safe_mode_available()</code>.</li>
<li>Silence possible PHP Warnings when unlinking files.</li>
</ul>

<h4>2.2.1</h4>

<ul>
<li>Stop storing a list of unreadable files in the backup warnings as it\'s too memory intensive.</li>
<li>Revert the custom <code>RecursiveDirectoryIterator</code> as it caused an infinite loop on some servers.</li>
<li>Show all errors and warnings in the popup shown when a manual backup completes.</li>
<li>Write the .backup_error and .backup_warning files everytime an error or warning happens instead of waiting until the end of the backups process.</li>
<li>Fix a couple of <code>PHP E_STRICT</code> notices.</li>
<li>Catch more errors during the manual backup process and expose them to the user.</li>
</ul>

<h4>2.2</h4>

<ul>
<li>Don\'t repeatedly try to create the backups directory in the <code>uploads</code> if <code>uploads</code> isn\'t writable.</li>
<li>Show the correct path in the warning message when the backups path can\'t be created.</li>
<li>Include any user defined auth keys and salts when generating the HMBKP_SECURE_KEY.</li>
<li>Stop relying on the built in WordPress schedules as other plugins can mess with them.</li>
<li>Delete old backups everytime the backups page is viewed in an attempt to ensure old backups are always cleaned up.</li>
<li>Improve modals on small screens and mobile devices.</li>
<li>Use the retina spinner on retina screens.</li>
<li>Update buttons to the new 3.5 style.</li>
<li>Fix a possible fatal error caused when a symlink points to a location that is outside an <code>open_basedir</code> restriction.</li>
<li>Fix an issue that could cause backups using PclZip with a custom backups path to fail.</li>
<li>Security hardening by improving escaping, sanitizitation and validation.</li>
<li>Increase the timeout on the ajax cron check, should fix issues with cron errors showing on slow sites.</li>
<li>Only clear the cached backup filesize if the backup type changes.</li>
<li>Add unit tests for all the schedule recurrences.</li>
<li>Fix an issue which could cause weekly and monthly schedules to fail.</li>
<li>Add an <code>uninstall.php</code> file which removes all BackUpWordPress data and options.</li>
<li>Catch a possible fatal error in <code>RecursiveDirectoryIterator::hasChildren</code>.</li>
<li>Fix an issue that could cause mysqldump errors to be ignored thus causing the backup process to use an incomplete mysqldump file.</li>
</ul>

<h4>2.1.3</h4>

<ul>
<li>Fix a regression in <code>2.1.2</code> that broke previewing and adding new exclude rules.</li>
</ul>

<h4>2.1.2</h4>

<ul>
<li>Fix an issue that could stop the settings panel from closing on save on servers which return <code>\'0\'</code> for ajax requests.</li>
<li>Fix an issue that could cause the backup root to be set to <code>/</code> on sites with <code>site_url</code> and <code>home</code> set to different domains.</li>
<li>The mysqldump fallback function will now be used if <code>mysqldump</code> produces an empty file.</li>
<li>Fix a possible PHP <code>NOTICE</code> on Apache servers.</li>
</ul>

<h4>2.1.1</h4>

<ul>
<li>Fix a possible fatal error when a backup schedule is instantiated outside of wp-admin.</li>
<li>Don\'t use functions from misc.php as loading it too early can cause fatal errors.</li>
<li>Don\'t hardcode an English string in the JS, use the translated string instead.</li>
<li>Properly skip dot files, should fix fatal errors on systems with <code>open_basedir</code> restrictions.</li>
<li>Don\'t call <code>apache_mod_loaded</code> as it caused wierd DNS issue on some sites, use <code>global $is_apache</code> instead.</li>
<li>Fix a possible double full stop at the end of the schedule sentence.</li>
<li>Minor code cleanup.</li>
</ul>

<h4>2.1</h4>

<ul>
<li>Stop blocking people with <code>safe_mode = On</code> from using the plugin, instead just show a warning.</li>
<li>Fix possible fatal error when setting schedule to monthly.</li>
<li>Fix issues with download backup not working on some shared hosts.</li>
<li>Fix issuses with download backup not working on sites with strange characters in the site name.</li>
<li>Fix a bug could cause the update actions to fire on initial activation.</li>
<li>Improved reliability when changing backup paths, now with Unit Tests.</li>
<li>Generate the lists of excluded, included and unreadable files in a more memory efficient way, no more fatal errors on sites with lots of files.</li>
<li>Bring back .htaccess protection of the backups directory on <code>Apache</code> servers with <code>mod_rewrite</code> enabled.</li>
<li>Prepend a random string to the backups directory to make it harder to brute force guess.</li>
<li>Fall back to storing the backups directoy in <code>uploads</code> if <code>WP_CONTENT_DIR</code> isn\'t writable.</li>
<li>Attempt to catch <code>E_ERROR</code> level errors (Fatal errors) that happen during the backup process and offer to email them to support.</li>
<li>Provide more granular status messages during the backup process.</li>
<li>Show a spinner next to the schedule link when a backup is running on a schedule which you are not currently viewing.</li>
<li>Improve the feedback when removing an exclude rule.</li>
<li>Fix an issue that could cause an exclude rule to be marked as default when it in-fact isn\'t, thus not letting it be deleted.</li>
<li>Add a line encouraging people to rate the plugin if they like it.</li>
<li>Change the support line to point to the FAQ before recommending they contact support.</li>
<li>Fix the link to the "How to Restore" post in the FAQ.</li>
<li>Some string changes for translators, 18 changed strings.</li>
</ul>

<h4>2.0.6</h4>

<ul>
<li>Fix possible warning on plugin activation if the sites cron option is empty.</li>
<li>Don\'t show the version warning in the help for Constants as that comes from the current version.</li>
</ul>

<h4>2.0.5</h4>

<ul>
<li>Re-setup the cron schedules if they get deleted somehow.</li>
<li>Delete all BackUpWordPress cron entries when the plugin is deactivated.</li>
<li>Introduce the <code>HMBKP_SCHEDULE_TIME</code> constant to allow control over the time schedules run.</li>
<li>Make sure the schedule times and times of previous backups are shown in local time.</li>
<li>Fix a bug that could cause the legacy backup schedule to be created on every update, not just when going from 1.x to 2.x.</li>
<li>Improve the usefulness of the <code>wp-cron.php</code> response code check.</li>
<li>Use the built in <code>site_format</code> function for human readable filesizes instead of defining our own function.</li>
</ul>

<h4>2.0.4</h4>

<ul>
<li>Revert the change to the way the plugin url and path were calculated as it caused regressions on some systems.</li>
</ul>

<h4>2.0.3</h4>

<ul>
<li>Fix issues with scheduled backups not firing in some cases.</li>
<li>Better compatibility when the WP Remote plugin is active alongside BackUpWordPress.</li>
<li>Catch and display more WP Cron errors.</li>
<li>BackUpWordPress now fails to activate on WordPress 3.3.2 and below.</li>
<li>Other minor fixes and improvements.</li>
</ul>

<h4>2.0.2</h4>

<ul>
<li>Only send backup failed emails if the backup actually failed.</li>
<li>Turn off the generic "memory limit probably hit" message as it was showing for too many people.</li>
<li>Fix a possible notice when the backup running filename is blank.</li>
<li>Include the <code>wp_error</code> response in the cron check.</li>
</ul>

<h4>2.0.1</h4>

<ul>
<li>Fix fatal error on PHP 5.2.</li>
</ul>

<h4>2.0</h4>

<ul>
<li>Ability to have multiple schedules with separate settings &#38; excludes per schedule.</li>
<li>Ability to manage exclude rules and see exactly which files are included and excluded.</li>
<li>Fix an issue with sites with an <code>open_basedir</code> restriction.</li>
<li>Backups should now be much more reliable in low memory environments.</li>
<li>Lots of other minor improvements and bug fixes.</li>
</ul>

<h4>1.6.9</h4>

<ul>
<li>Updated and improved translations across the board - props @elektronikLexikon.</li>
<li>German translation - props @elektronikLexikon.</li>
<li>New Basque translation - props Unai ZC.</li>
<li>New Dutch translation - Anno De Vries.</li>
<li>New Italian translation.</li>
<li>Better support for when WordPress is installed in a sub directory - props @mattheu</li>
</ul>

<h4>1.6.8</h4>

<ul>
<li>French translation props Christophe - <a href="http://catarina.fr" rel="nofollow">http://catarina.fr</a>.</li>
<li>Updated Spanish Translation props DD666 - <a href="https://github.com/radinamatic" rel="nofollow">https://github.com/radinamatic</a>.</li>
<li>Serbian translation props StefanRistic - <a href="https://github.com/StefanRistic" rel="nofollow">https://github.com/StefanRistic</a>.</li>
<li>Lithuanian translation props Vincent G - <a href="http://www.Host1Free.com" rel="nofollow">http://www.Host1Free.com</a>.</li>
<li>Romanian translation.</li>
<li>Fix conflict with WP Remote.</li>
<li>Fix a minor issue where invalid email address\'s were still stored.</li>
<li>The root path that is backed up can now be controlled by defining <code>HMBKP_ROOT</code>.</li>
</ul>

<h4>1.6.7</h4>

<ul>
<li>Fix issue with backups being listed in reverse chronological order.</li>
<li>Fix issue with newest backup being deleted when you hit your max backups limit.</li>
<li>It\'s now possible to have backups sent to multiple email address\'s by entering them as a comma separated list.</li>
<li>Fix a bug which broke the ability to override the <code>mysqldump</code> path with <code>HMBKP_MYSQLDUMP_PATH</code>.</li>
<li>Use <code>echo</code> rather than <code>pwd</code> when testing <code>shell_exec</code> as it\'s supported cross platform.</li>
<li>Updated Spanish translation.</li>
<li>Fix a minor spelling mistake.</li>
<li>Speed up the manage backups page by caching the FAQ data for 24 hours.</li>
</ul>

<h4>1.6.6</h4>

<ul>
<li>Fix backup path issue with case sensitive filesystems.</li>
</ul>

<h4>1.6.5</h4>

<ul>
<li>Fix an issue with emailing backups that could cause the backup file to not be attached.</li>
<li>Fix an issue that could cause the backup to be marked as running for ever if emailing the backup <code>FATAL</code> error\'d.</li>
<li>Never show the running backup in the list of backups.</li>
<li>Show an error backup email failed to send.</li>
<li>Fix possible notice when deleting a backup file which doesn\'t exist.</li>
<li>Fix possible notice on older versions of <code>PHP</code> which don\'t define <code>E_DEPRECATED</code>.</li>
<li>Make <code>HMBKP_SECURE_KEY</code> override-able.</li>
<li>BackUpWordPress should now work when <code>ABSPATH</code> is <code>/</code>.</li>
</ul>

<h4>1.6.4</h4>

<ul>
<li>Don\'t show warning message as they cause to much panic.</li>
<li>Move previous methods errors to warnings in fallback methods.</li>
<li>Wrap <code>.htaccess</code> rewrite rules in if <code>mod_rewrite</code> check.</li>
<li>Add link to new restore help article to FAQ.</li>
<li>Fix issue that could cause "not using latest stable version" message to show when you were in-fact using the latest version.</li>
<li>Bug fix in <code>zip command</code> check that could cause an incorrect <code>zip</code> path to be used.</li>
<li>Detect and pass <code>MySQL</code> port to <code>mysqldump</code>.</li>
</ul>

<h4>1.6.3</h4>

<ul>
<li>Don\'t fail archive verification for errors in previous archive methods.</li>
<li>Improved detection of the <code>zip</code> and <code>mysqldump</code> commands.</li>
<li>Fix issues when <code>ABSPATH</code> is <code>/</code>.</li>
<li>Remove reliance on <code>SECURE_AUTH_KEY</code> as it\'s often not defined.</li>
<li>Use <code>warning()</code> not <code>error()</code> for issues reported by <code>zip</code>, <code>ZipArchive</code> &#38; <code>PclZip</code>.</li>
<li>Fix download zip on Windows when <code>ABSPATH</code> contains a trailing forward slash.</li>
<li>Send backup email after backup completes so that fatal errors in email code don\'t stop the backup from completing.</li>
<li>Add missing / to <code>PCLZIP_TEMPORARY_DIR</code> define.</li>
<li>Catch and display errors during <code>mysqldump</code>.</li>
</ul>

<h4>1.6.2</h4>

<ul>
<li>Track <code>PHP</code> errors as backup warnings not errors.</li>
<li>Only show warning message for <code>PHP</code> errors in BackUpWordPress files.</li>
<li>Ability to dismiss the error / warning messages.</li>
<li>Disable use of <code>PclZip</code> for full archive checking for now as it causes memory issues on some large sites.</li>
<li>Don\'t delete "number of backups" setting on update.</li>
<li>Better handling of multibyte characters in archive and database dump filenames.</li>
<li>Mark backup as running and increase callback timeout to <code>500</code> when firing backup via ajax.</li>
<li>Don\'t send backup email if backup failed.</li>
<li>Filter out duplicate exclude rules.</li>
</ul>

<h4>1.6.1</h4>

<ul>
<li>Fix fatal error on PHP =&#60; 5.3</li>
</ul>

<h4>1.6</h4>

<ul>
<li>Fixes issue with backups dir being included in backups on some Windows Servers.</li>
<li>Consistent handling of symlinks across all archive methods (they are followed).</li>
<li>Use .htaccess rewrite cond authentication to allow for secure http downloads of backup files.</li>
<li>Track errors and warnings that happen during backup and expose them through admin.</li>
<li>Fire manual backups using ajax instead of wp-cron, <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> is no longer needed and has been removed.</li>
<li>Ability to cancel a running backup.</li>
<li>Zip files are now integrity checked after every backup.</li>
<li>More robust handling of failed / corrupt zips, backup process now fallsback through the various zip methods until one works.</li>
<li>Use <code>mysql_query</code> instead of the depreciated <code>mysql_list_tables</code>.</li>
</ul>

<h4>1.5.2</h4>

<ul>
<li>Better handling of unreadable files in ZipArchive and the backup size calculation.</li>
<li>Support for wp-cli, usage: <code>wp backup [--files_only] [--database_only] [--path&#60;dir&#62;] [--root&#60;dir&#62;] [--zip_command_path=&#60;path&#62;] [--mysqldump_command_path=&#60;path&#62;]</code></li>
</ul>

<h4>1.5.1</h4>

<ul>
<li>Better detection of <code>zip</code> command.</li>
<li>Don\'t delete user settings on update / deactivate.</li>
<li>Use <code>ZipArchive</code> if <code>zip</code> is not available, still falls back to <code>PclZip</code> if neither <code>zip</code> nor <code>ZipArchive</code> are installed.</li>
<li>Better exclude rule parsing, fixes lots of edge cases, excludes now pass all 52 unit tests.</li>
<li>Improved the speed of the backup size calculation.</li>
</ul>

<h4>1.5</h4>

<ul>
<li>Re-written core backup engine should be more robust especially in edge case scenarios.</li>
<li>48 unit tests for the core backup engine, yay for unit tests.</li>
<li>Remove some extraneous status information from the admin interface.</li>
<li>Rename Advanced Options to Settings</li>
<li>New <code>Constant</code> <code>HMBKP_CAPABILITY</code> to allow the default <code>add_menu_page</code> capability to be changed.</li>
<li>Suppress possible filemtime warnings in some edge cases.</li>
<li>3.3 compatability.</li>
<li>Set proper charset of MySQL backup, props valericus.</li>
<li>Fix some inconsistencies between the estimated backup size and actual backup size when excluding files.</li>
</ul>

<h4>1.4.1</h4>

<ul>
<li>1.4 was incorrectly marked as beta.</li>
</ul>

<h4>1.4</h4>

<ul>
<li>Most options can now be set on the backups page, all options can still be set by defining them as <code>Constants</code>.</li>
<li>Russian translation, props valericus.</li>
<li>All dates are now translatable.</li>
<li>Fixed some strings which weren\'t translatable.</li>
<li>New Constant <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> which enable you to disable the use of <code>wp_cron</code> for manual backups.</li>
<li>Manual backups now work if <code>DISABLE_WP_CRON</code> is defined as <code>true</code>.</li>
</ul>

<h4>1.3.2</h4>

<ul>
<li>Spanish translation</li>
<li>Bump PHP version check to 5.2.4</li>
<li>Fallback to PHP mysqldump if shell_exec fails for any reason.</li>
<li>Silently ignore unreadable files / folders</li>
<li>Make sure binary data is properly exported when doing a mysqldump</li>
<li>Use 303 instead of 302 when redirecting in the admin.</li>
<li>Don\'t <code>set_time_limit</code> inside a loop</li>
<li>Use WordPress 3.2 style buttons</li>
<li>Don\'t pass an empty password to mysqldump</li>
</ul>

<h4>1.3.1</h4>

<ul>
<li>Check for PHP version. Deactivate plugin if running on PHP version 4.</li>
</ul>

<h4>1.3</h4>

<ul>
<li>Re-written back up engine, no longer copies everything to a tmp folder before zipping which should improve speed and reliability.</li>
<li>Support for excluding files and folders, define <code>HMBKP_EXCLUDE</code> with a comma separated list of files and folders to exclude, supports wildcards <code>*</code>, path fragments and absolute paths.</li>
<li>Full support for moving the backups directory, if you define a new backups directory then your existing backups will be moved to it.</li>
<li>Work around issues caused by low MySQL <code>wait_timeout</code> setting.</li>
<li>Add FAQ to readme.txt.</li>
<li>Pull FAQ into the contextual help tab on the backups page.</li>
<li>Block activation on old versions of WordPress.</li>
<li>Stop guessing compressed backup file size, instead just show size of site uncompressed.</li>
<li>Fix bug in <code>safe_mode</code> detection which could cause <code>Off</code> to act like <code>On</code>.</li>
<li>Better name for the database dump file.</li>
<li>Better name for the backup files.</li>
<li>Improve styling for advanced options.</li>
<li>Show examples for all advanced options.</li>
<li>Language improvements.</li>
<li>Layout tweaks.</li>
</ul>

<h4>1.2</h4>

<ul>
<li>Show live backup status in the back up now button when a back up is running.</li>
<li>Show free disk space after total used by backups.</li>
<li>Several langauge changes.</li>
<li>Work around the 1 cron every 60 seconds limit.</li>
<li>Store backup status in a 2 hour transient as a last ditch attempt to work around the "stuck on backup running" issue.</li>
<li>Show a warning and disable backups when PHP is in Safe Mode, may try to work round issues and re-enable in the future.</li>
<li>Highlight defined <code>Constants</code>.</li>
<li>Show defaults for all <code>Constants</code>.</li>
<li>Show a warning if both <code>HMBKP_FILES_ONLY</code> and <code>HMBKP_DATABASE_ONLY</code> are defined at the same time.</li>
<li>Make sure options added in 1.1.4 are cleared on de-activate.</li>
<li>Support <code>mysqldump on</code> Windows if it\'s available.</li>
<li>New option to have each backup emailed to you on completion. Props @matheu for the contribution.</li>
<li>Improved windows server support.</li>
</ul>

<h4>1.1.4</h4>

<ul>
<li>Fix a rare issue where database backups could fail when using the mysqldump PHP fallback if <code>mysql.max_links</code> is set to 2 or less.</li>
<li>Don\'t suppress <code>mysql_connect</code> errors in the mysqldump PHP fallback.</li>
<li>One time highlight of the most recent completed backup when viewing the manage backups page after a successful backup.</li>
<li>Fix a spelling error in the <code>shell_exec</code> disabled message.</li>
<li>Store the BackUpWordPress version as a <code>Constant</code> rather than a <code>Variable</code>.</li>
<li>Don\'t <code>(float)</code> the BackUpWordPress version number, fixes issues with minor versions numbers being truncated.</li>
<li>Minor PHPDoc improvements.</li>
</ul>

<h4>1.1.3</h4>

<ul>
<li>Attempt to re-connect if database connection hits a timeout while a backup is running, should fix issues with the "Back Up Now" button continuing to spin even though the backup is completed.</li>
<li>When using <code>PCLZIP</code> as the zip fallback don\'t store the files with absolute paths. Should fix issues unzipping the file archives using "Compressed (zipped) Folders" on Windows XP.</li>
</ul>

<h4>1.1.2</h4>

<ul>
<li>Fix a bug that stopped <code>HMBKP_DISABLE_AUTOMATIC_BACKUP</code> from working.</li>
</ul>

<h4>1.1.1</h4>

<ul>
<li>Fix a possible <code>max_execution_timeout</code> fatal error when attempting to calculate the path to <code>mysqldump</code>.</li>
<li>Clear the running backup status and reset the calculated filesize on update.</li>
<li>Show a link to the manage backups page in the plugin description.</li>
<li>Other general fixes.</li>
</ul>

<h4>1.1</h4>

<ul>
<li>Remove the logging facility as it provided little benefit and complicated the code, your existing logs will be deleted on update.</li>
<li>Expose the various <code>Constants</code> that can be defined to change advanced settings.</li>
<li>Added the ability to disable the automatic backups completely <code>define( \'HMBKP_DISABLE_AUTOMATIC_BACKUP\', true );</code>.</li>
<li>Added the ability to switch to file only or database only backups <code>define( \'HMBKP_FILES_ONLY\', true );</code> Or <code>define( \'HMBKP_DATABASE_ONLY\', true );</code>.</li>
<li>Added the ability to define how many old backups should be kept <code>define( \'HMBKP_MAX_BACKUPS\', 20 );</code></li>
<li>Added the ability to define the time that the daily backup should run <code>define( \'HMBKP_DAILY_SCHEDULE_TIME\', \'16:30\' );</code></li>
<li>Tweaks to the backups page layout.</li>
<li>General bug fixes and improvements.</li>
</ul>

<h4>1.0.5</h4>

<ul>
<li>Don\'t ajax load estimated backup size if it\'s already been calculated.</li>
<li>Fix time in backup complete log message.</li>
<li>Don\'t mark backup as running until cron has been called, will fix issues with backup showing as running even if cron never fired.</li>
<li>Show number of backups saved message.</li>
<li>Add a link to the backups page to the plugin action links.</li>
</ul>

<h4>1.0.4</h4>

<p>Don\'t throw PHP Warnings when <code>shell_exec</code> is disabled</p>

<h4>1.0.3</h4>

<p>Minor bug fix release.</p>

<ul>
<li>Suppress <code>filesize()</code> warnings when calculating backup size.</li>
<li>Plugin should now work when symlinked.</li>
<li>Remove all options on deactivate, you should now be able to deactivate then activate to fix issues with settings etc. becoming corrupt.</li>
<li>Call setup_defaults for users who update from backupwordpress 0.4.5 so they get new settings.</li>
<li>Don\'t ajax ping running backup status quite so often.</li>
</ul>

<h4>1.0.1 &#38; 1.0.2</h4>

<p>Fix some silly 1.0 bugs</p>

<h4>1.0</h4>

<p>1.0 represents a total rewrite &#38; rethink of the BackUpWordPress plugin with a focus on making it "Just Work". The management and development of the plugin has been taken over by <a href="http://hmn.md">Human Made Limited</a> the chaps behind <a href="https://wpremote.com">WP Remote</a></p>

<h4>Previous</h4>

<p>Version 0.4.5 and previous were developed by <a href="http://profiles.wordpress.org/users/wpdprx/">wpdprx</a></p>";s:3:"faq";s:4410:"<p><strong>Where does BackUpWordPress store the backup files?</strong></p>

<p>Backups are stored on your server in <code>/wp-content/backups</code>, you can change the directory.</p>

<p><strong>Important:</strong> By default BackUpWordPress backs up everything in your site root as well as your database, this includes any non WordPress folders that happen to be in your site root. This does means that your backup directory can get quite large.</p>

<p><strong>What if I want I want to back up my site to another destination?</strong></p>

<p>BackUpWordPress Pro supports Dropbox, Google Drive, Amazon S3, Rackspace, Azure, DreamObjects and FTP/SFTP. Check it out here: <a href="http://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">https://bwp.hmn.md</a></p>

<p><strong>How do I restore my site from a backup?</strong></p>

<p>You need to download the latest backup file either by clicking download on the backups page or via <code>FTP</code>. <code>Unzip</code> the files and upload all the files to your server overwriting your site. You can then import the database using your hosts database management tool (likely <code>phpMyAdmin</code>).</p>

<p>See this post for more details <a href="http://hmn.md/backupwordpress-how-to-restore-from-backup-files/" rel="nofollow">http://hmn.md/backupwordpress-how-to-restore-from-backup-files/</a>.</p>

<p><strong>Does BackUpWordPress back up the backups directory?</strong></p>

<p>No.</p>

<p><strong>I\'m not receiving my backups by email</strong></p>

<p>Most servers have a filesize limit on email attachments, it\'s generally about 10mb. If your backup file is over that limit it won\'t be sent attached to the email, instead you should receive an email with a link to download the backup, if you aren\'t even receiving that then you likely have a mail issue on your server that you\'ll need to contact your host about.</p>

<p><strong>How many backups are stored by default?</strong></p>

<p>BackUpWordPress stores the last 10 backups by default.</p>

<p><strong>How long should a backup take?</strong></p>

<p>Unless your site is very large (many gigabytes) it should only take a few minutes to perform a back up, if your back up has been running for longer than an hour it\'s safe to assume that something has gone wrong, try de-activating and re-activating the plugin, if it keeps happening, contact support.</p>

<p><strong>What do I do if I get the wp-cron error message</strong></p>

<p>The issue is that your <code>wp-cron.php</code> is not returning a <code>200</code> response when hit with a http request originating from your own server, it could be several things, most of the time it\'s an issue with the server / site and not with BackUpWordPress.</p>

<p>Some things you can test are.</p>

<ul>
<li>Are scheduled posts working? (They use wp-cron too).</li>
<li>Are you hosted on Heart Internet? (wp-cron is known not to work with them).</li>
<li>If you click manual backup does it work?</li>
<li>Try adding <code>define( \'ALTERNATE_WP_CRON\', true ); to your</code>wp-config.php`, do automatic backups work?</li>
<li>Is your site private (I.E. is it behind some kind of authentication, maintenance plugin, .htaccess) if so wp-cron won\'t work until you remove it, if you are and you temporarily remove the authentication, do backups start working?</li>
</ul>

<p>If you have tried all these then feel free to contact support.</p>

<p><strong>How to get BackUpWordPress working in Heart Internet</strong></p>

<p>The script to be entered into the Heart Internet cPanel is: <code>/usr/bin/php5 /home/sites/yourdomain.com/public_html/wp-cron.php</code> (note the space between php5 and the location of the file). The file <code>wp-cron.php</code> <code>chmod</code> must be set to <code>711</code>.</p>

<p><strong>Further Support &#38; Feedback</strong></p>

<p>General support questions should be posted in the <a href="http://wordpress.org/tags/backupwordpress?forum_id=10">WordPress support forums, tagged with backupwordpress.</a></p>

<p>For development issues, feature requests or anybody wishing to help out with development checkout <a href="https://github.com/humanmade/backupwordpress/">BackUpWordPress on GitHub.</a></p>

<p>You can also tweet <a href="http://twitter.com/humanmadeltd">@humanmadeltd</a> or email <a href="mailto:support@hmn.md">support@hmn.md</a> for further help/support.</p>";}s:13:"download_link";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.2.6.2.zip";s:4:"tags";a:10:{s:7:"archive";s:7:"archive";s:7:"back-up";s:7:"back up";s:6:"backup";s:6:"backup";s:7:"backups";s:7:"backups";s:8:"database";s:8:"database";s:2:"db";s:2:"db";s:5:"files";s:5:"files";s:9:"humanmade";s:9:"humanmade";s:6:"wp-cli";s:6:"wp-cli";s:3:"zip";s:3:"zip";}s:11:"donate_link";N;}', 'no') ; 
INSERT INTO `wp_options` VALUES (673, '_transient_doing_cron', '1414397646.5722959041595458984375', 'yes') ; 
INSERT INTO `wp_options` VALUES (675, '_site_transient_timeout_theme_roots', '1414399452', 'yes') ; 
INSERT INTO `wp_options` VALUES (676, '_site_transient_theme_roots', 'a:5:{s:18:"cornerstone-master";s:7:"/themes";s:12:"fallengiants";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (680, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1414397698;s:7:"checked";a:5:{s:18:"cornerstone-master";s:5:"3.4.5";s:12:"fallengiants";s:5:"1.0.0";s:14:"twentyfourteen";s:3:"1.1";s:14:"twentythirteen";s:3:"1.2";s:12:"twentytwelve";s:3:"1.4";}s:8:"response";a:3:{s:14:"twentyfourteen";a:4:{s:5:"theme";s:14:"twentyfourteen";s:11:"new_version";s:3:"1.2";s:3:"url";s:43:"https://wordpress.org/themes/twentyfourteen";s:7:"package";s:60:"https://downloads.wordpress.org/theme/twentyfourteen.1.2.zip";}s:14:"twentythirteen";a:4:{s:5:"theme";s:14:"twentythirteen";s:11:"new_version";s:3:"1.3";s:3:"url";s:43:"https://wordpress.org/themes/twentythirteen";s:7:"package";s:60:"https://downloads.wordpress.org/theme/twentythirteen.1.3.zip";}s:12:"twentytwelve";a:4:{s:5:"theme";s:12:"twentytwelve";s:11:"new_version";s:3:"1.5";s:3:"url";s:41:"https://wordpress.org/themes/twentytwelve";s:7:"package";s:58:"https://downloads.wordpress.org/theme/twentytwelve.1.5.zip";}}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (681, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1414397698;s:8:"response";a:4:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.0.2";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.0.2.zip";}s:25:"google-maps-ready/gmp.php";O:8:"stdClass":6:{s:2:"id";s:5:"46884";s:4:"slug";s:17:"google-maps-ready";s:6:"plugin";s:25:"google-maps-ready/gmp.php";s:11:"new_version";s:7:"1.2.5.4";s:3:"url";s:48:"https://wordpress.org/plugins/google-maps-ready/";s:7:"package";s:60:"https://downloads.wordpress.org/plugin/google-maps-ready.zip";}s:27:"woocommerce/woocommerce.php";O:8:"stdClass":6:{s:2:"id";s:5:"25331";s:4:"slug";s:11:"woocommerce";s:6:"plugin";s:27:"woocommerce/woocommerce.php";s:11:"new_version";s:5:"2.2.7";s:3:"url";s:42:"https://wordpress.org/plugins/woocommerce/";s:7:"package";s:60:"https://downloads.wordpress.org/plugin/woocommerce.2.2.7.zip";}s:31:"wp-google-maps/wpGoogleMaps.php";O:8:"stdClass":6:{s:2:"id";s:5:"28725";s:4:"slug";s:14:"wp-google-maps";s:6:"plugin";s:31:"wp-google-maps/wpGoogleMaps.php";s:11:"new_version";s:6:"6.0.28";s:3:"url";s:45:"https://wordpress.org/plugins/wp-google-maps/";s:7:"package";s:57:"https://downloads.wordpress.org/plugin/wp-google-maps.zip";}}s:12:"translations";a:0:{}s:9:"no_update";a:5:{s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":6:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"2.6.2";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.2.6.2.zip";}s:67:"comprehensive-google-map-plugin/comprehensive-google-map-plugin.php";O:8:"stdClass":6:{s:2:"id";s:5:"26871";s:4:"slug";s:31:"comprehensive-google-map-plugin";s:6:"plugin";s:67:"comprehensive-google-map-plugin/comprehensive-google-map-plugin.php";s:11:"new_version";s:5:"9.1.2";s:3:"url";s:62:"https://wordpress.org/plugins/comprehensive-google-map-plugin/";s:7:"package";s:80:"https://downloads.wordpress.org/plugin/comprehensive-google-map-plugin.9.1.2.zip";}s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}s:19:"jetpack/jetpack.php";O:8:"stdClass":6:{s:2:"id";s:5:"20101";s:4:"slug";s:7:"jetpack";s:6:"plugin";s:19:"jetpack/jetpack.php";s:11:"new_version";s:5:"3.1.1";s:3:"url";s:38:"https://wordpress.org/plugins/jetpack/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/jetpack.3.1.1.zip";}s:47:"regenerate-thumbnails/regenerate-thumbnails.php";O:8:"stdClass":7:{s:2:"id";s:4:"4437";s:4:"slug";s:21:"regenerate-thumbnails";s:6:"plugin";s:47:"regenerate-thumbnails/regenerate-thumbnails.php";s:11:"new_version";s:5:"2.2.4";s:14:"upgrade_notice";s:124:"Better AJAX response error handling in the JavaScript. This should fix a long-standing bug in this plugin. Props Hew Sutton.";s:3:"url";s:52:"https://wordpress.org/plugins/regenerate-thumbnails/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/regenerate-thumbnails.zip";}}}', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=602 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (500 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 2, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (3, 2, '_wp_trash_meta_time', '1412823532') ; 
INSERT INTO `wp_postmeta` VALUES (4, 5, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 5, '_wp_page_template', 'one-page-layout.php') ; 
INSERT INTO `wp_postmeta` VALUES (6, 5, '_edit_lock', '1413172878:1') ; 
INSERT INTO `wp_postmeta` VALUES (7, 7, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (8, 7, '_wp_page_template', 'archive-product.php') ; 
INSERT INTO `wp_postmeta` VALUES (9, 7, '_edit_lock', '1413327762:1') ; 
INSERT INTO `wp_postmeta` VALUES (10, 9, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (11, 9, '_wp_page_template', 'our-story.php') ; 
INSERT INTO `wp_postmeta` VALUES (12, 9, '_edit_lock', '1413285359:1') ; 
INSERT INTO `wp_postmeta` VALUES (13, 11, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14, 11, '_wp_page_template', 'cellar-door.php') ; 
INSERT INTO `wp_postmeta` VALUES (15, 11, '_edit_lock', '1413867782:1') ; 
INSERT INTO `wp_postmeta` VALUES (16, 13, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (17, 13, '_wp_page_template', 'find-us.php') ; 
INSERT INTO `wp_postmeta` VALUES (18, 13, '_edit_lock', '1413871566:1') ; 
INSERT INTO `wp_postmeta` VALUES (63, 27, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (64, 27, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (65, 27, '_menu_item_object_id', '27') ; 
INSERT INTO `wp_postmeta` VALUES (66, 27, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (67, 27, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (68, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (69, 27, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (70, 27, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (72, 28, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (73, 28, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (74, 28, '_menu_item_object_id', '28') ; 
INSERT INTO `wp_postmeta` VALUES (75, 28, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (76, 28, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (77, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (78, 28, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (79, 28, '_menu_item_url', '#our-story') ; 
INSERT INTO `wp_postmeta` VALUES (81, 29, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (82, 29, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (83, 29, '_menu_item_object_id', '29') ; 
INSERT INTO `wp_postmeta` VALUES (84, 29, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (85, 29, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (86, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (87, 29, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (88, 29, '_menu_item_url', '#our-wines') ; 
INSERT INTO `wp_postmeta` VALUES (90, 30, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (91, 30, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (92, 30, '_menu_item_object_id', '30') ; 
INSERT INTO `wp_postmeta` VALUES (93, 30, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (94, 30, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (95, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (96, 30, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (97, 30, '_menu_item_url', '#cellar-door') ; 
INSERT INTO `wp_postmeta` VALUES (99, 31, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (100, 31, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (101, 31, '_menu_item_object_id', '31') ; 
INSERT INTO `wp_postmeta` VALUES (102, 31, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (103, 31, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (104, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (105, 31, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (106, 31, '_menu_item_url', '#find-us') ; 
INSERT INTO `wp_postmeta` VALUES (140, 41, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (141, 41, '_edit_lock', '1414051798:1') ; 
INSERT INTO `wp_postmeta` VALUES (143, 41, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (144, 41, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (146, 41, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (147, 41, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (148, 41, '_regular_price', '20') ; 
INSERT INTO `wp_postmeta` VALUES (149, 41, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (150, 41, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (151, 41, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (152, 41, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (153, 41, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (154, 41, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (155, 41, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (156, 41, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (157, 41, '_product_attributes', 'a:4:{s:10:"pa_vintage";a:6:{s:4:"name";s:10:"pa_vintage";s:5:"value";s:0:"";s:8:"position";s:1:"0";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:10:"pa_variety";a:6:{s:4:"name";s:10:"pa_variety";s:5:"value";s:0:"";s:8:"position";s:1:"1";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:11:"pa_vineyard";a:6:{s:4:"name";s:11:"pa_vineyard";s:5:"value";s:0:"";s:8:"position";s:1:"2";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:9:"pa_winery";a:6:{s:4:"name";s:9:"pa_winery";s:5:"value";s:0:"";s:8:"position";s:1:"3";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}}') ; 
INSERT INTO `wp_postmeta` VALUES (158, 41, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (159, 41, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (160, 41, '_price', '20') ; 
INSERT INTO `wp_postmeta` VALUES (161, 41, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (162, 41, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (163, 41, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (164, 41, '_stock', '') ; 
INSERT INTO `wp_postmeta` VALUES (165, 41, '_product_image_gallery', '128,121,125') ; 
INSERT INTO `wp_postmeta` VALUES (166, 42, '_wp_attached_file', '2014/10/LR__DSC7174.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (167, 42, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7174.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7174-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7174-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7174-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7174-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7174-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7174-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:8;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412382790;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:3:"200";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (168, 43, '_wp_attached_file', '2014/10/LR__DSC7179.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (169, 43, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7179.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7179-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7179-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7179-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7179-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7179-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7179-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412383815;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:3:"200";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (170, 44, '_wp_attached_file', '2014/10/LR__DSC7188.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (171, 44, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7188.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7188-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7188-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7188-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7188-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7188-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7188-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:9;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412383884;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:3:"200";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (172, 45, '_wp_attached_file', '2014/10/LR__DSC7193.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (173, 45, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7193.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7193-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7193-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7193-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7193-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7193-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7193-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:9;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412384342;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:3:"200";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (174, 46, '_wp_attached_file', '2014/10/LR__DSC7196.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (175, 46, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7196.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7196-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7196-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7196-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7196-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7196-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7196-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:9;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412384360;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:3:"200";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (176, 47, '_wp_attached_file', '2014/10/LR__DSC7207.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (177, 47, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7207.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7207-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7207-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7207-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7207-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7207-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7207-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412384900;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:3:"200";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (178, 48, '_wp_attached_file', '2014/10/LR__DSC7209.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (179, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7209.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7209-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7209-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7209-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7209-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7209-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7209-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:10;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412384936;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (180, 49, '_wp_attached_file', '2014/10/LR__DSC7221.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (181, 49, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7221.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7221-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7221-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7221-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7221-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7221-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7221-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412385078;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (182, 50, '_wp_attached_file', '2014/10/LR__DSC7223.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (183, 50, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7223.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7223-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7223-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7223-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7223-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7223-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7223-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412385186;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (184, 51, '_wp_attached_file', '2014/10/LR__DSC7225.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (185, 51, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7225.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7225-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7225-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7225-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7225-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7225-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7225-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412385212;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (186, 52, '_wp_attached_file', '2014/10/LR__DSC7230.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (187, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7230.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7230-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7230-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7230-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7230-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7230-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7230-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:4.5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412385692;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (188, 53, '_wp_attached_file', '2014/10/LR__DSC7241.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (189, 53, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7241.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7241-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7241-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7241-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7241-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7241-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7241-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:8;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412385801;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:7:"0.00625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (190, 54, '_wp_attached_file', '2014/10/LR__DSC7246.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (191, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7246.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7246-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7246-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7246-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7246-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7246-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7246-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:8;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412385881;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:7:"0.00625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (192, 55, '_wp_attached_file', '2014/10/LR__DSC7254.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (193, 55, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7254.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7254-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7254-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7254-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7254-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7254-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7254-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412386054;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (194, 56, '_wp_attached_file', '2014/10/LR__DSC7266.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (195, 56, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7266.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7266-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7266-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7266-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7266-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7266-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7266-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:3.20000000000000017763568394002504646778106689453125;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412386525;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (196, 57, '_wp_attached_file', '2014/10/LR__DSC7287.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (197, 57, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7287.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7287-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7287-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7287-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7287-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7287-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7287-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412386659;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.001";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (198, 58, '_wp_attached_file', '2014/10/LR__DSC7292-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (199, 58, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7292-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7292-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7292-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7292-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7292-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7292-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7292-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412386720;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.001";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (200, 59, '_wp_attached_file', '2014/10/LR__DSC7292.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (201, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7292.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7292-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7292-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7292-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7292-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7292-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7292-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412386720;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.001";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (202, 60, '_wp_attached_file', '2014/10/LR__DSC7306.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (203, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7306.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7306-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7306-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7306-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7306-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7306-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7306-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:4.5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387112;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (204, 61, '_wp_attached_file', '2014/10/LR__DSC7311-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (205, 61, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:25:"2014/10/LR__DSC7311-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7311-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7311-2-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7311-2-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7311-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7311-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7311-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387144;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (206, 62, '_wp_attached_file', '2014/10/LR__DSC7311.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (207, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7311.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7311-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7311-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7311-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7311-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7311-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7311-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387144;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (208, 63, '_wp_attached_file', '2014/10/LR__DSC7317.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (209, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7317.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7317-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7317-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7317-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7317-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7317-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7317-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387161;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (210, 64, '_wp_attached_file', '2014/10/LR__DSC7327.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (211, 64, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7327.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7327-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7327-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7327-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7327-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7327-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7327-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387301;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (212, 65, '_wp_attached_file', '2014/10/LR__DSC7340.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (213, 65, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7340.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7340-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7340-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7340-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7340-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7340-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7340-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387368;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (214, 66, '_wp_attached_file', '2014/10/LR__DSC7350.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (215, 66, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7350.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7350-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7350-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7350-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7350-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7350-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7350-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387453;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (216, 67, '_wp_attached_file', '2014/10/LR__DSC7353.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (217, 67, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7353.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7353-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7353-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7353-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7353-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7353-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7353-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387460;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (218, 68, '_wp_attached_file', '2014/10/LR__DSC7356-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (219, 68, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7356-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7356-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7356-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7356-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7356-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7356-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7356-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387550;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (220, 69, '_wp_attached_file', '2014/10/LR__DSC7356.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (221, 69, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7356.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7356-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7356-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7356-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7356-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7356-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7356-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387550;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (222, 70, '_wp_attached_file', '2014/10/LR__DSC7357.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (223, 70, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7357.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7357-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7357-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7357-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7357-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7357-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7357-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387613;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (224, 71, '_wp_attached_file', '2014/10/LR__DSC7371-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (225, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7371-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7371-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7371-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7371-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7371-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7371-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7371-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387792;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (226, 72, '_wp_attached_file', '2014/10/LR__DSC7371.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (227, 72, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7371.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7371-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7371-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7371-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7371-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7371-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7371-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412387792;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (228, 73, '_wp_attached_file', '2014/10/LR__DSC7400-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (229, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7400-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7400-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7400-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7400-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7400-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7400-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7400-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412388163;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (230, 74, '_wp_attached_file', '2014/10/LR__DSC7400.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (231, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7400.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7400-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7400-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7400-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7400-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7400-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7400-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412388163;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (232, 75, '_wp_attached_file', '2014/10/LR__DSC7402.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (233, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7402.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7402-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7402-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7402-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7402-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7402-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7402-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412388169;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (234, 76, '_wp_attached_file', '2014/10/LR__DSC7407.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (235, 76, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7407.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7407-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7407-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7407-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7407-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7407-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7407-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412388247;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (236, 77, '_wp_attached_file', '2014/10/LR__DSC7436-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (237, 77, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:25:"2014/10/LR__DSC7436-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7436-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7436-2-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7436-2-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7436-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7436-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7436-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412389004;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (238, 78, '_wp_attached_file', '2014/10/LR__DSC7436.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (239, 78, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7436.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7436-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7436-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7436-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7436-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7436-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7436-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412389004;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (240, 79, '_wp_attached_file', '2014/10/LR__DSC7437-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (241, 79, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7437-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7437-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7437-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7437-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7437-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7437-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7437-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412389302;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (242, 80, '_wp_attached_file', '2014/10/LR__DSC7437.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (243, 80, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7437.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7437-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7437-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7437-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7437-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7437-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7437-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412389302;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (244, 81, '_wp_attached_file', '2014/10/LR__DSC7444.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (245, 81, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7444.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7444-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7444-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7444-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7444-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7444-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7444-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412389393;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (246, 82, '_wp_attached_file', '2014/10/LR__DSC7448.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (247, 82, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7448.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7448-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7448-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7448-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7448-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7448-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7448-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412389424;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (248, 83, '_wp_attached_file', '2014/10/LR__DSC7454.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (249, 83, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7454.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7454-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7454-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7454-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7454-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7454-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7454-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412389501;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (250, 84, '_wp_attached_file', '2014/10/LR__DSC7455.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (251, 84, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7455.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7455-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7455-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7455-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7455-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7455-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7455-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412389764;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (252, 85, '_wp_attached_file', '2014/10/LR__DSC7465.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (253, 85, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7465.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7465-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7465-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7465-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7465-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7465-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7465-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:3.5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412389896;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (254, 86, '_wp_attached_file', '2014/10/LR__DSC7474.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (255, 86, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7474.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7474-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7474-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7474-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7474-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7474-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7474-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412398823;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (256, 87, '_wp_attached_file', '2014/10/LR__DSC7475.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (257, 87, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7475.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7475-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7475-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7475-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7475-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7475-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7475-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412398836;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (258, 88, '_wp_attached_file', '2014/10/LR__DSC7484-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (259, 88, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7484-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7484-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7484-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7484-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7484-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7484-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7484-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:4;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412398976;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (260, 89, '_wp_attached_file', '2014/10/LR__DSC7484.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (261, 89, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7484.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7484-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7484-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7484-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7484-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7484-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7484-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:4;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412398976;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (262, 90, '_wp_attached_file', '2014/10/LR__DSC7487.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (263, 90, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7487.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7487-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7487-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7487-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7487-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7487-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7487-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:4;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412399040;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (264, 91, '_wp_attached_file', '2014/10/LR__DSC7498.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (265, 91, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7498.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7498-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7498-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7498-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7498-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7498-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7498-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412399416;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (266, 92, '_wp_attached_file', '2014/10/LR__DSC7501.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (267, 92, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7501.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7501-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7501-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7501-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7501-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7501-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7501-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412400159;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (268, 93, '_wp_attached_file', '2014/10/LR__DSC7515.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (269, 93, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7515.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7515-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7515-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7515-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7515-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7515-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7515-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:3.5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412400461;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (270, 94, '_wp_attached_file', '2014/10/LR__DSC7516.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (271, 94, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7516.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7516-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7516-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7516-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7516-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7516-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7516-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:3.5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412400466;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (272, 95, '_wp_attached_file', '2014/10/LR__DSC7525.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (273, 95, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7525.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7525-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7525-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7525-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7525-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7525-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7525-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412401961;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (274, 96, '_wp_attached_file', '2014/10/LR__DSC7531.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (275, 96, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7531.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7531-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7531-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7531-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7531-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7531-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7531-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:4;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412402149;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (276, 97, '_wp_attached_file', '2014/10/LR__DSC7538.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (277, 97, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7538.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7538-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7538-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7538-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7538-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7538-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7538-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:4;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412402980;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (278, 98, '_wp_attached_file', '2014/10/LR__DSC7543-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (279, 98, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7543-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7543-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7543-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7543-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7543-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7543-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7543-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412405954;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (280, 99, '_wp_attached_file', '2014/10/LR__DSC7543.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (281, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7543.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7543-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7543-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7543-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7543-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7543-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7543-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412405954;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (282, 100, '_wp_attached_file', '2014/10/LR__DSC7550-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (283, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7550-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7550-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7550-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7550-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7550-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7550-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7550-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406096;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (284, 101, '_wp_attached_file', '2014/10/LR__DSC7550.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (285, 101, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7550.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7550-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7550-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7550-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7550-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7550-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7550-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406096;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (286, 102, '_wp_attached_file', '2014/10/LR__DSC7551.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (287, 102, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7551.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7551-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7551-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7551-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7551-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7551-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7551-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406132;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (288, 103, '_wp_attached_file', '2014/10/LR__DSC7553-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (289, 103, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:25:"2014/10/LR__DSC7553-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7553-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7553-2-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7553-2-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7553-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7553-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7553-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406140;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (290, 104, '_wp_attached_file', '2014/10/LR__DSC7553.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (291, 104, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7553.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7553-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7553-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7553-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7553-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7553-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7553-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406140;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (292, 105, '_wp_attached_file', '2014/10/LR__DSC7561-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (293, 105, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7561-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7561-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7561-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7561-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7561-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7561-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7561-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406202;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (294, 106, '_wp_attached_file', '2014/10/LR__DSC7561.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (295, 106, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7561.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7561-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7561-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7561-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7561-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7561-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7561-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406202;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (296, 107, '_wp_attached_file', '2014/10/LR__DSC7565.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (297, 107, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7565.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7565-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7565-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7565-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7565-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7565-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7565-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406214;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (298, 108, '_wp_attached_file', '2014/10/LR__DSC7566.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (299, 108, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7566.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7566-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7566-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7566-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7566-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7566-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7566-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.29999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406245;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (300, 109, '_wp_attached_file', '2014/10/LR__DSC7578.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (301, 109, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7578.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7578-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7578-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7578-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7578-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7578-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7578-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406533;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.005";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (302, 110, '_wp_attached_file', '2014/10/LR__DSC7584-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (303, 110, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:25:"2014/10/LR__DSC7584-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7584-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7584-2-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7584-2-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7584-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7584-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7584-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406598;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (304, 111, '_wp_attached_file', '2014/10/LR__DSC7584.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (305, 111, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7584.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7584-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7584-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7584-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7584-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7584-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7584-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406598;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (306, 112, '_wp_attached_file', '2014/10/LR__DSC7588.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (307, 112, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7588.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7588-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7588-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7588-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7588-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7588-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7588-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406621;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (308, 113, '_wp_attached_file', '2014/10/LR__DSC7599-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (309, 113, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:25:"2014/10/LR__DSC7599-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7599-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7599-2-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7599-2-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7599-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7599-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7599-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406728;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (310, 114, '_wp_attached_file', '2014/10/LR__DSC7599.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (311, 114, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7599.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7599-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7599-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7599-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7599-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7599-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7599-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406728;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (312, 115, '_wp_attached_file', '2014/10/LR__DSC7604-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (313, 115, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7604-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7604-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7604-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7604-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7604-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7604-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7604-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406797;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (314, 116, '_wp_attached_file', '2014/10/LR__DSC7604.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (315, 116, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7604.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7604-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7604-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7604-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7604-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7604-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7604-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406797;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (316, 117, '_wp_attached_file', '2014/10/LR__DSC7610.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (317, 117, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7610.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7610-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7610-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7610-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7610-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7610-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7610-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406845;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (318, 118, '_wp_attached_file', '2014/10/LR__DSC7613.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (319, 118, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7613.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7613-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7613-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7613-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7613-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7613-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7613-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406869;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (320, 119, '_wp_attached_file', '2014/10/LR__DSC7616-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (321, 119, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7616-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7616-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7616-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7616-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7616-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7616-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7616-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406972;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:8:"0.003125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (322, 120, '_wp_attached_file', '2014/10/LR__DSC7616.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (323, 120, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7616.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7616-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7616-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7616-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7616-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7616-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7616-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406972;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:8:"0.003125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (324, 121, '_wp_attached_file', '2014/10/LR__DSC7618.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (325, 121, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7618.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7618-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7618-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7618-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7618-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7618-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7618-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406994;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:8:"0.003125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (326, 122, '_wp_attached_file', '2014/10/LR__DSC7620-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (327, 122, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7620-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7620-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7620-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7620-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7620-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7620-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7620-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406999;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:8:"0.003125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (328, 123, '_wp_attached_file', '2014/10/LR__DSC7620.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (329, 123, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7620.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7620-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7620-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7620-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7620-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7620-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7620-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412406999;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:8:"0.003125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (330, 124, '_wp_attached_file', '2014/10/LR__DSC7622.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (331, 124, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7622.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7622-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7622-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7622-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7622-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7622-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7622-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412407058;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:8:"0.003125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (332, 125, '_wp_attached_file', '2014/10/LR__DSC7624.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (333, 125, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7624.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7624-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7624-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7624-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7624-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7624-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7624-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412407092;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:8:"0.003125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (334, 126, '_wp_attached_file', '2014/10/LR__DSC7631.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (335, 126, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7631.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7631-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7631-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7631-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7631-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7631-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7631-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:7.0999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412407216;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:8:"0.003125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (336, 127, '_wp_attached_file', '2014/10/LR__DSC7648.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (337, 127, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7648.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7648-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7648-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7648-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7648-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7648-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7648-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412407468;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (338, 128, '_wp_attached_file', '2014/10/LR__DSC7650.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (339, 128, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7650.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7650-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7650-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7650-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7650-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7650-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7650-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412407509;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0025";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (340, 129, '_wp_attached_file', '2014/10/LR__DSC7652.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (341, 129, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7652.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7652-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7652-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7652-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7652-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7652-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7652-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412407520;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (342, 130, '_wp_attached_file', '2014/10/LR__DSC7654-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (343, 130, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7654-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7654-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7654-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7654-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7654-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7654-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7654-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412407938;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (344, 131, '_wp_attached_file', '2014/10/LR__DSC7654.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (345, 131, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7654.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7654-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7654-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7654-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7654-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7654-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7654-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412407938;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (346, 132, '_wp_attached_file', '2014/10/LR__DSC7656-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (347, 132, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7656-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7656-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7656-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7656-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7656-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7656-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7656-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:2.5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412407949;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (348, 133, '_wp_attached_file', '2014/10/LR__DSC7656.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (349, 133, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7656.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7656-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7656-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7656-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7656-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7656-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7656-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:2.5;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412407949;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"35";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (350, 134, '_wp_attached_file', '2014/10/LR__DSC7660-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (351, 134, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7660-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7660-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7660-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7660-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7660-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7660-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7660-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:3.20000000000000017763568394002504646778106689453125;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408003;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (352, 135, '_wp_attached_file', '2014/10/LR__DSC7660.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (353, 135, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7660.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7660-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7660-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7660-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7660-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7660-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7660-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:3.20000000000000017763568394002504646778106689453125;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408003;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (354, 136, '_wp_attached_file', '2014/10/LR__DSC7678.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (355, 136, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7678.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7678-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7678-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7678-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7678-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7678-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7678-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:3.20000000000000017763568394002504646778106689453125;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408086;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (356, 137, '_wp_attached_file', '2014/10/LR__DSC7685-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (357, 137, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7685-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7685-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7685-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7685-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7685-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7685-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7685-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:3.20000000000000017763568394002504646778106689453125;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408271;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0005";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (358, 138, '_wp_attached_file', '2014/10/LR__DSC7685.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (359, 138, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7685.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7685-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7685-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7685-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7685-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7685-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7685-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:3.20000000000000017763568394002504646778106689453125;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408271;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0005";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (360, 139, '_wp_attached_file', '2014/10/LR__DSC7687.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (361, 139, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7687.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7687-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7687-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7687-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7687-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7687-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7687-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:3.20000000000000017763568394002504646778106689453125;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408302;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0005";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (362, 140, '_wp_attached_file', '2014/10/LR__DSC7689.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (363, 140, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7689.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7689-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7689-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7689-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7689-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7689-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7689-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:3.20000000000000017763568394002504646778106689453125;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408358;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0005";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (364, 141, '_wp_attached_file', '2014/10/LR__DSC7698-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (365, 141, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7698-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7698-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7698-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7698-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7698-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7698-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7698-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:10;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408408;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.005";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (366, 142, '_wp_attached_file', '2014/10/LR__DSC7698.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (367, 142, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7698.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7698-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7698-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7698-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7698-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7698-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7698-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:10;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408408;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.005";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (368, 143, '_wp_attached_file', '2014/10/LR__DSC7704.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (369, 143, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7704.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7704-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7704-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7704-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7704-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7704-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7704-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:2.79999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408491;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (370, 144, '_wp_attached_file', '2014/10/LR__DSC7705.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (371, 144, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7705.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7705-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7705-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7705-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7705-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7705-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7705-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:2.79999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408498;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (372, 145, '_wp_attached_file', '2014/10/LR__DSC7707.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (373, 145, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7707.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7707-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7707-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7707-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7707-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7707-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7707-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:2.79999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408500;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (374, 146, '_wp_attached_file', '2014/10/LR__DSC7710-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (375, 146, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7710-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7710-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7710-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7710-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7710-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7710-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7710-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:2.79999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408578;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (376, 147, '_wp_attached_file', '2014/10/LR__DSC7710.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (377, 147, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7710.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7710-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7710-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7710-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7710-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7710-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7710-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:2.79999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408578;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (378, 148, '_wp_attached_file', '2014/10/LR__DSC7711.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (379, 148, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7711.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7711-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7711-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7711-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7711-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7711-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7711-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:2.79999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408613;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:6:"0.0004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (380, 149, '_wp_attached_file', '2014/10/LR__DSC7718.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (381, 149, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7718.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7718-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7718-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7718-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7718-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7718-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7718-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:8;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408693;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (382, 150, '_wp_attached_file', '2014/10/LR__DSC7723.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (383, 150, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7723.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7723-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7723-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7723-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7723-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7723-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7723-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:8;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408760;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.002";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (384, 151, '_wp_attached_file', '2014/10/LR__DSC7731-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (385, 151, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:25:"2014/10/LR__DSC7731-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7731-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7731-2-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7731-2-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7731-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7731-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7731-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:8;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408803;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:7:"0.00625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (386, 152, '_wp_attached_file', '2014/10/LR__DSC7731.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (387, 152, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1001;s:6:"height";i:1500;s:4:"file";s:23:"2014/10/LR__DSC7731.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7731-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7731-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7731-683x1024.jpg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7731-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7731-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7731-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:8;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412408803;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:7:"0.00625";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (388, 153, '_wp_attached_file', '2014/10/LR__DSC7738-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (389, 153, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7738-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7738-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7738-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7738-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7738-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7738-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7738-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412409242;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (390, 154, '_wp_attached_file', '2014/10/LR__DSC7738.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (391, 154, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7738.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7738-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7738-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7738-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7738-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7738-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7738-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412409242;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.008";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (392, 155, '_wp_attached_file', '2014/10/LR__DSC7744-2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (393, 155, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:25:"2014/10/LR__DSC7744-2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"LR__DSC7744-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"LR__DSC7744-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"LR__DSC7744-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7744-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"LR__DSC7744-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"LR__DSC7744-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412409257;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.005";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (394, 156, '_wp_attached_file', '2014/10/LR__DSC7744.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (395, 156, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1001;s:4:"file";s:23:"2014/10/LR__DSC7744.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"LR__DSC7744-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"LR__DSC7744-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"LR__DSC7744-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"LR__DSC7744-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"LR__DSC7744-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"LR__DSC7744-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:0:"";s:6:"camera";s:10:"NIKON D800";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1412409257;s:9:"copyright";s:18:"Ivanna Capture You";s:12:"focal_length";s:2:"20";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:5:"0.005";s:5:"title";s:18:"Ivanna Capture You";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (396, 157, '_wp_attached_file', '2014/10/CAB-SAV-BACKGROUND.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (397, 157, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1252;s:6:"height";i:1013;s:4:"file";s:30:"2014/10/CAB-SAV-BACKGROUND.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"CAB-SAV-BACKGROUND-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"CAB-SAV-BACKGROUND-300x242.jpg";s:5:"width";i:300;s:6:"height";i:242;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:31:"CAB-SAV-BACKGROUND-1024x828.jpg";s:5:"width";i:1024;s:6:"height";i:828;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:28:"CAB-SAV-BACKGROUND-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:30:"CAB-SAV-BACKGROUND-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:30:"CAB-SAV-BACKGROUND-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:1;}}') ; 
INSERT INTO `wp_postmeta` VALUES (398, 158, '_wp_attached_file', '2014/10/FALLEN-GIANTS-LOGO-BLACK.png') ; 
INSERT INTO `wp_postmeta` VALUES (399, 158, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1782;s:6:"height";i:591;s:4:"file";s:36:"2014/10/FALLEN-GIANTS-LOGO-BLACK.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"FALLEN-GIANTS-LOGO-BLACK-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:35:"FALLEN-GIANTS-LOGO-BLACK-300x99.png";s:5:"width";i:300;s:6:"height";i:99;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:37:"FALLEN-GIANTS-LOGO-BLACK-1024x339.png";s:5:"width";i:1024;s:6:"height";i:339;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:34:"FALLEN-GIANTS-LOGO-BLACK-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:36:"FALLEN-GIANTS-LOGO-BLACK-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:36:"FALLEN-GIANTS-LOGO-BLACK-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (400, 159, '_wp_attached_file', '2014/10/FALLEN-GIANTS-LOGO-DARK-GREY.png') ; 
INSERT INTO `wp_postmeta` VALUES (401, 159, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1782;s:6:"height";i:591;s:4:"file";s:40:"2014/10/FALLEN-GIANTS-LOGO-DARK-GREY.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:40:"FALLEN-GIANTS-LOGO-DARK-GREY-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:39:"FALLEN-GIANTS-LOGO-DARK-GREY-300x99.png";s:5:"width";i:300;s:6:"height";i:99;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:41:"FALLEN-GIANTS-LOGO-DARK-GREY-1024x339.png";s:5:"width";i:1024;s:6:"height";i:339;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:38:"FALLEN-GIANTS-LOGO-DARK-GREY-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:40:"FALLEN-GIANTS-LOGO-DARK-GREY-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:40:"FALLEN-GIANTS-LOGO-DARK-GREY-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (402, 160, '_wp_attached_file', '2014/10/FALLEN-GIANTS-LOGO-WHITE.png') ; 
INSERT INTO `wp_postmeta` VALUES (403, 160, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1782;s:6:"height";i:591;s:4:"file";s:36:"2014/10/FALLEN-GIANTS-LOGO-WHITE.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"FALLEN-GIANTS-LOGO-WHITE-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:35:"FALLEN-GIANTS-LOGO-WHITE-300x99.png";s:5:"width";i:300;s:6:"height";i:99;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:37:"FALLEN-GIANTS-LOGO-WHITE-1024x339.png";s:5:"width";i:1024;s:6:"height";i:339;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:34:"FALLEN-GIANTS-LOGO-WHITE-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:36:"FALLEN-GIANTS-LOGO-WHITE-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:36:"FALLEN-GIANTS-LOGO-WHITE-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (404, 161, '_wp_attached_file', '2014/10/HALLS-GAP-ESTATE-LOGO-BLACK.png') ; 
INSERT INTO `wp_postmeta` VALUES (405, 161, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1707;s:6:"height";i:366;s:4:"file";s:39:"2014/10/HALLS-GAP-ESTATE-LOGO-BLACK.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"HALLS-GAP-ESTATE-LOGO-BLACK-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:38:"HALLS-GAP-ESTATE-LOGO-BLACK-300x64.png";s:5:"width";i:300;s:6:"height";i:64;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:40:"HALLS-GAP-ESTATE-LOGO-BLACK-1024x219.png";s:5:"width";i:1024;s:6:"height";i:219;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:37:"HALLS-GAP-ESTATE-LOGO-BLACK-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:39:"HALLS-GAP-ESTATE-LOGO-BLACK-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:39:"HALLS-GAP-ESTATE-LOGO-BLACK-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (406, 162, '_wp_attached_file', '2014/10/HALLS-GAP-ESTATE-LOGO-DARK-GREY.png') ; 
INSERT INTO `wp_postmeta` VALUES (407, 162, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1707;s:6:"height";i:366;s:4:"file";s:43:"2014/10/HALLS-GAP-ESTATE-LOGO-DARK-GREY.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:43:"HALLS-GAP-ESTATE-LOGO-DARK-GREY-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:42:"HALLS-GAP-ESTATE-LOGO-DARK-GREY-300x64.png";s:5:"width";i:300;s:6:"height";i:64;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:44:"HALLS-GAP-ESTATE-LOGO-DARK-GREY-1024x219.png";s:5:"width";i:1024;s:6:"height";i:219;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:41:"HALLS-GAP-ESTATE-LOGO-DARK-GREY-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:43:"HALLS-GAP-ESTATE-LOGO-DARK-GREY-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:43:"HALLS-GAP-ESTATE-LOGO-DARK-GREY-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (408, 163, '_wp_attached_file', '2014/10/HALLS-GAP-ESTATE-LOGO-WHITE.png') ; 
INSERT INTO `wp_postmeta` VALUES (409, 163, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1707;s:6:"height";i:366;s:4:"file";s:39:"2014/10/HALLS-GAP-ESTATE-LOGO-WHITE.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"HALLS-GAP-ESTATE-LOGO-WHITE-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:38:"HALLS-GAP-ESTATE-LOGO-WHITE-300x64.png";s:5:"width";i:300;s:6:"height";i:64;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:40:"HALLS-GAP-ESTATE-LOGO-WHITE-1024x219.png";s:5:"width";i:1024;s:6:"height";i:219;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:37:"HALLS-GAP-ESTATE-LOGO-WHITE-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:39:"HALLS-GAP-ESTATE-LOGO-WHITE-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:39:"HALLS-GAP-ESTATE-LOGO-WHITE-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (410, 164, '_wp_attached_file', '2014/10/RIESLING-BACKGROUND.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (411, 164, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1252;s:6:"height";i:1013;s:4:"file";s:31:"2014/10/RIESLING-BACKGROUND.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"RIESLING-BACKGROUND-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"RIESLING-BACKGROUND-300x242.jpg";s:5:"width";i:300;s:6:"height";i:242;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"RIESLING-BACKGROUND-1024x828.jpg";s:5:"width";i:1024;s:6:"height";i:828;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:29:"RIESLING-BACKGROUND-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:31:"RIESLING-BACKGROUND-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:31:"RIESLING-BACKGROUND-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:1;}}') ; 
INSERT INTO `wp_postmeta` VALUES (412, 165, '_wp_attached_file', '2014/10/SHIRAZ-BACKGROUND.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (413, 165, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1252;s:6:"height";i:1013;s:4:"file";s:29:"2014/10/SHIRAZ-BACKGROUND.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"SHIRAZ-BACKGROUND-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"SHIRAZ-BACKGROUND-300x242.jpg";s:5:"width";i:300;s:6:"height";i:242;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"SHIRAZ-BACKGROUND-1024x828.jpg";s:5:"width";i:1024;s:6:"height";i:828;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:27:"SHIRAZ-BACKGROUND-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:29:"SHIRAZ-BACKGROUND-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:29:"SHIRAZ-BACKGROUND-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:1;}}') ; 
INSERT INTO `wp_postmeta` VALUES (414, 41, '_thumbnail_id', '165') ; 
INSERT INTO `wp_postmeta` VALUES (415, 166, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (416, 166, '_edit_lock', '1414046258:1') ; 
INSERT INTO `wp_postmeta` VALUES (418, 166, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (419, 166, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (421, 166, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (422, 166, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (423, 166, '_regular_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (424, 166, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (425, 166, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (426, 166, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (427, 166, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (428, 166, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (429, 166, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (430, 166, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (431, 166, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (432, 166, '_product_attributes', 'a:4:{s:10:"pa_vintage";a:6:{s:4:"name";s:10:"pa_vintage";s:5:"value";s:0:"";s:8:"position";s:1:"0";s:10:"is_visible";i:0;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:10:"pa_variety";a:6:{s:4:"name";s:10:"pa_variety";s:5:"value";s:0:"";s:8:"position";s:1:"3";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:11:"pa_vineyard";a:6:{s:4:"name";s:11:"pa_vineyard";s:5:"value";s:0:"";s:8:"position";s:1:"5";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:9:"pa_winery";a:6:{s:4:"name";s:9:"pa_winery";s:5:"value";s:0:"";s:8:"position";s:1:"7";s:10:"is_visible";i:0;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}}') ; 
INSERT INTO `wp_postmeta` VALUES (433, 166, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (434, 166, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (435, 166, '_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (436, 166, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (437, 166, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (438, 166, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (439, 166, '_stock', '') ; 
INSERT INTO `wp_postmeta` VALUES (440, 166, '_product_image_gallery', '128,121,125') ; 
INSERT INTO `wp_postmeta` VALUES (441, 166, '_thumbnail_id', '164') ; 
INSERT INTO `wp_postmeta` VALUES (446, 167, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (447, 167, '_edit_lock', '1414113403:1') ; 
INSERT INTO `wp_postmeta` VALUES (449, 167, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (450, 167, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (452, 167, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (453, 167, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (454, 167, '_regular_price', '20') ; 
INSERT INTO `wp_postmeta` VALUES (455, 167, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (456, 167, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (457, 167, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (458, 167, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (459, 167, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (460, 167, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (461, 167, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (462, 167, '_sku', '') ; 
INSERT INTO `wp_postmeta` VALUES (463, 167, '_product_attributes', 'a:4:{s:10:"pa_vintage";a:6:{s:4:"name";s:10:"pa_vintage";s:5:"value";s:0:"";s:8:"position";s:1:"0";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:10:"pa_variety";a:6:{s:4:"name";s:10:"pa_variety";s:5:"value";s:0:"";s:8:"position";s:1:"1";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:11:"pa_vineyard";a:6:{s:4:"name";s:11:"pa_vineyard";s:5:"value";s:0:"";s:8:"position";s:1:"2";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:9:"pa_winery";a:6:{s:4:"name";s:9:"pa_winery";s:5:"value";s:0:"";s:8:"position";s:1:"3";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}}') ; 
INSERT INTO `wp_postmeta` VALUES (464, 167, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (465, 167, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (466, 167, '_price', '20') ; 
INSERT INTO `wp_postmeta` VALUES (467, 167, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (468, 167, '_manage_stock', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (469, 167, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (470, 167, '_stock', '') ; 
INSERT INTO `wp_postmeta` VALUES (471, 167, '_product_image_gallery', '') ; 
INSERT INTO `wp_postmeta` VALUES (472, 167, '_thumbnail_id', '157') ; 
INSERT INTO `wp_postmeta` VALUES (477, 167, '_crosssell_ids', 'a:2:{i:0;s:3:"166";i:1;s:2:"41";}') ; 
INSERT INTO `wp_postmeta` VALUES (478, 167, '_upsell_ids', 'a:2:{i:0;s:3:"166";i:1;s:2:"41";}') ; 
INSERT INTO `wp_postmeta` VALUES (479, 168, '_order_key', 'wc_order_543c732045c96') ; 
INSERT INTO `wp_postmeta` VALUES (480, 168, '_order_currency', 'AUD') ; 
INSERT INTO `wp_postmeta` VALUES (481, 168, '_prices_include_tax', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (482, 168, '_customer_ip_address', '::1') ; 
INSERT INTO `wp_postmeta` VALUES (483, 168, '_customer_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.101 Safari/537.36') ; 
INSERT INTO `wp_postmeta` VALUES (484, 168, '_customer_user', '1') ; 
INSERT INTO `wp_postmeta` VALUES (485, 168, '_order_shipping', '0') ; 
INSERT INTO `wp_postmeta` VALUES (486, 168, '_billing_country', 'AU') ; 
INSERT INTO `wp_postmeta` VALUES (487, 168, '_billing_first_name', 'Alex') ; 
INSERT INTO `wp_postmeta` VALUES (488, 168, '_billing_last_name', 'Chavet') ; 
INSERT INTO `wp_postmeta` VALUES (489, 168, '_billing_company', 'alexchavetbuyer') ; 
INSERT INTO `wp_postmeta` VALUES (490, 168, '_billing_address_1', '11 test street') ; 
INSERT INTO `wp_postmeta` VALUES (491, 168, '_billing_address_2', '') ; 
INSERT INTO `wp_postmeta` VALUES (492, 168, '_billing_city', 'Melbourne') ; 
INSERT INTO `wp_postmeta` VALUES (493, 168, '_billing_state', 'VIC') ; 
INSERT INTO `wp_postmeta` VALUES (494, 168, '_billing_postcode', '3054') ; 
INSERT INTO `wp_postmeta` VALUES (495, 168, '_billing_email', 'alex.chavet.buyer@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (496, 168, '_billing_phone', '0449632345') ; 
INSERT INTO `wp_postmeta` VALUES (497, 168, '_shipping_country', 'AU') ; 
INSERT INTO `wp_postmeta` VALUES (498, 168, '_shipping_first_name', 'Alex') ; 
INSERT INTO `wp_postmeta` VALUES (499, 168, '_shipping_last_name', 'Chavet') ; 
INSERT INTO `wp_postmeta` VALUES (500, 168, '_shipping_company', 'alexchavetbuyer') ; 
INSERT INTO `wp_postmeta` VALUES (501, 168, '_shipping_address_1', '11 test street') ; 
INSERT INTO `wp_postmeta` VALUES (502, 168, '_shipping_address_2', '') ; 
INSERT INTO `wp_postmeta` VALUES (503, 168, '_shipping_city', 'Melbourne') ; 
INSERT INTO `wp_postmeta` VALUES (504, 168, '_shipping_state', 'VIC') ; 
INSERT INTO `wp_postmeta` VALUES (505, 168, '_shipping_postcode', '3054') ; 
INSERT INTO `wp_postmeta` VALUES (506, 168, '_payment_method', 'paypal') ; 
INSERT INTO `wp_postmeta` VALUES (507, 168, '_payment_method_title', 'PayPal') ; 
INSERT INTO `wp_postmeta` VALUES (508, 168, '_order_discount', '0') ; 
INSERT INTO `wp_postmeta` VALUES (509, 168, '_cart_discount', '0') ; 
INSERT INTO `wp_postmeta` VALUES (510, 168, '_order_tax', '0') ; 
INSERT INTO `wp_postmeta` VALUES (511, 168, '_order_shipping_tax', '0') ; 
INSERT INTO `wp_postmeta` VALUES (512, 168, '_order_total', '140.00') ; 
INSERT INTO `wp_postmeta` VALUES (513, 168, '_download_permissions_granted', '1') ; 
INSERT INTO `wp_postmeta` VALUES (514, 168, '_recorded_sales', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (515, 168, '_recorded_coupon_usage_counts', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (516, 168, '_completed_date', '2014-10-14 00:56:18') ; 
INSERT INTO `wp_postmeta` VALUES (517, 168, '_edit_lock', '1413248061:1') ; 
INSERT INTO `wp_postmeta` VALUES (518, 168, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (519, 168, '_transaction_id', '') ; 
INSERT INTO `wp_postmeta` VALUES (520, 172, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (521, 172, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (522, 172, '_menu_item_object_id', '39') ; 
INSERT INTO `wp_postmeta` VALUES (523, 172, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (524, 172, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (525, 172, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (526, 172, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (527, 172, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (529, 173, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (530, 173, '_menu_item_menu_item_parent', '172') ; 
INSERT INTO `wp_postmeta` VALUES (531, 173, '_menu_item_object_id', '37') ; 
INSERT INTO `wp_postmeta` VALUES (532, 173, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (533, 173, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (534, 173, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (535, 173, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (536, 173, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (538, 174, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (539, 174, '_menu_item_menu_item_parent', '172') ; 
INSERT INTO `wp_postmeta` VALUES (540, 174, '_menu_item_object_id', '35') ; 
INSERT INTO `wp_postmeta` VALUES (541, 174, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (542, 174, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (543, 174, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (544, 174, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (545, 174, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (547, 175, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (548, 175, '_menu_item_menu_item_parent', '172') ; 
INSERT INTO `wp_postmeta` VALUES (549, 175, '_menu_item_object_id', '33') ; 
INSERT INTO `wp_postmeta` VALUES (550, 175, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (551, 175, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (552, 175, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (553, 175, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (554, 175, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (556, 176, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (557, 176, '_menu_item_menu_item_parent', '29') ; 
INSERT INTO `wp_postmeta` VALUES (558, 176, '_menu_item_object_id', '167') ; 
INSERT INTO `wp_postmeta` VALUES (559, 176, '_menu_item_object', 'product') ; 
INSERT INTO `wp_postmeta` VALUES (560, 176, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (561, 176, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (562, 176, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (563, 176, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (565, 177, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (566, 177, '_menu_item_menu_item_parent', '29') ; 
INSERT INTO `wp_postmeta` VALUES (567, 177, '_menu_item_object_id', '166') ; 
INSERT INTO `wp_postmeta` VALUES (568, 177, '_menu_item_object', 'product') ; 
INSERT INTO `wp_postmeta` VALUES (569, 177, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (570, 177, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (571, 177, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (572, 177, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (574, 178, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (575, 178, '_menu_item_menu_item_parent', '29') ; 
INSERT INTO `wp_postmeta` VALUES (576, 178, '_menu_item_object_id', '41') ; 
INSERT INTO `wp_postmeta` VALUES (577, 178, '_menu_item_object', 'product') ; 
INSERT INTO `wp_postmeta` VALUES (578, 178, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (579, 178, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (580, 178, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (581, 178, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (582, 184, '_wp_attached_file', '2014/10/icones_01.png') ; 
INSERT INTO `wp_postmeta` VALUES (583, 184, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4;s:6:"height";i:94;s:4:"file";s:21:"2014/10/icones_01.png";s:5:"sizes";a:1:{s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"icones_01-4x90.png";s:5:"width";i:4;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (584, 185, '_wp_attached_file', '2014/10/icones_02.png') ; 
INSERT INTO `wp_postmeta` VALUES (585, 185, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:94;s:6:"height";i:94;s:4:"file";s:21:"2014/10/icones_02.png";s:5:"sizes";a:1:{s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"icones_02-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (586, 186, '_wp_attached_file', '2014/10/icones_03.png') ; 
INSERT INTO `wp_postmeta` VALUES (587, 186, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:94;s:6:"height";i:94;s:4:"file";s:21:"2014/10/icones_03.png";s:5:"sizes";a:1:{s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"icones_03-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (588, 187, '_wp_attached_file', '2014/10/icones_04.png') ; 
INSERT INTO `wp_postmeta` VALUES (589, 187, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:94;s:6:"height";i:94;s:4:"file";s:21:"2014/10/icones_04.png";s:5:"sizes";a:1:{s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"icones_04-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (590, 188, '_wp_attached_file', '2014/10/icones_05.png') ; 
INSERT INTO `wp_postmeta` VALUES (591, 188, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:94;s:6:"height";i:94;s:4:"file";s:21:"2014/10/icones_05.png";s:5:"sizes";a:1:{s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"icones_05-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (592, 189, '_wp_attached_file', '2014/10/icones_06.png') ; 
INSERT INTO `wp_postmeta` VALUES (593, 189, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:94;s:6:"height";i:94;s:4:"file";s:21:"2014/10/icones_06.png";s:5:"sizes";a:1:{s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"icones_06-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (594, 190, '_wp_attached_file', '2014/10/icones_07.png') ; 
INSERT INTO `wp_postmeta` VALUES (595, 190, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:40;s:6:"height";i:94;s:4:"file";s:21:"2014/10/icones_07.png";s:5:"sizes";a:1:{s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"icones_07-40x90.png";s:5:"width";i:40;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (596, 194, '_wp_attached_file', '2014/10/Cellar.png') ; 
INSERT INTO `wp_postmeta` VALUES (597, 194, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:175;s:4:"file";s:18:"2014/10/Cellar.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"Cellar-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"Cellar-300x87.png";s:5:"width";i:300;s:6:"height";i:87;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:16:"Cellar-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:18:"Cellar-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:18:"Cellar-300x175.png";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (598, 167, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (599, 166, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (600, 41, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (601, 41, '_upsell_ids', 'a:2:{i:0;s:3:"167";i:1;s:3:"166";}') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (194 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2014-10-09 02:56:00', '2014-10-09 02:56:00', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-10-09 02:56:00', '2014-10-09 02:56:00', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2014-10-09 02:56:00', '2014-10-09 02:56:00', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost:8888/FallenGiants/fallengiants/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'open', 'open', '', 'sample-page', '', '', '2014-10-09 02:58:52', '2014-10-09 02:58:52', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2014-10-09 02:58:52', '2014-10-09 02:58:52', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost:8888/FallenGiants/fallengiants/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-10-09 02:58:52', '2014-10-09 02:58:52', '', 2, 'http://localhost:8888/FallenGiants/fallengiants/?p=4', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2014-10-09 02:59:02', '2014-10-09 02:59:02', 'Contenu de la home page', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-10-13 04:03:41', '2014-10-13 04:03:41', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?page_id=5', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2014-10-09 02:59:02', '2014-10-09 02:59:02', '', 'Home', '', 'inherit', 'open', 'open', '', '5-revision-v1', '', '', '2014-10-09 02:59:02', '2014-10-09 02:59:02', '', 5, 'http://localhost:8888/FallenGiants/fallengiants/?p=6', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2014-10-09 02:59:17', '2014-10-09 02:59:17', 'Contenu des wines', 'Our Wines', '', 'publish', 'open', 'closed', '', 'our-wines', '', '', '2014-10-14 23:01:53', '2014-10-14 23:01:53', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?page_id=7', 2, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2014-10-09 02:59:17', '2014-10-09 02:59:17', '', 'Our Wines', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-10-09 02:59:17', '2014-10-09 02:59:17', '', 7, 'http://localhost:8888/FallenGiants/fallengiants/?p=8', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2014-10-09 02:59:29', '2014-10-09 02:59:29', 'Our vineyard was planted on the steep Eastern slopes of the Grampians in 1969. It represented part of the second coming of the Victorian wine industry which had seen very little new plantings since the turn of the century. The region had always had a pedigree for great wines with the first vineyards in Grampians being planted at Bests &amp; Seppelts, in the early 1860’s.

The vineyard has long been a respected grower for many of the countries great wineries until 1996, when it was bought by the famed Victorian Winemaker, the late, great <i>Trevor Mast</i>, and has been a staple of Mount Langi Ghiran ever since.

Our family bought it in 2013 and re named the vineyard <i>Fallen Giants</i> after the dreamtime stories of the original owners of these land, the <i>Djab Wurrung</i> and <i>Jardiwadjali</i> people. According to the legends, <i>Geriward</i> (the Grampians) was created by the great Ancestor spirit <i>Bunjil</i>, who often took the form of a great Eagle. The ranges were then further shaped by Tchingal a Giant ferocious Emu, who split the mountains with his fierce kick.

<b>The Vineyard</b>

The vineyard was planted in 1969 to Shiraz, Cabernet &amp; Riesling totalling 23 acres under vine. The majority of the planting is Shiraz (14 acres).

A cooler site being at high elevation (260M) and East facing in aspect. Mean January Temperature (MJT) 20.6 degrees C

<strong>The soil is red clay loam. It is old, dating back 380 million years ago to the Devion period. As the soils are old and weathered the vines are naturally low yielding.</strong>', 'Our story', '', 'publish', 'open', 'closed', '', 'our-story', '', '', '2014-10-14 03:25:48', '2014-10-14 03:25:48', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?page_id=9', 1, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2014-10-09 02:59:29', '2014-10-09 02:59:29', '', 'Our story', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2014-10-09 02:59:29', '2014-10-09 02:59:29', '', 9, 'http://localhost:8888/FallenGiants/fallengiants/?p=10', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2014-10-09 02:59:40', '2014-10-09 02:59:40', '<p style="text-align: center;"></p>
<p style="text-align: center;">With amazing views over the Grampians and our vineyards, our Cellar door is the perfect place to taste and enjoy our wine. With a kids playground as well...plan to stay a while.</p>
<p style="text-align: center;"><img class="icone alignnone wp-image-188 size-full" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_05.png" alt="icones_05" width="94" height="94" /></p>

<h4 style="text-align: center;">Free wine tastings.</h4>
<p style="text-align: center;"><img class="alignnone size-full wp-image-189" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_06.png" alt="icones_06" width="94" height="94" /></p>

<h4 style="text-align: center;">Cheese platters.</h4>
<p style="text-align: center;">Sit on the deck with a glass of our wine and enjoy some local produce.</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-186" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_03.png" alt="icones_03" width="94" height="94" /></p>

<h4 style="text-align: center;">Enjoy a picnic.</h4>
<p style="text-align: center;">Borrow a picnic blanket and plant yourself among the vines with a bottle of our wine for the afternoon!</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-185" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_02.png" alt="icones_02" width="94" height="94" /></p>

<h4 style="text-align: center;">Vineyard tours.</h4>
<p style="text-align: center;">Available by appointment, we can take you for a stroll through the vineyards and give you some further insight into our wine.</p>
<p style="text-align: center;">  <a href="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png"><img class="alignnone size-medium wp-image-187" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png" alt="icones_04" width="94" height="94" /></a></p>

<h4 style="text-align: center;">BBQ facilities.</h4>
<p style="text-align: center;">Bring some meat, buy some wine and enjoy the property.</p>', 'Cellar Door', '', 'publish', 'open', 'closed', '', 'cellar-door', '', '', '2014-10-21 04:59:31', '2014-10-21 04:59:31', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?page_id=11', 3, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2014-10-09 02:59:40', '2014-10-09 02:59:40', '', 'Cellar Door', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-10-09 02:59:40', '2014-10-09 02:59:40', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/?p=12', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2014-10-09 02:59:47', '2014-10-09 02:59:47', '<h3>STAY IN TOUCH</h3>
<ul>
	<li class="entypo-phone"><a href="tel:+61353564252">Phone (03) 5356 4252</a></li>
	<li class="entypo-mail">cellardoor@hallsgapestate.com.au</li>
	<li class="entypo-facebook-squared">hallsgapestate</li>
	<li class="entypo-instagrem">hallsgapestate</li>
</ul>', 'Find us', '', 'publish', 'open', 'closed', '', 'find-us', '', '', '2014-10-21 05:26:04', '2014-10-21 05:26:04', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?page_id=13', 4, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2014-10-09 02:59:47', '2014-10-09 02:59:47', '', 'Find us', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-09 02:59:47', '2014-10-09 02:59:47', '', 13, 'http://localhost:8888/FallenGiants/fallengiants/?p=14', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2014-10-09 03:00:09', '2014-10-09 03:00:09', '', 'Our wines', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-10-09 03:00:09', '2014-10-09 03:00:09', '', 7, 'http://localhost:8888/FallenGiants/fallengiants/?p=15', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2014-10-09 03:00:46', '2014-10-09 03:00:46', '', 'Our Wines', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-10-09 03:00:46', '2014-10-09 03:00:46', '', 7, 'http://localhost:8888/FallenGiants/fallengiants/?p=16', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2014-10-13 04:01:54', '2014-10-13 04:01:54', 'Contenu de la story', 'Our story', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2014-10-13 04:01:54', '2014-10-13 04:01:54', '', 9, 'http://localhost:8888/FallenGiants/fallengiants/9-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2014-10-13 04:03:41', '2014-10-13 04:03:41', 'Contenu de la home page', 'Home', '', 'inherit', 'open', 'open', '', '5-revision-v1', '', '', '2014-10-13 04:03:41', '2014-10-13 04:03:41', '', 5, 'http://localhost:8888/FallenGiants/fallengiants/5-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2014-10-13 04:03:59', '2014-10-13 04:03:59', 'Contenu des wines', 'Our Wines', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-10-13 04:03:59', '2014-10-13 04:03:59', '', 7, 'http://localhost:8888/FallenGiants/fallengiants/7-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2014-10-13 04:04:18', '2014-10-13 04:04:18', 'Trouvez nous', 'Find us', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-13 04:04:18', '2014-10-13 04:04:18', '', 13, 'http://localhost:8888/FallenGiants/fallengiants/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2014-10-13 04:04:37', '2014-10-13 04:04:37', 'Entrez dans la cave', 'Cellar Door', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-10-13 04:04:37', '2014-10-13 04:04:37', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2014-10-13 04:13:06', '2014-10-13 04:13:06', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-10-15 00:48:56', '2014-10-15 00:48:56', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=27', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2014-10-13 04:13:06', '2014-10-13 04:13:06', '', 'Our story', '', 'publish', 'open', 'open', '', 'our-story', '', '', '2014-10-15 00:48:56', '2014-10-15 00:48:56', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=28', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2014-10-13 04:13:06', '2014-10-13 04:13:06', '', 'Our wines', '', 'publish', 'open', 'open', '', 'our-wines', '', '', '2014-10-15 00:48:56', '2014-10-15 00:48:56', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=29', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2014-10-13 04:14:13', '2014-10-13 04:14:13', '', 'Cellar Door', '', 'publish', 'open', 'open', '', 'cellar-door', '', '', '2014-10-15 00:48:56', '2014-10-15 00:48:56', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=30', 7, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2014-10-13 04:14:13', '2014-10-13 04:14:13', '', 'Find us', '', 'publish', 'open', 'open', '', 'find-us', '', '', '2014-10-15 00:48:56', '2014-10-15 00:48:56', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=31', 8, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2014-10-13 04:18:44', '2014-10-13 04:18:44', '<h3>The standard Lorem Ipsum passage, used since the 1500s</h3>
"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
<h3>Section 1.10.32 of "de Finibus Bonorum et Malorum", written by Cicero in 45 BC</h3>
"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"', 'Our story', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2014-10-13 04:18:44', '2014-10-13 04:18:44', '', 9, 'http://localhost:8888/FallenGiants/fallengiants/9-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (33, 1, '2014-10-13 05:50:13', '2014-10-13 05:50:13', '', 'Shop', '', 'publish', 'closed', 'open', '', 'shop', '', '', '2014-10-13 05:50:13', '2014-10-13 05:50:13', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/shop/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2014-10-13 05:50:13', '2014-10-13 05:50:13', '[woocommerce_cart]', 'Cart', '', 'publish', 'closed', 'open', '', 'cart', '', '', '2014-10-13 05:50:13', '2014-10-13 05:50:13', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/cart/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (37, 1, '2014-10-13 05:50:13', '2014-10-13 05:50:13', '[woocommerce_checkout]', 'Checkout', '', 'publish', 'closed', 'open', '', 'checkout', '', '', '2014-10-13 05:50:13', '2014-10-13 05:50:13', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/checkout/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (39, 1, '2014-10-13 05:50:13', '2014-10-13 05:50:13', '[woocommerce_my_account]', 'My Account', '', 'publish', 'closed', 'open', '', 'my-account', '', '', '2014-10-13 05:50:13', '2014-10-13 05:50:13', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/my-account/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2014-10-13 06:49:43', '2014-10-13 06:49:43', 'From our single vineyard planted in 1969 on the eastern slopes of the Grampians. A nice even year with little in the way of heat spikes in the region. The Shiraz was picked in early April, then fermented in traditional open fermenters with hand plunging twice a day. The wine was pressed off to barrel where it matured in French oak (20% new) for 18 months before bottling. Drinking well now but will also reward cellaring to 2022.', 'Halls Gap Estate Fallen Giants Shiraz', 'The Shiraz was picked in early April, then fermented in traditional open fermenters with hand plunging twice a day.', 'publish', 'open', 'closed', '', 'shiraz-2014', '', '', '2014-10-23 08:12:09', '2014-10-23 08:12:09', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?post_type=product&#038;p=41', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2014-10-13 06:46:09', '2014-10-13 06:46:09', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you', '', '', '2014-10-13 06:46:09', '2014-10-13 06:46:09', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7174.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (43, 1, '2014-10-13 06:46:10', '2014-10-13 06:46:10', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-2', '', '', '2014-10-13 06:46:10', '2014-10-13 06:46:10', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7179.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (44, 1, '2014-10-13 06:46:11', '2014-10-13 06:46:11', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-3', '', '', '2014-10-13 06:46:11', '2014-10-13 06:46:11', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7188.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (45, 1, '2014-10-13 06:46:13', '2014-10-13 06:46:13', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-4', '', '', '2014-10-13 06:46:13', '2014-10-13 06:46:13', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7193.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (46, 1, '2014-10-13 06:46:15', '2014-10-13 06:46:15', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-5', '', '', '2014-10-13 06:46:15', '2014-10-13 06:46:15', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7196.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (47, 1, '2014-10-13 06:46:16', '2014-10-13 06:46:16', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-6', '', '', '2014-10-13 06:46:16', '2014-10-13 06:46:16', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7207.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (48, 1, '2014-10-13 06:46:17', '2014-10-13 06:46:17', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-7', '', '', '2014-10-13 06:46:17', '2014-10-13 06:46:17', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7209.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2014-10-13 06:46:18', '2014-10-13 06:46:18', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-8', '', '', '2014-10-13 06:46:18', '2014-10-13 06:46:18', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7221.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2014-10-13 06:46:19', '2014-10-13 06:46:19', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-9', '', '', '2014-10-13 06:46:19', '2014-10-13 06:46:19', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7223.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2014-10-13 06:46:21', '2014-10-13 06:46:21', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-10', '', '', '2014-10-13 06:46:21', '2014-10-13 06:46:21', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7225.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (52, 1, '2014-10-13 06:46:22', '2014-10-13 06:46:22', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-11', '', '', '2014-10-13 06:46:22', '2014-10-13 06:46:22', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7230.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2014-10-13 06:46:23', '2014-10-13 06:46:23', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-12', '', '', '2014-10-13 06:46:23', '2014-10-13 06:46:23', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7241.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2014-10-13 06:46:25', '2014-10-13 06:46:25', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-13', '', '', '2014-10-13 06:46:25', '2014-10-13 06:46:25', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7246.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (55, 1, '2014-10-13 06:46:26', '2014-10-13 06:46:26', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-14', '', '', '2014-10-13 06:46:26', '2014-10-13 06:46:26', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7254.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2014-10-13 06:46:27', '2014-10-13 06:46:27', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-15', '', '', '2014-10-13 06:46:27', '2014-10-13 06:46:27', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7266.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (57, 1, '2014-10-13 06:46:29', '2014-10-13 06:46:29', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-16', '', '', '2014-10-13 06:46:29', '2014-10-13 06:46:29', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7287.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (58, 1, '2014-10-13 06:46:30', '2014-10-13 06:46:30', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-17', '', '', '2014-10-13 06:46:30', '2014-10-13 06:46:30', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7292-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (59, 1, '2014-10-13 06:46:31', '2014-10-13 06:46:31', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-18', '', '', '2014-10-13 06:46:31', '2014-10-13 06:46:31', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7292.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (60, 1, '2014-10-13 06:46:32', '2014-10-13 06:46:32', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-19', '', '', '2014-10-13 06:46:32', '2014-10-13 06:46:32', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7306.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (61, 1, '2014-10-13 06:46:33', '2014-10-13 06:46:33', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-20', '', '', '2014-10-13 06:46:33', '2014-10-13 06:46:33', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7311-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (62, 1, '2014-10-13 06:46:35', '2014-10-13 06:46:35', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-21', '', '', '2014-10-13 06:46:35', '2014-10-13 06:46:35', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7311.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (63, 1, '2014-10-13 06:46:36', '2014-10-13 06:46:36', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-22', '', '', '2014-10-13 06:46:36', '2014-10-13 06:46:36', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7317.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (64, 1, '2014-10-13 06:46:37', '2014-10-13 06:46:37', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-23', '', '', '2014-10-13 06:46:37', '2014-10-13 06:46:37', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7327.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (65, 1, '2014-10-13 06:46:38', '2014-10-13 06:46:38', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-24', '', '', '2014-10-13 06:46:38', '2014-10-13 06:46:38', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7340.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (66, 1, '2014-10-13 06:46:40', '2014-10-13 06:46:40', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-25', '', '', '2014-10-13 06:46:40', '2014-10-13 06:46:40', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7350.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (67, 1, '2014-10-13 06:46:41', '2014-10-13 06:46:41', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-26', '', '', '2014-10-13 06:46:41', '2014-10-13 06:46:41', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7353.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (68, 1, '2014-10-13 06:46:42', '2014-10-13 06:46:42', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-27', '', '', '2014-10-13 06:46:42', '2014-10-13 06:46:42', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7356-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (69, 1, '2014-10-13 06:46:43', '2014-10-13 06:46:43', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-28', '', '', '2014-10-13 06:46:43', '2014-10-13 06:46:43', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7356.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (70, 1, '2014-10-13 06:46:44', '2014-10-13 06:46:44', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-29', '', '', '2014-10-13 06:46:44', '2014-10-13 06:46:44', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7357.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (71, 1, '2014-10-13 06:46:46', '2014-10-13 06:46:46', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-30', '', '', '2014-10-13 06:46:46', '2014-10-13 06:46:46', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7371-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (72, 1, '2014-10-13 06:46:47', '2014-10-13 06:46:47', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-31', '', '', '2014-10-13 06:46:47', '2014-10-13 06:46:47', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7371.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (73, 1, '2014-10-13 06:46:48', '2014-10-13 06:46:48', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-32', '', '', '2014-10-13 06:46:48', '2014-10-13 06:46:48', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7400-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (74, 1, '2014-10-13 06:46:49', '2014-10-13 06:46:49', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-33', '', '', '2014-10-13 06:46:49', '2014-10-13 06:46:49', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7400.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (75, 1, '2014-10-13 06:46:51', '2014-10-13 06:46:51', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-34', '', '', '2014-10-13 06:46:51', '2014-10-13 06:46:51', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7402.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (76, 1, '2014-10-13 06:46:52', '2014-10-13 06:46:52', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-35', '', '', '2014-10-13 06:46:52', '2014-10-13 06:46:52', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7407.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (77, 1, '2014-10-13 06:46:53', '2014-10-13 06:46:53', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-36', '', '', '2014-10-13 06:46:53', '2014-10-13 06:46:53', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7436-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (78, 1, '2014-10-13 06:46:55', '2014-10-13 06:46:55', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-37', '', '', '2014-10-13 06:46:55', '2014-10-13 06:46:55', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7436.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (79, 1, '2014-10-13 06:46:56', '2014-10-13 06:46:56', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-38', '', '', '2014-10-13 06:46:56', '2014-10-13 06:46:56', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7437-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2014-10-13 06:46:57', '2014-10-13 06:46:57', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-39', '', '', '2014-10-13 06:46:57', '2014-10-13 06:46:57', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7437.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2014-10-13 06:46:58', '2014-10-13 06:46:58', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-40', '', '', '2014-10-13 06:46:58', '2014-10-13 06:46:58', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7444.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (82, 1, '2014-10-13 06:46:59', '2014-10-13 06:46:59', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-41', '', '', '2014-10-13 06:46:59', '2014-10-13 06:46:59', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7448.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (83, 1, '2014-10-13 06:47:01', '2014-10-13 06:47:01', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-42', '', '', '2014-10-13 06:47:01', '2014-10-13 06:47:01', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7454.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (84, 1, '2014-10-13 06:47:02', '2014-10-13 06:47:02', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-43', '', '', '2014-10-13 06:47:02', '2014-10-13 06:47:02', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7455.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (85, 1, '2014-10-13 06:47:03', '2014-10-13 06:47:03', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-44', '', '', '2014-10-13 06:47:03', '2014-10-13 06:47:03', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7465.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (86, 1, '2014-10-13 06:47:04', '2014-10-13 06:47:04', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-45', '', '', '2014-10-13 06:47:04', '2014-10-13 06:47:04', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7474.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (87, 1, '2014-10-13 06:47:06', '2014-10-13 06:47:06', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-46', '', '', '2014-10-13 06:47:06', '2014-10-13 06:47:06', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7475.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2014-10-13 06:47:07', '2014-10-13 06:47:07', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-47', '', '', '2014-10-13 06:47:07', '2014-10-13 06:47:07', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7484-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (89, 1, '2014-10-13 06:47:08', '2014-10-13 06:47:08', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-48', '', '', '2014-10-13 06:47:08', '2014-10-13 06:47:08', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7484.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (90, 1, '2014-10-13 06:47:10', '2014-10-13 06:47:10', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-49', '', '', '2014-10-13 06:47:10', '2014-10-13 06:47:10', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7487.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2014-10-13 06:47:11', '2014-10-13 06:47:11', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-50', '', '', '2014-10-13 06:47:11', '2014-10-13 06:47:11', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7498.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2014-10-13 06:47:12', '2014-10-13 06:47:12', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-51', '', '', '2014-10-13 06:47:12', '2014-10-13 06:47:12', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7501.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (93, 1, '2014-10-13 06:47:14', '2014-10-13 06:47:14', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-52', '', '', '2014-10-13 06:47:14', '2014-10-13 06:47:14', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7515.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (94, 1, '2014-10-13 06:47:15', '2014-10-13 06:47:15', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-53', '', '', '2014-10-13 06:47:15', '2014-10-13 06:47:15', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7516.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (95, 1, '2014-10-13 06:47:17', '2014-10-13 06:47:17', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-54', '', '', '2014-10-13 06:47:17', '2014-10-13 06:47:17', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7525.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (96, 1, '2014-10-13 06:47:19', '2014-10-13 06:47:19', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-55', '', '', '2014-10-13 06:47:19', '2014-10-13 06:47:19', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7531.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2014-10-13 06:47:21', '2014-10-13 06:47:21', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-56', '', '', '2014-10-13 06:47:21', '2014-10-13 06:47:21', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7538.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2014-10-13 06:47:22', '2014-10-13 06:47:22', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-57', '', '', '2014-10-13 06:47:22', '2014-10-13 06:47:22', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7543-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (99, 1, '2014-10-13 06:47:23', '2014-10-13 06:47:23', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-58', '', '', '2014-10-13 06:47:23', '2014-10-13 06:47:23', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7543.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 1, '2014-10-13 06:47:25', '2014-10-13 06:47:25', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-59', '', '', '2014-10-13 06:47:25', '2014-10-13 06:47:25', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7550-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (101, 1, '2014-10-13 06:47:26', '2014-10-13 06:47:26', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-60', '', '', '2014-10-13 06:47:26', '2014-10-13 06:47:26', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7550.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (102, 1, '2014-10-13 06:47:27', '2014-10-13 06:47:27', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-61', '', '', '2014-10-13 06:47:27', '2014-10-13 06:47:27', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7551.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (103, 1, '2014-10-13 06:47:29', '2014-10-13 06:47:29', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-62', '', '', '2014-10-13 06:47:29', '2014-10-13 06:47:29', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7553-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (104, 1, '2014-10-13 06:47:30', '2014-10-13 06:47:30', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-63', '', '', '2014-10-13 06:47:30', '2014-10-13 06:47:30', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7553.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (105, 1, '2014-10-13 06:47:31', '2014-10-13 06:47:31', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-64', '', '', '2014-10-13 06:47:31', '2014-10-13 06:47:31', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7561-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (106, 1, '2014-10-13 06:47:32', '2014-10-13 06:47:32', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-65', '', '', '2014-10-13 06:47:32', '2014-10-13 06:47:32', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7561.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (107, 1, '2014-10-13 06:47:34', '2014-10-13 06:47:34', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-66', '', '', '2014-10-13 06:47:34', '2014-10-13 06:47:34', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7565.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (108, 1, '2014-10-13 06:47:35', '2014-10-13 06:47:35', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-67', '', '', '2014-10-13 06:47:35', '2014-10-13 06:47:35', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7566.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (109, 1, '2014-10-13 06:47:36', '2014-10-13 06:47:36', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-68', '', '', '2014-10-13 06:47:36', '2014-10-13 06:47:36', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7578.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (110, 1, '2014-10-13 06:47:37', '2014-10-13 06:47:37', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-69', '', '', '2014-10-13 06:47:37', '2014-10-13 06:47:37', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7584-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (111, 1, '2014-10-13 06:47:39', '2014-10-13 06:47:39', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-70', '', '', '2014-10-13 06:47:39', '2014-10-13 06:47:39', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7584.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (112, 1, '2014-10-13 06:47:40', '2014-10-13 06:47:40', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-71', '', '', '2014-10-13 06:47:40', '2014-10-13 06:47:40', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7588.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (113, 1, '2014-10-13 06:47:41', '2014-10-13 06:47:41', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-72', '', '', '2014-10-13 06:47:41', '2014-10-13 06:47:41', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7599-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (114, 1, '2014-10-13 06:47:42', '2014-10-13 06:47:42', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-73', '', '', '2014-10-13 06:47:42', '2014-10-13 06:47:42', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7599.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (115, 1, '2014-10-13 06:47:44', '2014-10-13 06:47:44', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-74', '', '', '2014-10-13 06:47:44', '2014-10-13 06:47:44', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7604-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (116, 1, '2014-10-13 06:47:45', '2014-10-13 06:47:45', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-75', '', '', '2014-10-13 06:47:45', '2014-10-13 06:47:45', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7604.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (117, 1, '2014-10-13 06:47:47', '2014-10-13 06:47:47', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-76', '', '', '2014-10-13 06:47:47', '2014-10-13 06:47:47', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7610.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (118, 1, '2014-10-13 06:47:49', '2014-10-13 06:47:49', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-77', '', '', '2014-10-13 06:47:49', '2014-10-13 06:47:49', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7613.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (119, 1, '2014-10-13 06:47:50', '2014-10-13 06:47:50', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-78', '', '', '2014-10-13 06:47:50', '2014-10-13 06:47:50', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7616-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (120, 1, '2014-10-13 06:47:51', '2014-10-13 06:47:51', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-79', '', '', '2014-10-13 06:47:51', '2014-10-13 06:47:51', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7616.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (121, 1, '2014-10-13 06:47:52', '2014-10-13 06:47:52', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-80', '', '', '2014-10-13 06:47:52', '2014-10-13 06:47:52', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7618.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (122, 1, '2014-10-13 06:47:54', '2014-10-13 06:47:54', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-81', '', '', '2014-10-13 06:47:54', '2014-10-13 06:47:54', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7620-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (123, 1, '2014-10-13 06:47:55', '2014-10-13 06:47:55', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-82', '', '', '2014-10-13 06:47:55', '2014-10-13 06:47:55', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7620.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (124, 1, '2014-10-13 06:47:57', '2014-10-13 06:47:57', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-83', '', '', '2014-10-13 06:47:57', '2014-10-13 06:47:57', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7622.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (125, 1, '2014-10-13 06:47:58', '2014-10-13 06:47:58', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-84', '', '', '2014-10-13 06:47:58', '2014-10-13 06:47:58', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7624.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (126, 1, '2014-10-13 06:47:59', '2014-10-13 06:47:59', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-85', '', '', '2014-10-13 06:47:59', '2014-10-13 06:47:59', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7631.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (127, 1, '2014-10-13 06:48:01', '2014-10-13 06:48:01', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-86', '', '', '2014-10-13 06:48:01', '2014-10-13 06:48:01', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7648.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (128, 1, '2014-10-13 06:48:02', '2014-10-13 06:48:02', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-87', '', '', '2014-10-13 06:48:02', '2014-10-13 06:48:02', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7650.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (129, 1, '2014-10-13 06:48:03', '2014-10-13 06:48:03', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-88', '', '', '2014-10-13 06:48:03', '2014-10-13 06:48:03', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7652.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (130, 1, '2014-10-13 06:48:04', '2014-10-13 06:48:04', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-89', '', '', '2014-10-13 06:48:04', '2014-10-13 06:48:04', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7654-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (131, 1, '2014-10-13 06:48:06', '2014-10-13 06:48:06', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-90', '', '', '2014-10-13 06:48:06', '2014-10-13 06:48:06', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7654.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (132, 1, '2014-10-13 06:48:07', '2014-10-13 06:48:07', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-91', '', '', '2014-10-13 06:48:07', '2014-10-13 06:48:07', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7656-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (133, 1, '2014-10-13 06:48:08', '2014-10-13 06:48:08', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-92', '', '', '2014-10-13 06:48:08', '2014-10-13 06:48:08', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7656.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (134, 1, '2014-10-13 06:48:09', '2014-10-13 06:48:09', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-93', '', '', '2014-10-13 06:48:09', '2014-10-13 06:48:09', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7660-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (135, 1, '2014-10-13 06:48:11', '2014-10-13 06:48:11', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-94', '', '', '2014-10-13 06:48:11', '2014-10-13 06:48:11', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7660.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (136, 1, '2014-10-13 06:48:12', '2014-10-13 06:48:12', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-95', '', '', '2014-10-13 06:48:12', '2014-10-13 06:48:12', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7678.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (137, 1, '2014-10-13 06:48:13', '2014-10-13 06:48:13', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-96', '', '', '2014-10-13 06:48:13', '2014-10-13 06:48:13', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7685-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (138, 1, '2014-10-13 06:48:14', '2014-10-13 06:48:14', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-97', '', '', '2014-10-13 06:48:14', '2014-10-13 06:48:14', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7685.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (139, 1, '2014-10-13 06:48:16', '2014-10-13 06:48:16', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-98', '', '', '2014-10-13 06:48:16', '2014-10-13 06:48:16', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7687.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (140, 1, '2014-10-13 06:48:17', '2014-10-13 06:48:17', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-99', '', '', '2014-10-13 06:48:17', '2014-10-13 06:48:17', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7689.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (141, 1, '2014-10-13 06:48:18', '2014-10-13 06:48:18', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-100', '', '', '2014-10-13 06:48:18', '2014-10-13 06:48:18', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7698-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (142, 1, '2014-10-13 06:48:20', '2014-10-13 06:48:20', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-101', '', '', '2014-10-13 06:48:20', '2014-10-13 06:48:20', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7698.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (143, 1, '2014-10-13 06:48:21', '2014-10-13 06:48:21', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-102', '', '', '2014-10-13 06:48:21', '2014-10-13 06:48:21', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7704.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (144, 1, '2014-10-13 06:48:22', '2014-10-13 06:48:22', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-103', '', '', '2014-10-13 06:48:22', '2014-10-13 06:48:22', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7705.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (145, 1, '2014-10-13 06:48:24', '2014-10-13 06:48:24', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-104', '', '', '2014-10-13 06:48:24', '2014-10-13 06:48:24', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7707.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (146, 1, '2014-10-13 06:48:25', '2014-10-13 06:48:25', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-105', '', '', '2014-10-13 06:48:25', '2014-10-13 06:48:25', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7710-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (147, 1, '2014-10-13 06:48:26', '2014-10-13 06:48:26', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-106', '', '', '2014-10-13 06:48:26', '2014-10-13 06:48:26', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7710.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (148, 1, '2014-10-13 06:48:28', '2014-10-13 06:48:28', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-107', '', '', '2014-10-13 06:48:28', '2014-10-13 06:48:28', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7711.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (149, 1, '2014-10-13 06:48:29', '2014-10-13 06:48:29', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-108', '', '', '2014-10-13 06:48:29', '2014-10-13 06:48:29', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7718.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (150, 1, '2014-10-13 06:48:30', '2014-10-13 06:48:30', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-109', '', '', '2014-10-13 06:48:30', '2014-10-13 06:48:30', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7723.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (151, 1, '2014-10-13 06:48:32', '2014-10-13 06:48:32', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-110', '', '', '2014-10-13 06:48:32', '2014-10-13 06:48:32', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7731-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (152, 1, '2014-10-13 06:48:33', '2014-10-13 06:48:33', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-111', '', '', '2014-10-13 06:48:33', '2014-10-13 06:48:33', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7731.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (153, 1, '2014-10-13 06:48:34', '2014-10-13 06:48:34', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-112', '', '', '2014-10-13 06:48:34', '2014-10-13 06:48:34', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7738-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (154, 1, '2014-10-13 06:48:36', '2014-10-13 06:48:36', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-113', '', '', '2014-10-13 06:48:36', '2014-10-13 06:48:36', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7738.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (155, 1, '2014-10-13 06:48:37', '2014-10-13 06:48:37', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-114', '', '', '2014-10-13 06:48:37', '2014-10-13 06:48:37', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7744-2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (156, 1, '2014-10-13 06:48:38', '2014-10-13 06:48:38', '', 'Ivanna Capture You', '', 'inherit', 'open', 'open', '', 'ivanna-capture-you-115', '', '', '2014-10-13 06:48:38', '2014-10-13 06:48:38', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/LR__DSC7744.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (157, 1, '2014-10-13 06:48:51', '2014-10-13 06:48:51', '', 'CAB SAV BACKGROUND', '', 'inherit', 'open', 'open', '', 'cab-sav-background', '', '', '2014-10-13 06:48:51', '2014-10-13 06:48:51', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/CAB-SAV-BACKGROUND.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (158, 1, '2014-10-13 06:48:53', '2014-10-13 06:48:53', '', 'FALLEN GIANTS LOGO BLACK', '', 'inherit', 'open', 'open', '', 'fallen-giants-logo-black', '', '', '2014-10-13 06:48:53', '2014-10-13 06:48:53', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/FALLEN-GIANTS-LOGO-BLACK.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (159, 1, '2014-10-13 06:48:54', '2014-10-13 06:48:54', '', 'FALLEN GIANTS LOGO DARK GREY', '', 'inherit', 'open', 'open', '', 'fallen-giants-logo-dark-grey', '', '', '2014-10-13 06:48:54', '2014-10-13 06:48:54', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/FALLEN-GIANTS-LOGO-DARK-GREY.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (160, 1, '2014-10-13 06:48:55', '2014-10-13 06:48:55', '', 'FALLEN GIANTS LOGO WHITE', '', 'inherit', 'open', 'open', '', 'fallen-giants-logo-white', '', '', '2014-10-13 06:48:55', '2014-10-13 06:48:55', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/FALLEN-GIANTS-LOGO-WHITE.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (161, 1, '2014-10-13 06:48:56', '2014-10-13 06:48:56', '', 'HALLS GAP ESTATE LOGO BLACK', '', 'inherit', 'open', 'open', '', 'halls-gap-estate-logo-black', '', '', '2014-10-13 06:48:56', '2014-10-13 06:48:56', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/HALLS-GAP-ESTATE-LOGO-BLACK.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (162, 1, '2014-10-13 06:48:57', '2014-10-13 06:48:57', '', 'HALLS GAP ESTATE LOGO DARK GREY', '', 'inherit', 'open', 'open', '', 'halls-gap-estate-logo-dark-grey', '', '', '2014-10-13 06:48:57', '2014-10-13 06:48:57', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/HALLS-GAP-ESTATE-LOGO-DARK-GREY.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (163, 1, '2014-10-13 06:48:58', '2014-10-13 06:48:58', '', 'HALLS GAP ESTATE LOGO WHITE', '', 'inherit', 'open', 'open', '', 'halls-gap-estate-logo-white', '', '', '2014-10-13 06:48:58', '2014-10-13 06:48:58', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/HALLS-GAP-ESTATE-LOGO-WHITE.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (164, 1, '2014-10-13 06:48:59', '2014-10-13 06:48:59', '', 'RIESLING BACKGROUND', '', 'inherit', 'open', 'open', '', 'riesling-background', '', '', '2014-10-13 06:48:59', '2014-10-13 06:48:59', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/RIESLING-BACKGROUND.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (165, 1, '2014-10-13 06:49:00', '2014-10-13 06:49:00', '', 'SHIRAZ BACKGROUND', '', 'inherit', 'open', 'open', '', 'shiraz-background', '', '', '2014-10-13 06:49:00', '2014-10-13 06:49:00', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/SHIRAZ-BACKGROUND.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (166, 1, '2014-10-13 07:02:34', '2014-10-13 07:02:34', 'From our single vineyard planted in 1969 on the eastern slopes of the Grampians. A nice even year with little in the way of heat spikes in the region. The Shiraz was picked in early April, then fermented in traditional open fermenters with hand plunging twice a day. The wine was pressed off to barrel where it matured in French oak (20% new) for 18 months before bottling. Drinking well now but will also reward cellaring to 2022.', 'Halls Gap Estate Fallen Giants Riesling', 'From our single vineyard planted in 1969 on the eastern slopes of the Grampians. A nice even year with little in the way of heat spikes in the region. The Shiraz was picked in early April, then fermented in traditional open fermenters with hand plunging twice a day. The wine was pressed off to barrel where it matured in French oak (20% new) for 18 months before bottling. Drinking well now but will also reward cellaring to 2022.', 'publish', 'open', 'closed', '', 'riesling-2014', '', '', '2014-10-23 05:47:11', '2014-10-23 05:47:11', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/product/riesling-2014/', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (167, 1, '2014-10-13 07:03:16', '2014-10-13 07:03:16', 'The cabernet was planted along with the Shiraz in 1969. Harvested at the end of April, the Fallen Giants block is very low yielding producing 1.4 tonne to the acre.

The Cabernet was fermented in open fermenters with a long cold soak and extended maceration. Plunging was done twice a day ensuring nice colour and fine tannin.', 'Halls Gap Estate Fallen Giants Cabernet', 'The Cabernet was fermented in open fermenters with a long cold soak and extended maceration.', 'publish', 'open', 'closed', '', 'cabernet-sauvignon-2014', '', '', '2014-10-23 22:39:32', '2014-10-23 22:39:32', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/product/cabernet-sauvignon-2014/', 0, 'product', '', 1) ; 
INSERT INTO `wp_posts` VALUES (168, 1, '2014-10-14 00:49:00', '2014-10-14 00:49:00', '', 'Order &ndash; October 14, 2014 @ 12:49 AM', '', 'wc-completed', 'closed', 'closed', 'order_543c7320444ca', 'order-oct-14-2014-1249-am', '', '', '2014-10-14 00:56:41', '2014-10-14 00:56:41', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?post_type=shop_order&#038;p=168', 0, 'shop_order', '', 2) ; 
INSERT INTO `wp_posts` VALUES (169, 1, '2014-10-14 03:22:13', '2014-10-14 03:22:13', '', 'Our story', '', 'inherit', 'open', 'open', '', '9-autosave-v1', '', '', '2014-10-14 03:22:13', '2014-10-14 03:22:13', '', 9, 'http://localhost:8888/FallenGiants/fallengiants/9-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (170, 1, '2014-10-14 03:25:48', '2014-10-14 03:25:48', 'Our vineyard was planted on the steep Eastern slopes of the Grampians in 1969. It represented part of the second coming of the Victorian wine industry which had seen very little new plantings since the turn of the century. The region had always had a pedigree for great wines with the first vineyards in Grampians being planted at Bests &amp; Seppelts, in the early 1860’s.

The vineyard has long been a respected grower for many of the countries great wineries until 1996, when it was bought by the famed Victorian Winemaker, the late, great <i>Trevor Mast</i>, and has been a staple of Mount Langi Ghiran ever since.

Our family bought it in 2013 and re named the vineyard <i>Fallen Giants</i> after the dreamtime stories of the original owners of these land, the <i>Djab Wurrung</i> and <i>Jardiwadjali</i> people. According to the legends, <i>Geriward</i> (the Grampians) was created by the great Ancestor spirit <i>Bunjil</i>, who often took the form of a great Eagle. The ranges were then further shaped by Tchingal a Giant ferocious Emu, who split the mountains with his fierce kick.

<b>The Vineyard</b>

The vineyard was planted in 1969 to Shiraz, Cabernet &amp; Riesling totalling 23 acres under vine. The majority of the planting is Shiraz (14 acres).

A cooler site being at high elevation (260M) and East facing in aspect. Mean January Temperature (MJT) 20.6 degrees C

<strong>The soil is red clay loam. It is old, dating back 380 million years ago to the Devion period. As the soils are old and weathered the vines are naturally low yielding.</strong>', 'Our story', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2014-10-14 03:25:48', '2014-10-14 03:25:48', '', 9, 'http://localhost:8888/FallenGiants/fallengiants/9-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (171, 1, '2014-10-14 23:51:33', '2014-10-14 23:51:33', 'From our single vineyard planted in 1969 on the eastern slopes of the Grampians. A nice even year with little in the way of heat spikes in the region. The Shiraz was picked in early April, then fermented in traditional open fermenters with hand plunging twice a day. The wine was pressed off to barrel where it matured in French oak (20% new) for 18 months before bottling. Drinking well now but will also reward cellaring to 2022.', 'SHIRAZ 2014', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
', 'inherit', 'open', 'open', '', '41-autosave-v1', '', '', '2014-10-14 23:51:33', '2014-10-14 23:51:33', '', 41, 'http://localhost:8888/FallenGiants/fallengiants/41-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (172, 1, '2014-10-15 00:47:24', '2014-10-15 00:47:24', ' ', '', '', 'publish', 'open', 'open', '', '172', '', '', '2014-10-15 00:47:24', '2014-10-15 00:47:24', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=172', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (173, 1, '2014-10-15 00:47:24', '2014-10-15 00:47:24', ' ', '', '', 'publish', 'open', 'open', '', '173', '', '', '2014-10-15 00:47:24', '2014-10-15 00:47:24', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=173', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (174, 1, '2014-10-15 00:47:24', '2014-10-15 00:47:24', ' ', '', '', 'publish', 'open', 'open', '', '174', '', '', '2014-10-15 00:47:24', '2014-10-15 00:47:24', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=174', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (175, 1, '2014-10-15 00:47:24', '2014-10-15 00:47:24', ' ', '', '', 'publish', 'open', 'open', '', '175', '', '', '2014-10-15 00:47:24', '2014-10-15 00:47:24', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=175', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (176, 1, '2014-10-15 00:48:37', '2014-10-15 00:48:37', ' ', '', '', 'publish', 'open', 'open', '', '176', '', '', '2014-10-15 00:48:56', '2014-10-15 00:48:56', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=176', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (177, 1, '2014-10-15 00:48:37', '2014-10-15 00:48:37', ' ', '', '', 'publish', 'open', 'open', '', '177', '', '', '2014-10-15 00:48:56', '2014-10-15 00:48:56', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=177', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (178, 1, '2014-10-15 00:48:37', '2014-10-15 00:48:37', ' ', '', '', 'publish', 'open', 'open', '', '178', '', '', '2014-10-15 00:48:56', '2014-10-15 00:48:56', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=178', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (179, 1, '2014-10-15 05:04:53', '2014-10-15 05:04:53', 'Trouvez nous

[ready_google_map id=\'1\']', 'Find us', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-15 05:04:53', '2014-10-15 05:04:53', '', 13, 'http://localhost:8888/FallenGiants/fallengiants/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (180, 1, '2014-10-15 05:09:55', '2014-10-15 05:09:55', 'Trouvez nous

[wpgmza id="1"]', 'Find us', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-15 05:09:55', '2014-10-15 05:09:55', '', 13, 'http://localhost:8888/FallenGiants/fallengiants/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (181, 1, '2014-10-15 05:31:26', '2014-10-15 05:31:26', '<a href="tel:+61353564252">Phone (03) 5356 4252</a>

cellardoor@hallsgapestate.com.au

facebook: hallsgapestate

Instagram: hallsgapestate', 'Find us', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-15 05:31:26', '2014-10-15 05:31:26', '', 13, 'http://localhost:8888/FallenGiants/fallengiants/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (182, 1, '2014-10-15 05:34:53', '2014-10-15 05:34:53', 'With amazing views over the Grampians and our vineyards, our Cellar door is the perfect place to 

taste and enjoy our wine. With a kids playground as well...plan to stay a while

- Free wine tastings.

- Cheese platters. Sit on the deck with a glass of our wine and enjoy some local produce.

- Enjoy a picnic. Borrow a picnic blanket and plant yourself among the vines with a bottle of 

our wine for the afternoon!

- Vineyard tours. Available by appointment, we can take you for a stroll through the vineyards 

and give you some further insight into our wine.

- BBQ facilities. Bring some meat, buy some wine and enjoy the property.', 'Cellar Door', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-10-15 05:34:53', '2014-10-15 05:34:53', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (183, 1, '2014-10-21 04:37:12', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-21 04:37:12', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/FallenGiants/fallengiants/?p=183', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (184, 1, '2014-10-21 04:38:00', '2014-10-21 04:38:00', '', 'icones_01', '', 'inherit', 'open', 'open', '', 'icones_01', '', '', '2014-10-21 04:38:00', '2014-10-21 04:38:00', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_01.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (185, 1, '2014-10-21 04:38:01', '2014-10-21 04:38:01', '', 'icones_02', '', 'inherit', 'open', 'open', '', 'icones_02', '', '', '2014-10-21 04:38:01', '2014-10-21 04:38:01', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_02.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (186, 1, '2014-10-21 04:38:01', '2014-10-21 04:38:01', '', 'icones_03', '', 'inherit', 'open', 'open', '', 'icones_03', '', '', '2014-10-21 04:38:01', '2014-10-21 04:38:01', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_03.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (187, 1, '2014-10-21 04:38:02', '2014-10-21 04:38:02', '', 'icones_04', '', 'inherit', 'open', 'open', '', 'icones_04', '', '', '2014-10-21 04:38:02', '2014-10-21 04:38:02', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (188, 1, '2014-10-21 04:38:02', '2014-10-21 04:38:02', '', 'icones_05', '', 'inherit', 'open', 'open', '', 'icones_05', '', '', '2014-10-21 04:38:02', '2014-10-21 04:38:02', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_05.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (189, 1, '2014-10-21 04:38:03', '2014-10-21 04:38:03', '', 'icones_06', '', 'inherit', 'open', 'open', '', 'icones_06', '', '', '2014-10-21 04:38:03', '2014-10-21 04:38:03', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_06.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (190, 1, '2014-10-21 04:38:04', '2014-10-21 04:38:04', '', 'icones_07', '', 'inherit', 'open', 'open', '', 'icones_07', '', '', '2014-10-21 04:38:04', '2014-10-21 04:38:04', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_07.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (191, 1, '2014-10-21 04:46:12', '2014-10-21 04:46:12', '<p style="text-align: center;">With amazing views over the Grampians and our vineyards, our Cellar door is the perfect place to taste and enjoy our wine. With a kids playground as well...plan to stay a while.</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-188" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_05.png" alt="icones_05" width="94" height="94" /></p>

<h4 style="text-align: center;">Free wine tastings.</h4>
<p style="text-align: center;"><img class="alignnone size-full wp-image-189" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_06.png" alt="icones_06" width="94" height="94" /></p>

<h4 style="text-align: center;">Cheese platters.</h4>
<p style="text-align: center;">Sit on the deck with a glass of our wine and enjoy some local produce.</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-186" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_03.png" alt="icones_03" width="94" height="94" /></p>

<h4 style="text-align: center;">Enjoy a picnic.</h4>
<p style="text-align: center;">Borrow a picnic blanket and plant yourself among the vines with a bottle of our wine for the afternoon!</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-185" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_02.png" alt="icones_02" width="94" height="94" /></p>

<h4 style="text-align: center;">Vineyard tours.</h4>
<p style="text-align: center;">Available by appointment, we can take you for a stroll through the vineyards and give you some further insight into our wine.</p>
<p style="text-align: center;">  <a href="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png"><img class="alignnone size-medium wp-image-187" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png" alt="icones_04" width="94" height="94" /></a></p>
<p style="text-align: center;">BBQ facilities.</p>
<p style="text-align: center;">Bring some meat, buy some wine and enjoy the property.</p>', 'Cellar Door', '', 'inherit', 'open', 'open', '', '11-autosave-v1', '', '', '2014-10-21 04:46:12', '2014-10-21 04:46:12', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/11-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (192, 1, '2014-10-21 04:39:37', '2014-10-21 04:39:37', '<p style="text-align: center;">With amazing views over the Grampians and our vineyards, our Cellar door is the perfect place to</p>
<p style="text-align: center;">taste and enjoy our wine. With a kids playground as well...plan to stay a while</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-188" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_05.png" alt="icones_05" width="94" height="94" /></p>
<p style="text-align: center;">Free wine tastings.</p>
<p style="text-align: center;"><img class="alignnone size-full wp-image-189" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_06.png" alt="icones_06" width="94" height="94" /></p>
<p style="text-align: center;">Cheese platters.</p>
<p style="text-align: center;">Sit on the deck with a glass of our wine and enjoy some local produce.</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-186" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_03.png" alt="icones_03" width="94" height="94" /></p>
<p style="text-align: center;">Enjoy a picnic.</p>
<p style="text-align: center;">Borrow a picnic blanket and plant yourself among the vines with a bottle of</p>
<p style="text-align: center;">our wine for the afternoon!</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-185" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_02.png" alt="icones_02" width="94" height="94" /></p>
<p style="text-align: center;">Vineyard tours.</p>
<p style="text-align: center;">Available by appointment, we can take you for a stroll through the vineyards</p>
<p style="text-align: center;">and give you some further insight into our wine.</p>
<p style="text-align: center;">  <a href="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png"><img class="alignnone size-medium wp-image-187" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png" alt="icones_04" width="94" height="94" /></a></p>
<p style="text-align: center;">BBQ facilities.</p>
<p style="text-align: center;">Bring some meat, buy some wine and enjoy the property.</p>', 'Cellar Door', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-10-21 04:39:37', '2014-10-21 04:39:37', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (193, 1, '2014-10-21 04:46:16', '2014-10-21 04:46:16', '<p style="text-align: center;">With amazing views over the Grampians and our vineyards, our Cellar door is the perfect place to taste and enjoy our wine. With a kids playground as well...plan to stay a while.</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-188" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_05.png" alt="icones_05" width="94" height="94" /></p>

<h4 style="text-align: center;">Free wine tastings.</h4>
<p style="text-align: center;"><img class="alignnone size-full wp-image-189" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_06.png" alt="icones_06" width="94" height="94" /></p>

<h4 style="text-align: center;">Cheese platters.</h4>
<p style="text-align: center;">Sit on the deck with a glass of our wine and enjoy some local produce.</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-186" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_03.png" alt="icones_03" width="94" height="94" /></p>

<h4 style="text-align: center;">Enjoy a picnic.</h4>
<p style="text-align: center;">Borrow a picnic blanket and plant yourself among the vines with a bottle of our wine for the afternoon!</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-185" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_02.png" alt="icones_02" width="94" height="94" /></p>

<h4 style="text-align: center;">Vineyard tours.</h4>
<p style="text-align: center;">Available by appointment, we can take you for a stroll through the vineyards and give you some further insight into our wine.</p>
<p style="text-align: center;">  <a href="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png"><img class="alignnone size-medium wp-image-187" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png" alt="icones_04" width="94" height="94" /></a></p>

<h4 style="text-align: center;">BBQ facilities.</h4>
<p style="text-align: center;">Bring some meat, buy some wine and enjoy the property.</p>', 'Cellar Door', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-10-21 04:46:16', '2014-10-21 04:46:16', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (194, 1, '2014-10-21 04:54:44', '2014-10-21 04:54:44', '', 'Cellar', '', 'inherit', 'open', 'open', '', 'cellar', '', '', '2014-10-21 04:54:44', '2014-10-21 04:54:44', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/Cellar.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (195, 1, '2014-10-21 04:55:08', '2014-10-21 04:55:08', '<p style="text-align: center;"><a href="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/Cellar.png"><img class="alignnone  wp-image-194" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/Cellar-300x87.png" alt="Cellar" width="369" height="112" /></a></p>
<p style="text-align: center;"></p>
<p style="text-align: center;"></p>
<p style="text-align: center;">With amazing views over the Grampians and our vineyards, our Cellar door is the perfect place to taste and enjoy our wine. With a kids playground as well...plan to stay a while.</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-188" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_05.png" alt="icones_05" width="94" height="94" /></p>

<h4 style="text-align: center;">Free wine tastings.</h4>
<p style="text-align: center;"><img class="alignnone size-full wp-image-189" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_06.png" alt="icones_06" width="94" height="94" /></p>

<h4 style="text-align: center;">Cheese platters.</h4>
<p style="text-align: center;">Sit on the deck with a glass of our wine and enjoy some local produce.</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-186" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_03.png" alt="icones_03" width="94" height="94" /></p>

<h4 style="text-align: center;">Enjoy a picnic.</h4>
<p style="text-align: center;">Borrow a picnic blanket and plant yourself among the vines with a bottle of our wine for the afternoon!</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-185" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_02.png" alt="icones_02" width="94" height="94" /></p>

<h4 style="text-align: center;">Vineyard tours.</h4>
<p style="text-align: center;">Available by appointment, we can take you for a stroll through the vineyards and give you some further insight into our wine.</p>
<p style="text-align: center;">  <a href="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png"><img class="alignnone size-medium wp-image-187" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png" alt="icones_04" width="94" height="94" /></a></p>

<h4 style="text-align: center;">BBQ facilities.</h4>
<p style="text-align: center;">Bring some meat, buy some wine and enjoy the property.</p>', 'Cellar Door', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-10-21 04:55:08', '2014-10-21 04:55:08', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (196, 1, '2014-10-21 04:55:43', '2014-10-21 04:55:43', '<p style="text-align: center;"><a href="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/Cellar.png"><img class="alignnone  wp-image-194" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/Cellar-300x87.png" alt="Cellar" width="369" height="112" /></a></p>
<p style="text-align: center;"></p>
<p style="text-align: center;"></p>
<p style="text-align: center;"></p>
<p style="text-align: center;">With amazing views over the Grampians and our vineyards, our Cellar door is the perfect place to taste and enjoy our wine. With a kids playground as well...plan to stay a while.</p>
<p style="text-align: center;"></p>
<p style="text-align: center;"></p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-188" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_05.png" alt="icones_05" width="94" height="94" /></p>

<h4 style="text-align: center;">Free wine tastings.</h4>
<p style="text-align: center;"><img class="alignnone size-full wp-image-189" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_06.png" alt="icones_06" width="94" height="94" /></p>

<h4 style="text-align: center;">Cheese platters.</h4>
<p style="text-align: center;">Sit on the deck with a glass of our wine and enjoy some local produce.</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-186" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_03.png" alt="icones_03" width="94" height="94" /></p>

<h4 style="text-align: center;">Enjoy a picnic.</h4>
<p style="text-align: center;">Borrow a picnic blanket and plant yourself among the vines with a bottle of our wine for the afternoon!</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-185" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_02.png" alt="icones_02" width="94" height="94" /></p>

<h4 style="text-align: center;">Vineyard tours.</h4>
<p style="text-align: center;">Available by appointment, we can take you for a stroll through the vineyards and give you some further insight into our wine.</p>
<p style="text-align: center;">  <a href="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png"><img class="alignnone size-medium wp-image-187" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png" alt="icones_04" width="94" height="94" /></a></p>

<h4 style="text-align: center;">BBQ facilities.</h4>
<p style="text-align: center;">Bring some meat, buy some wine and enjoy the property.</p>', 'Cellar Door', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-10-21 04:55:43', '2014-10-21 04:55:43', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (197, 1, '2014-10-21 04:59:15', '2014-10-21 04:59:15', '<p style="text-align: center;"><a href="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/Cellar.png"><img class="alignnone  wp-image-194" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/Cellar-300x87.png" alt="Cellar" width="369" height="112" /></a></p>
<p style="text-align: center;">With amazing views over the Grampians and our vineyards, our Cellar door is the perfect place to taste and enjoy our wine. With a kids playground as well...plan to stay a while.</p>
<p style="text-align: center;"><img class="icone alignnone wp-image-188 size-full" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_05.png" alt="icones_05" width="94" height="94" /></p>

<h4 style="text-align: center;">Free wine tastings.</h4>
<p style="text-align: center;"><img class="alignnone size-full wp-image-189" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_06.png" alt="icones_06" width="94" height="94" /></p>

<h4 style="text-align: center;">Cheese platters.</h4>
<p style="text-align: center;">Sit on the deck with a glass of our wine and enjoy some local produce.</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-186" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_03.png" alt="icones_03" width="94" height="94" /></p>

<h4 style="text-align: center;">Enjoy a picnic.</h4>
<p style="text-align: center;">Borrow a picnic blanket and plant yourself among the vines with a bottle of our wine for the afternoon!</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-185" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_02.png" alt="icones_02" width="94" height="94" /></p>

<h4 style="text-align: center;">Vineyard tours.</h4>
<p style="text-align: center;">Available by appointment, we can take you for a stroll through the vineyards and give you some further insight into our wine.</p>
<p style="text-align: center;">  <a href="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png"><img class="alignnone size-medium wp-image-187" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png" alt="icones_04" width="94" height="94" /></a></p>

<h4 style="text-align: center;">BBQ facilities.</h4>
<p style="text-align: center;">Bring some meat, buy some wine and enjoy the property.</p>', 'Cellar Door', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-10-21 04:59:15', '2014-10-21 04:59:15', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (198, 1, '2014-10-21 04:59:31', '2014-10-21 04:59:31', '<p style="text-align: center;"></p>
<p style="text-align: center;">With amazing views over the Grampians and our vineyards, our Cellar door is the perfect place to taste and enjoy our wine. With a kids playground as well...plan to stay a while.</p>
<p style="text-align: center;"><img class="icone alignnone wp-image-188 size-full" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_05.png" alt="icones_05" width="94" height="94" /></p>

<h4 style="text-align: center;">Free wine tastings.</h4>
<p style="text-align: center;"><img class="alignnone size-full wp-image-189" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_06.png" alt="icones_06" width="94" height="94" /></p>

<h4 style="text-align: center;">Cheese platters.</h4>
<p style="text-align: center;">Sit on the deck with a glass of our wine and enjoy some local produce.</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-186" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_03.png" alt="icones_03" width="94" height="94" /></p>

<h4 style="text-align: center;">Enjoy a picnic.</h4>
<p style="text-align: center;">Borrow a picnic blanket and plant yourself among the vines with a bottle of our wine for the afternoon!</p>
<p style="text-align: center;"><img class="alignnone size-medium wp-image-185" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_02.png" alt="icones_02" width="94" height="94" /></p>

<h4 style="text-align: center;">Vineyard tours.</h4>
<p style="text-align: center;">Available by appointment, we can take you for a stroll through the vineyards and give you some further insight into our wine.</p>
<p style="text-align: center;">  <a href="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png"><img class="alignnone size-medium wp-image-187" src="http://localhost:8888/FallenGiants/fallengiants/wp-content/uploads/2014/10/icones_04.png" alt="icones_04" width="94" height="94" /></a></p>

<h4 style="text-align: center;">BBQ facilities.</h4>
<p style="text-align: center;">Bring some meat, buy some wine and enjoy the property.</p>', 'Cellar Door', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-10-21 04:59:31', '2014-10-21 04:59:31', '', 11, 'http://localhost:8888/FallenGiants/fallengiants/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (199, 1, '2014-10-21 05:06:15', '2014-10-21 05:06:15', '<h3>STAY IN TOUCH</h3>
<a href="tel:+61353564252">Phone (03) 5356 4252</a>

cellardoor@hallsgapestate.com.au

facebook: hallsgapestate

Instagram: hallsgapestate', 'Find us', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-21 05:06:15', '2014-10-21 05:06:15', '', 13, 'http://localhost:8888/FallenGiants/fallengiants/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (200, 1, '2014-10-21 05:09:23', '2014-10-21 05:09:23', '<h3>STAY IN TOUCH</h3>
<a href="tel:+61353564252">Phone (03) 5356 4252</a>

cellardoor@hallsgapestate.com.au

F hallsgapestate

I hallsgapestate', 'Find us', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-21 05:09:23', '2014-10-21 05:09:23', '', 13, 'http://localhost:8888/FallenGiants/fallengiants/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (201, 1, '2014-10-21 05:16:56', '2014-10-21 05:16:56', '<h3>STAY IN TOUCH</h3>
<a href="tel:+61353564252">Phone (03) 5356 4252</a>

cellardoor@hallsgapestate.com.au

<li class="brandico-instagram-filled">hallsgapestate</li>

I hallsgapestate', 'Find us', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-21 05:16:56', '2014-10-21 05:16:56', '', 13, 'http://localhost:8888/FallenGiants/fallengiants/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (202, 1, '2014-10-21 05:23:10', '2014-10-21 05:23:10', '<h3>STAY IN TOUCH</h3>
<ul>
<li class="entypo-phone"><a href="tel:+61353564252">Phone (03) 5356 4252</a>
</li>

<li class="entypo-mail">cellardoor@hallsgapestate.com.au
</li>
<li class="entypo-facebook-squared">hallsgapestate</li>
</li>
<li class="brandico-instagram-filled">hallsgapestate</li>
</li>
</ul>

brandico-facebook-rect
I hallsgapestate', 'Find us', '', 'inherit', 'open', 'open', '', '13-autosave-v1', '', '', '2014-10-21 05:23:10', '2014-10-21 05:23:10', '', 13, 'http://localhost:8888/FallenGiants/fallengiants/13-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (203, 1, '2014-10-21 05:24:55', '2014-10-21 05:24:55', '<h3>STAY IN TOUCH</h3>
<ul>
<li class="entypo-phone"><a href="tel:+61353564252">Phone (03) 5356 4252</a>
</li>

<li class="entypo-mail">cellardoor@hallsgapestate.com.au
</li>
<li class="entypo-facebook-squared">hallsgapestate</li>
</li>
<li class="entypo-instagrem">hallsgapestate</li>
</li>
</ul>

brandico-facebook-rect
I hallsgapestate', 'Find us', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-21 05:24:55', '2014-10-21 05:24:55', '', 13, 'http://localhost:8888/FallenGiants/fallengiants/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (204, 1, '2014-10-21 05:26:04', '2014-10-21 05:26:04', '<h3>STAY IN TOUCH</h3>
<ul>
	<li class="entypo-phone"><a href="tel:+61353564252">Phone (03) 5356 4252</a></li>
	<li class="entypo-mail">cellardoor@hallsgapestate.com.au</li>
	<li class="entypo-facebook-squared">hallsgapestate</li>
	<li class="entypo-instagrem">hallsgapestate</li>
</ul>', 'Find us', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-21 05:26:04', '2014-10-21 05:26:04', '', 13, 'http://localhost:8888/FallenGiants/fallengiants/13-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (28 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (27, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (28, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (29, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (30, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (31, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 16, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (166, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (166, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (166, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (166, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (166, 15, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (167, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (167, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (167, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (167, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (167, 17, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (172, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (173, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (174, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (175, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (176, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (177, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (178, 2, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (17 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 8) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'product_type', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'product_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'product_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (6, 6, 'product_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 7, 'nav_menu', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (8, 8, 'product_cat', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (9, 9, 'pa_vintage', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (10, 10, 'pa_vintage', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (11, 11, 'pa_vintage', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (12, 12, 'pa_variety', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (13, 13, 'pa_vineyard', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (14, 14, 'pa_winery', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (15, 15, 'pa_variety', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (16, 16, 'pa_variety', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (17, 17, 'pa_variety', '', 0, 1) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (17 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Main', 'main', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'simple', 'simple', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'grouped', 'grouped', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'variable', 'variable', 0) ; 
INSERT INTO `wp_terms` VALUES (6, 'external', 'external', 0) ; 
INSERT INTO `wp_terms` VALUES (7, 'E-business', 'e-business', 0) ; 
INSERT INTO `wp_terms` VALUES (8, 'Vintage', 'vintage', 0) ; 
INSERT INTO `wp_terms` VALUES (9, '2012', '2012', 0) ; 
INSERT INTO `wp_terms` VALUES (10, '2013', '2013', 0) ; 
INSERT INTO `wp_terms` VALUES (11, '2014', '2014', 0) ; 
INSERT INTO `wp_terms` VALUES (12, 'Cabernet-Sauvignon', 'cabernet-sauvignon', 0) ; 
INSERT INTO `wp_terms` VALUES (13, 'Fallen Giants', 'fallen-giants', 0) ; 
INSERT INTO `wp_terms` VALUES (14, 'Halls Gap Estate', 'halls-gap-estate', 0) ; 
INSERT INTO `wp_terms` VALUES (15, 'Riesling', 'riesling', 0) ; 
INSERT INTO `wp_terms` VALUES (16, 'Shiraz', 'shiraz', 0) ; 
INSERT INTO `wp_terms` VALUES (17, 'Cabernet', 'cabernet', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (48 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin_fg') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '183') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'session_tokens', 'a:4:{s:64:"b6f8a851b56b798dde1bef357ef1b2fbdf0314026b4809075961665fb59e9482";i:1414377514;s:64:"723bbe4d56ff4f02a51b763281908ffd8bc26299cea1da549a7fa8ce42a5e640";i:1414377514;s:64:"55153277dd2673692510616e6fe544fda01a9dfe7a7a9a0727bde06b8fed310f";i:1415082139;s:64:"d60e61fb7a8d6a524f59e605b70a21f17bb5f0ad1e614cd6b519550be70244ac";i:1415082171;}') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'nav_menu_recently_edited', '2') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'closedpostboxes_page', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'metaboxhidden_page', 'a:5:{i:0;s:12:"revisionsdiv";i:1;s:10:"postcustom";i:2;s:16:"commentstatusdiv";i:3;s:11:"commentsdiv";i:4;s:9:"authordiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (22, 1, 'wp_user-settings', 'editor_expand=off&libraryContent=upload&editor=tinymce&hidetb=1&advImgDetails=show') ; 
INSERT INTO `wp_usermeta` VALUES (23, 1, 'wp_user-settings-time', '1413869160') ; 
INSERT INTO `wp_usermeta` VALUES (24, 1, 'billing_country', 'AU') ; 
INSERT INTO `wp_usermeta` VALUES (25, 1, 'billing_first_name', 'Alex') ; 
INSERT INTO `wp_usermeta` VALUES (26, 1, 'billing_last_name', 'Chavet') ; 
INSERT INTO `wp_usermeta` VALUES (27, 1, 'billing_company', 'alexchavetbuyer') ; 
INSERT INTO `wp_usermeta` VALUES (28, 1, 'billing_address_1', '11 test street') ; 
INSERT INTO `wp_usermeta` VALUES (29, 1, 'billing_address_2', '') ; 
INSERT INTO `wp_usermeta` VALUES (30, 1, 'billing_city', 'Melbourne') ; 
INSERT INTO `wp_usermeta` VALUES (31, 1, 'billing_state', 'VIC') ; 
INSERT INTO `wp_usermeta` VALUES (32, 1, 'billing_postcode', '3054') ; 
INSERT INTO `wp_usermeta` VALUES (33, 1, 'billing_email', 'alex.chavet.buyer@gmail.com') ; 
INSERT INTO `wp_usermeta` VALUES (34, 1, 'billing_phone', '0449632345') ; 
INSERT INTO `wp_usermeta` VALUES (35, 1, 'shipping_country', 'AU') ; 
INSERT INTO `wp_usermeta` VALUES (36, 1, 'shipping_first_name', 'Alex') ; 
INSERT INTO `wp_usermeta` VALUES (37, 1, 'shipping_last_name', 'Chavet') ; 
INSERT INTO `wp_usermeta` VALUES (38, 1, 'shipping_company', 'alexchavetbuyer') ; 
INSERT INTO `wp_usermeta` VALUES (39, 1, 'shipping_address_1', '11 test street') ; 
INSERT INTO `wp_usermeta` VALUES (40, 1, 'shipping_address_2', '') ; 
INSERT INTO `wp_usermeta` VALUES (41, 1, 'shipping_city', 'Melbourne') ; 
INSERT INTO `wp_usermeta` VALUES (42, 1, 'shipping_state', 'VIC') ; 
INSERT INTO `wp_usermeta` VALUES (43, 1, 'shipping_postcode', '3054') ; 
INSERT INTO `wp_usermeta` VALUES (44, 1, 'paying_customer', '1') ; 
INSERT INTO `wp_usermeta` VALUES (45, 1, '_money_spent', '140') ; 
INSERT INTO `wp_usermeta` VALUES (46, 1, '_order_count', '1') ; 
INSERT INTO `wp_usermeta` VALUES (47, 1, '_woocommerce_persistent_cart', 'a:1:{s:4:"cart";a:0:{}}') ; 
INSERT INTO `wp_usermeta` VALUES (48, 1, 'closedpostboxes_product', 'a:1:{i:0;s:10:"postcustom";}') ; 
INSERT INTO `wp_usermeta` VALUES (49, 1, 'metaboxhidden_product', 'a:1:{i:0;s:7:"slugdiv";}') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'admin_fg', '$P$BQLm54anIyNYMbBOm3FV5m/6laMLsm1', 'admin_fg', 'alex.chavet@gmail.com', '', '2014-10-09 02:56:00', '', 0, 'admin_fg') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wp_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) NOT NULL,
  `attribute_label` longtext,
  `attribute_type` varchar(200) NOT NULL,
  `attribute_orderby` varchar(200) NOT NULL,
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_attribute_taxonomies (4 records)
#
 
INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES (1, 'vintage', 'Vintage', 'select', 'menu_order') ; 
INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES (2, 'variety', 'Variety', 'text', 'menu_order') ; 
INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES (3, 'vineyard', 'Vineyard', 'text', 'menu_order') ; 
INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES (4, 'winery', 'Winery', 'text', 'menu_order') ;
#
# End of data contents of table wp_woocommerce_attribute_taxonomies
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wp_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_id` varchar(32) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL DEFAULT '0',
  `order_key` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `downloads_remaining` varchar(9) DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`,`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_downloadable_product_permissions (0 records)
#

#
# End of data contents of table wp_woocommerce_downloadable_product_permissions
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;


#
# Table structure of table `wp_woocommerce_order_itemmeta`
#

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_order_itemmeta (12 records)
#
 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (25, 5, '_qty', '7') ; 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (26, 5, '_tax_class', '') ; 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (27, 5, '_product_id', '167') ; 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (28, 5, '_variation_id', '0') ; 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (29, 5, '_line_subtotal', '140') ; 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (30, 5, '_line_total', '140') ; 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (31, 5, '_line_subtotal_tax', '0') ; 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (32, 5, '_line_tax', '0') ; 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (33, 5, '_line_tax_data', 'a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}') ; 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (34, 6, 'method_id', 'free_shipping') ; 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (35, 6, 'cost', '0') ; 
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (36, 6, 'taxes', 'a:0:{}') ;
#
# End of data contents of table wp_woocommerce_order_itemmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;


#
# Table structure of table `wp_woocommerce_order_items`
#

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_name` longtext NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT '',
  `order_id` bigint(20) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_order_items (2 records)
#
 
INSERT INTO `wp_woocommerce_order_items` VALUES (5, 'CABERNET SAUVIGNON 2014', 'line_item', 168) ; 
INSERT INTO `wp_woocommerce_order_items` VALUES (6, 'Free Shipping', 'shipping', 168) ;
#
# End of data contents of table wp_woocommerce_order_items
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;


#
# Table structure of table `wp_woocommerce_tax_rate_locations`
#

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `location_code` varchar(255) NOT NULL,
  `tax_rate_id` bigint(20) NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type` (`location_type`),
  KEY `location_type_code` (`location_type`,`location_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_tax_rate_locations (0 records)
#

#
# End of data contents of table wp_woocommerce_tax_rate_locations
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;


#
# Table structure of table `wp_woocommerce_tax_rates`
#

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) NOT NULL DEFAULT '',
  `tax_rate` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) NOT NULL,
  `tax_rate_class` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`),
  KEY `tax_rate_class` (`tax_rate_class`),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_tax_rates (0 records)
#

#
# End of data contents of table wp_woocommerce_tax_rates
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_termmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_termmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_termmeta`;


#
# Table structure of table `wp_woocommerce_termmeta`
#

CREATE TABLE `wp_woocommerce_termmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `woocommerce_term_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `woocommerce_term_id` (`woocommerce_term_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_termmeta (12 records)
#
 
INSERT INTO `wp_woocommerce_termmeta` VALUES (1, 8, 'order', '0') ; 
INSERT INTO `wp_woocommerce_termmeta` VALUES (2, 8, 'display_type', 'products') ; 
INSERT INTO `wp_woocommerce_termmeta` VALUES (3, 8, 'thumbnail_id', '0') ; 
INSERT INTO `wp_woocommerce_termmeta` VALUES (4, 9, 'order_pa_vintage', '0') ; 
INSERT INTO `wp_woocommerce_termmeta` VALUES (5, 10, 'order_pa_vintage', '0') ; 
INSERT INTO `wp_woocommerce_termmeta` VALUES (6, 11, 'order_pa_vintage', '0') ; 
INSERT INTO `wp_woocommerce_termmeta` VALUES (7, 12, 'order_pa_variety', '0') ; 
INSERT INTO `wp_woocommerce_termmeta` VALUES (8, 13, 'order_pa_vineyard', '0') ; 
INSERT INTO `wp_woocommerce_termmeta` VALUES (9, 14, 'order_pa_winery', '0') ; 
INSERT INTO `wp_woocommerce_termmeta` VALUES (10, 15, 'order_pa_variety', '0') ; 
INSERT INTO `wp_woocommerce_termmeta` VALUES (11, 16, 'order_pa_variety', '0') ; 
INSERT INTO `wp_woocommerce_termmeta` VALUES (12, 17, 'order_pa_variety', '0') ;
#
# End of data contents of table wp_woocommerce_termmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpgmza`
#

DROP TABLE IF EXISTS `wp_wpgmza`;


#
# Table structure of table `wp_wpgmza`
#

CREATE TABLE `wp_wpgmza` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `address` varchar(700) NOT NULL,
  `description` mediumtext NOT NULL,
  `pic` varchar(700) NOT NULL,
  `link` varchar(700) NOT NULL,
  `icon` varchar(700) NOT NULL,
  `lat` varchar(100) NOT NULL,
  `lng` varchar(100) NOT NULL,
  `anim` varchar(3) NOT NULL,
  `title` varchar(700) NOT NULL,
  `infoopen` varchar(3) NOT NULL,
  `category` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpgmza (1 records)
#
 
INSERT INTO `wp_wpgmza` VALUES (3, 1, '4113 Ararat - Halls Gap Road, Halls Gap 3381', '', '', '', '', '-37.14076', '142.558765', '2', '', '0', '') ;
#
# End of data contents of table wp_wpgmza
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_categories`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpgmza_categories`
#

DROP TABLE IF EXISTS `wp_wpgmza_categories`;


#
# Table structure of table `wp_wpgmza_categories`
#

CREATE TABLE `wp_wpgmza_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `category_icon` varchar(700) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpgmza_categories (0 records)
#

#
# End of data contents of table wp_wpgmza_categories
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_category_maps`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpgmza_category_maps`
#

DROP TABLE IF EXISTS `wp_wpgmza_category_maps`;


#
# Table structure of table `wp_wpgmza_category_maps`
#

CREATE TABLE `wp_wpgmza_category_maps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `map_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpgmza_category_maps (0 records)
#

#
# End of data contents of table wp_wpgmza_category_maps
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_category_maps`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_maps`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpgmza_maps`
#

DROP TABLE IF EXISTS `wp_wpgmza_maps`;


#
# Table structure of table `wp_wpgmza_maps`
#

CREATE TABLE `wp_wpgmza_maps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_title` varchar(50) NOT NULL,
  `map_width` varchar(6) NOT NULL,
  `map_height` varchar(6) NOT NULL,
  `map_start_lat` varchar(700) NOT NULL,
  `map_start_lng` varchar(700) NOT NULL,
  `map_start_location` varchar(700) NOT NULL,
  `map_start_zoom` int(10) NOT NULL,
  `default_marker` varchar(700) NOT NULL,
  `type` int(10) NOT NULL,
  `alignment` int(10) NOT NULL,
  `directions_enabled` int(10) NOT NULL,
  `styling_enabled` int(10) NOT NULL,
  `styling_json` mediumtext NOT NULL,
  `active` int(1) NOT NULL,
  `kml` varchar(700) NOT NULL,
  `bicycle` int(10) NOT NULL,
  `traffic` int(10) NOT NULL,
  `dbox` int(10) NOT NULL,
  `dbox_width` varchar(10) NOT NULL,
  `listmarkers` int(10) NOT NULL,
  `listmarkers_advanced` int(10) NOT NULL,
  `filterbycat` tinyint(1) NOT NULL,
  `ugm_enabled` int(10) NOT NULL,
  `ugm_category_enabled` tinyint(1) NOT NULL,
  `fusion` varchar(100) NOT NULL,
  `map_width_type` varchar(3) NOT NULL,
  `map_height_type` varchar(3) NOT NULL,
  `mass_marker_support` int(10) NOT NULL,
  `ugm_access` int(10) NOT NULL,
  `order_markers_by` int(10) NOT NULL,
  `order_markers_choice` int(10) NOT NULL,
  `show_user_location` int(3) NOT NULL,
  `default_to` varchar(700) NOT NULL,
  `other_settings` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_wpgmza_maps (1 records)
#
 
INSERT INTO `wp_wpgmza_maps` VALUES (1, 'My first map', '100', '400', '-37.157147', '142.542626', '-37.15714667999481,142.5426260546875', 9, '0', 1, 1, 1, 0, '', 0, '', 2, 2, 1, '250', 0, 0, 0, 0, 0, '', '\\%', 'px', 1, 0, 1, 2, 0, '', 'a:7:{s:21:"store_locator_enabled";i:2;s:22:"store_locator_distance";i:2;s:26:"store_locator_query_string";s:14:"ZIP / Address:";s:13:"weather_layer";i:2;s:23:"weather_layer_temp_type";i:1;s:11:"cloud_layer";i:2;s:15:"transport_layer";i:2;}') ;
#
# End of data contents of table wp_wpgmza_maps
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_category_maps`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_maps`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_polygon`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpgmza_polygon`
#

DROP TABLE IF EXISTS `wp_wpgmza_polygon`;


#
# Table structure of table `wp_wpgmza_polygon`
#

CREATE TABLE `wp_wpgmza_polygon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `polydata` longtext NOT NULL,
  `linecolor` varchar(7) NOT NULL,
  `lineopacity` varchar(7) NOT NULL,
  `fillcolor` varchar(7) NOT NULL,
  `opacity` varchar(3) NOT NULL,
  `title` varchar(250) NOT NULL,
  `link` varchar(700) NOT NULL,
  `ohfillcolor` varchar(7) NOT NULL,
  `ohlinecolor` varchar(7) NOT NULL,
  `ohopacity` varchar(3) NOT NULL,
  `polyname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpgmza_polygon (0 records)
#

#
# End of data contents of table wp_wpgmza_polygon
# --------------------------------------------------------

# WordPress : http://localhost:8888/FallenGiants/fallengiants MySQL database backup
#
# Generated: Monday 27. October 2014 08:14 UTC
# Hostname: localhost
# Database: `fallengiants`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_category_maps`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_maps`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_polygon`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_polylines`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpgmza_polylines`
#

DROP TABLE IF EXISTS `wp_wpgmza_polylines`;


#
# Table structure of table `wp_wpgmza_polylines`
#

CREATE TABLE `wp_wpgmza_polylines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `polydata` longtext NOT NULL,
  `linecolor` varchar(7) NOT NULL,
  `linethickness` varchar(3) NOT NULL,
  `opacity` varchar(3) NOT NULL,
  `polyname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpgmza_polylines (0 records)
#

#
# End of data contents of table wp_wpgmza_polylines
# --------------------------------------------------------

